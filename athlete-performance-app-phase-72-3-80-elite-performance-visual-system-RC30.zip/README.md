# Phase 72.3.80 RC30 — Elite Performance Visual System

RC30 is a single combined release built on RC29. It preserves all RC29 functional fixes and adds a premium athlete-performance visual system: photography-first hero composition, live performance signal rails, embedded sparklines, sharper graphite/silver surfaces, sport-specific geometry, disciplined category accents, and mobile-first 360–430 px tuning.

No new Supabase migration is required. Migration 009 remains the latest migration.

# Phase 72.3.79 RC29 — More/Roster + Coach Action Repair

RC29 builds on RC28 and fixes three beta issues without changing migration 009:

- More sheet now renders real SVG icons instead of exposing internal icon names like `roster`, preventing label overlap.
- Coach Roster has one primary **Invite Player** action and one **Manage Teams** action; duplicate invite/add-player controls on the same page are removed.
- Coach team/player actions use explicit launchers. In a real Coach account they open the Coach team modal; in Admin Coach Preview they show a clear read-only message instead of silently doing nothing.
- Mobile More-sheet labels and actions reflow safely on narrow screens.

All RC28 navigation, Train layout, Performance OS, role permissions, cloud athletes, Junior mode, player photos, realistic sport imagery, setup modal behavior, and Supabase work remain intact.

No new Supabase migration is required. Migration 009 remains the latest migration.
