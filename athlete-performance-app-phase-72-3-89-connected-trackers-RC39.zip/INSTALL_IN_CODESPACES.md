# Phase 72.3.89 RC39 — Connected Trackers

Upload the RC39 ZIP into `/workspaces/athlete-performance-app`, then run each command separately.

```bash
cd /workspaces/athlete-performance-app
```

```bash
unzip -o athlete-performance-app-phase-72-3-89-connected-trackers-RC39.zip
```

```bash
rm -rf .next
```

```bash
npm install
```

```bash
npm run test:connected-trackers
```

```bash
npm run test:typecheck
```

```bash
npm run build
```

```bash
npm run dev -- -H 0.0.0.0 -p 3001
```

## Required database step
RC39 introduces **migration 010**. Run `supabase/migrations/010_connected_trackers_player_parent_only.sql` in the Supabase SQL Editor after migration 009.

Migration 009 itself is unchanged.

## Provider activation
The tracker screens work immediately, but live cloud Connect buttons remain disabled until the matching developer credentials are added to Vercel. See `TRACKER_PROVIDER_SETUP.md`.
