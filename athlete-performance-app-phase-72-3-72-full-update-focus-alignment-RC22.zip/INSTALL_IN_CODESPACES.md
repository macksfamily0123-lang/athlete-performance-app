# Install Phase 72.3.72 RC22 in Codespaces

From `/workspaces/athlete-performance-app`, upload this ZIP first:

`athlete-performance-app-phase-72-3-72-full-update-focus-alignment-RC22.zip`

Then run:

```bash
cd /workspaces/athlete-performance-app
```

```bash
unzip -o athlete-performance-app-phase-72-3-72-full-update-focus-alignment-RC22.zip
```

```bash
rm -rf .next
```

```bash
npm install
```

```bash
npm run test:focus-icon-alignment
```

```bash
npm run test:role-dashboard-mobile
```

```bash
npm run dev
```

No new Supabase migration is required. Migration 009 remains unchanged.
