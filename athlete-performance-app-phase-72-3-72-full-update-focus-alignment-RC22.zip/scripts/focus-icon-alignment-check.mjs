import fs from "node:fs";
const app=fs.readFileSync("components/AthleteApp.tsx","utf8");
const css=fs.readFileSync("app/globals.css","utf8");
const pkg=JSON.parse(fs.readFileSync("package.json","utf8"));
const checks=[
 ["RC22 version",pkg.version==="72.3.72"],
 ["shared focus icon component exists",app.includes("function PremiumRoleFocusIcon")],
 ["role focus uses shared component",app.includes("<PremiumRoleFocusIcon role={accountRole} juniorMode={juniorMode}/>")],
 ["old focus-card text glyph renderer removed",!app.includes('<span className="premiumRoleFocusIcon">{accountRole===')],
 ["player progress SVG exists",app.includes('M4 18V13M9 18V10M14 18V7M19 18V4')],
 ["coach target SVG exists",app.includes('<circle cx="12" cy="12" r="7.5"/>')],
 ["parent heart SVG exists",app.includes('M20.4 5.7a5.2 5.2')],
 ["admin progress SVG exists",app.includes('M4 19V13M10 19V9M16 19V5')],
 ["icon wrapper uses true grid centering",css.includes("place-items:center!important")&&css.includes("place-content:center!important")],
 ["SVG has explicit dimensions and no transform",css.includes(".premiumRoleFocusIcon svg")&&css.includes("transform:none!important")],
 ["mobile icon sizing remains centered",css.includes(".premiumRoleFocusIcon svg{width:21px;height:21px}")],
 ["RC22 preserves RC21 mobile hero",css.includes("min-height:420px!important")&&css.includes("padding:228px 14px 14px!important")],
 ["RC20 readiness ring preserved",app.includes("SmoothReadinessRing")&&css.includes(".premiumReadinessProgress")],
 ["all-sport realistic assets preserved",app.includes('"/commercial-scenes/baseball-player.webp"')&&app.includes('"/commercial-scenes/figure-skating-player.webp"')]
];
let failed=0;
for(const [name,ok] of checks){console.log(`${ok?"PASS":"FAIL"}: ${name}`);if(!ok)failed++}
if(failed){console.error(`\n${failed} RC22 focus-icon checks failed.`);process.exit(1)}
console.log(`\nPASS: ${checks.length}/${checks.length} focus-icon alignment checks.`);
