# Phase 72.3.72 RC22 — Full Update + Home Focus Alignment

Built on Phase 72.3.71 RC21.

- Fixes the off-center shared Home Focus/Progress symbol on Player, Junior, Coach, Parent, and Admin Home pages.
- Replaces font glyphs with centered inline SVG icons so browser font baselines cannot shift the symbol.
- Keeps role-appropriate visual meaning: Player progress, Junior star, Coach target, Parent support heart, Admin beta-progress chart.
- Preserves RC21 role-dashboard completion and small-screen mobile header reflow.
- Preserves RC20 initials-only fallback avatars and smooth SVG readiness ring.
- Preserves realistic non-Junior hero imagery for all supported sports.
- No new Supabase migration; migration 009 remains unchanged.

# Phase 72.3.71 RC21 — Role Dashboard Completion + Mobile Fit

Built on Phase 72.3.70 RC20.

- Preserves RC20 initials-only fallback avatars and smooth SVG readiness ring.
- Preserves realistic non-Junior hero imagery for all supported sports.
- Adds a data-driven role focus card to Player, Coach, Parent, and Admin Home.
- Coach Home adds team readiness, upcoming-session coverage, Player photos, and next-session context.
- Rebuilds the narrow-screen hero instead of merely shrinking the desktop layout.
- Removes duplicate Home banners on phones.
- Improves Parent/Coach dashboard reflow, bottom navigation, touch sizing, and mobile form readability.
- Keeps Junior Home simpler and shorter.
- No new Supabase migration; migration 009 remains unchanged.

# Phase 72.3.70 RC20 — Avatar & Readiness Polish

Baseline: Phase 72.3.68 RC18, itself built from completed Phase 72.3.64 RC15.

## New in RC20
- Removed the tiny hockey icon from fallback player initials/avatars everywhere, including Parent My Players.
- Replaced the Home readiness conic-gradient ring with a true SVG circle with rounded ends to eliminate the jagged seam.
- The ring now uses the actual readiness percentage and status color.
- All RC19 realistic all-sport header behavior is preserved.
- Non-Junior hero imagery is now realistic for all 8 supported sports:
  Baseball, Football, Ice Hockey, Basketball, Lacrosse, Wrestling, Soccer, Figure Skating.
- The selected athlete's Player Profile Sport remains authoritative.
- Junior Player mode intentionally keeps the simpler sport graphics for now.
- Hockey Coach retains the dedicated realistic coach/team scene.
- Player, Parent, Admin, and non-Junior selected-athlete views receive the realistic sport scene.
- Added `npm run test:realistic-all-sports`.

## Preserved
- Supabase integration.
- Roles and permissions.
- Junior mode.
- Player More navigation fix.
- Cloud test athletes.
- Parent/Coach connection flows.
- Player photos.
- Migration 009 unchanged.
