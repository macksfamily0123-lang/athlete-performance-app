# Athlete Performance App — Phase 71.2 Athlete Selector

## Coach
Coach sees a persistent Viewing selector in the top context bar.
It can switch between all athletes in the roster.

## Admin
Admin can select any athlete and can still use Test View to preview Coach, Player, and Parent interfaces.

## Parent
When entering Parent mode, the parent selects which athletes/children are linked to that account.
The Parent workspace then shows a Viewing selector containing only those linked athletes.

## Player
Player does not receive an athlete selector and remains tied to their own athlete record.

Selecting another athlete switches the full application context:
- Home
- Schedule
- Goals
- Testing
- Analytics
- Readiness
- Development
- Training Program
- Competition

Existing role permissions remain in place.
