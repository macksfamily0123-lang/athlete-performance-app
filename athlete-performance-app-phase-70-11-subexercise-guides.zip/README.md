# Phase 70.11 — Individual Movement Guides

Compound workout blocks are now broken into their actual movements.

Example: Easy movement + dynamic mobility no longer gets a generic tutorial. It displays:
1. Easy jog or bike — 2 minutes
2. Ankle rocks — 10 each side
3. Walking lunges — 8 each side
4. Hip openers — 8 each side
5. Arm circles — 10 each direction

Each individual movement has:
- its own plain-English instruction
- its own video search
- its own photo search

The section title remains a title and does not receive a redundant description or generic demo.
Other compound blocks such as Movement Preparation and Core Stability Circuit are also split into individual movements.
