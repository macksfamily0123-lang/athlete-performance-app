# Phase 72.3.78 RC28 — Always-Active Navigation + Train Layout Repair

RC28 builds on RC27 and fixes two beta issues:

- The five-tab bottom navigation is now rendered through a document-body portal, so scrolling page content cannot cover its tap targets. It remains fixed and interactive at every scroll position.
- The Plan/Train/Progress/More sheet is also portaled above the scrolling app. On narrow phones its menu items use a two-column layout with the action on a separate row, preventing long labels such as **Development** from overlapping descriptions.

## Preserved
- Performance OS redesign
- setup modal restoration
- realistic all-sport non-Junior headers
- Junior mode
- player photos and initials fallback
- smooth Readiness SVG ring
- Supabase cloud integration
- roles and permissions
- Player More/cloud test athletes
- Parent/Coach/Admin workflows
- migration 009 unchanged

## Codespaces quick start

```bash
unzip -o athlete-performance-app-phase-72-3-78-always-active-nav-train-layout-RC28.zip
rm -rf .next
npm install
npm run test:always-active-nav
npm run dev -- -H 0.0.0.0 -p 3001
```
