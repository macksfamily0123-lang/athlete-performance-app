# RC28 Release Notes

## Fixed
1. Bottom navigation tap targets now work while the page is at any scroll position. The dock is mounted at the document viewport level rather than inside the scrolling app tree.
2. The bottom navigation remains fixed, centered, full-width on phones, and above ordinary page content.
3. Navigation sheets are mounted at viewport level as well.
4. On narrow screens, Train-sheet entries wrap safely. **Development** and its descriptive copy no longer overlap.

## Data / backend
No database migration is included. Migration 009 is unchanged.
