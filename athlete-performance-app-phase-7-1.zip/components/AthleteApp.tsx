
"use client";
import {useEffect,useMemo,useState} from "react";

type Sport="Baseball"|"Football"|"Ice Hockey"|"Basketball"|"Lacrosse"|"Wrestling"|"Soccer";
type TestDef={id:string;name:string;category:string;unit:string;lowerBetter:boolean};
type CustomTest=TestDef&{sport:Sport};
type Result={id:number;testId:string;name:string;category:string;unit:string;value:number;date:string;sport:Sport};
type Goal={id:number;title:string;progress:number;type:"Short-term"|"Long-term"};
type Workout={id:number;date:string;name:string;category:string;minutes:number;completed:boolean;sport:Sport};
type Profile={name:string;position:string;team:string;season:string;height:string;weight:string;handedness:"Right"|"Left"};
type DevelopmentItem={id:number,title:string,category:string,target:string,dueDate:string,status:"Not Started"|"In Progress"|"Complete"};

const sports:Sport[]=["Baseball","Football","Ice Hockey","Basketball","Lacrosse","Wrestling","Soccer"];
const categories=["Speed","Agility","Power","Strength","Endurance","Skill","Conditioning","Other"];
const units=["sec","min","mph","km/h","in","ft","lb","kg","reps","yards","meters","points","%","Other"];
const positions:Record<Sport,string[]>={
 Soccer:["Goalkeeper","Center Back","Left Back","Right Back","Defensive Midfielder","Central Midfielder","Attacking Midfielder","Left Wing","Right Wing","Striker","Forward"],
 Baseball:["Pitcher","Catcher","First Base","Second Base","Third Base","Shortstop","Left Field","Center Field","Right Field","Utility"],
 Football:["Quarterback","Running Back","Fullback","Wide Receiver","Tight End","Offensive Line","Defensive Line","Linebacker","Cornerback","Safety","Kicker","Punter","Long Snapper"],
 "Ice Hockey":["Center","Left Wing","Right Wing","Defense","Goaltender"],
 Basketball:["Point Guard","Shooting Guard","Small Forward","Power Forward","Center"],
 Lacrosse:["Attack","Midfield","Defense","Faceoff Specialist","Goalie"],
 Wrestling:["Wrestler"]
};

const raw:Record<Sport,string[][]>={
 Baseball:[["10-yard sprint","Speed","sec","1"],["20-yard sprint","Speed","sec","1"],["5-10-5 shuttle","Agility","sec","1"],["Vertical jump","Power","in","0"],["Broad jump","Power","in","0"],["Bench press","Strength","lb","0"]],
 Football:[["10-yard sprint","Speed","sec","1"],["40-yard sprint","Speed","sec","1"],["5-10-5 shuttle","Agility","sec","1"],["Vertical jump","Power","in","0"],["Broad jump","Power","in","0"],["Bench press","Strength","lb","0"],["Squat","Strength","lb","0"]],
 "Ice Hockey":[["10-yard sprint","Speed","sec","1"],["20-yard sprint","Speed","sec","1"],["Pro agility shuttle","Agility","sec","1"],["Vertical jump","Power","in","0"],["Broad jump","Power","in","0"],["Squat","Strength","lb","0"]],
 Basketball:[["10-yard sprint","Speed","sec","1"],["Lane agility","Agility","sec","1"],["Vertical jump","Power","in","0"],["Broad jump","Power","in","0"],["Squat","Strength","lb","0"]],
 Lacrosse:[["20-yard sprint","Speed","sec","1"],["Pro agility shuttle","Agility","sec","1"],["Vertical jump","Power","in","0"],["Broad jump","Power","in","0"],["Bench press","Strength","lb","0"]],
 Wrestling:[["20-yard sprint","Speed","sec","1"],["5-10-5 shuttle","Agility","sec","1"],["Vertical jump","Power","in","0"],["Broad jump","Power","in","0"],["Squat","Strength","lb","0"],["Pull-ups","Strength","reps","0"]]
};
const definitions=(sport:Sport):TestDef[]=>raw[sport].map((x,i)=>({id:`${sport}-${i}`,name:x[0],category:x[1],unit:x[2],lowerBetter:x[3]==="1"}));
const today=()=>new Date().toISOString().slice(0,10);
const daysAgo=(n:number)=>{const d=new Date();d.setDate(d.getDate()-n);return d.toISOString().slice(0,10)};
const improvement=(first:number,last:number,lower:boolean)=>first===0?0:Math.round((lower?(first-last)/first:(last-first)/first*100)*10)/10;
const pct=(n:number)=>Math.max(0,Math.min(100,Math.round(n)));

export default function AthleteApp(){
 const [sport,setSport]=useState<Sport>("Ice Hockey"),[tab,setTab]=useState("Home");
 const [results,setResults]=useState<Result[]>([]),[custom,setCustom]=useState<CustomTest[]>([]),[goals,setGoals]=useState<Goal[]>([]),[workouts,setWorkouts]=useState<Workout[]>([]),[profile,setProfile]=useState<Profile>({name:"Athlete",position:"",team:"",season:"2026-27",height:"",weight:"",handedness:"Right"}),[dev,setDev]=useState<DevelopmentItem[]>([]);
 useEffect(()=>{for(const [key,setter] of [["results",setResults],["custom",setCustom],["goals",setGoals],["workouts",setWorkouts]] as any[]){try{const v=localStorage.getItem(key);if(v)setter(JSON.parse(v))}catch{}}},[]);
 useEffect(()=>localStorage.setItem("results",JSON.stringify(results)),[results]);
 useEffect(()=>localStorage.setItem("custom",JSON.stringify(custom)),[custom]);
 useEffect(()=>localStorage.setItem("goals",JSON.stringify(goals)),[goals]);
 useEffect(()=>localStorage.setItem("workouts",JSON.stringify(workouts)),[workouts]);
useEffect(()=>{try{const v=localStorage.getItem("profile");if(v){const x=JSON.parse(v);setProfile({name:x?.name??"Athlete",position:x?.position??"",team:x?.team??"",season:x?.season??"2026-27",height:x?.height??"",weight:x?.weight??"",handedness:x?.handedness==="Left"?"Left":"Right"})}}catch{}},[]);
useEffect(()=>localStorage.setItem("profile",JSON.stringify(profile)),[profile]);
useEffect(()=>{try{const v=localStorage.getItem("development");if(v)setDev(JSON.parse(v))}catch{}},[]);
useEffect(()=>localStorage.setItem("development",JSON.stringify(dev)),[dev]);
 return <div className="app">
  <header><div className="logo">AP</div><div><strong>Athlete Performance</strong><small>Train with purpose.</small></div></header>
  <main>
   <div className="sports">{sports.map(s=><button className={sport===s?"sel":""} onClick={()=>{setSport(s);setProfile((x:Profile)=>({...x,position:positions[s].includes(x.position)?x.position:""}))}} key={s}>{s}</button>)}</div>
   {tab==="Home"&&<Home sport={sport} goals={goals} workouts={workouts} results={results} profile={profile} setProfile={setProfile}/>}
   {tab==="Goals"&&<Goals goals={goals} setGoals={setGoals}/>}
   {tab==="Calendar"&&<Calendar sport={sport} workouts={workouts} setWorkouts={setWorkouts}/>}
   {tab==="Testing"&&<Testing sport={sport} library={[...definitions(sport),...custom.filter(x=>x.sport===sport)]} custom={custom} setCustom={setCustom} results={results} setResults={setResults}/>}
   {tab==="Analytics</button><button className={tab==="Development"?"sel":""} onClick={()=>setTab("Development")}>Development"&&<Analytics sport={sport} results={results} goals={goals} workouts={workouts}/>}{tab==="Development"&&<Development sport={sport} dev={dev} setDev={setDev} results={results}/>}
  </main>
  <nav>{["Home","Goals","Calendar","Testing","Analytics"].map(x=><button className={tab===x?"active":""} onClick={()=>setTab(x)} key={x}>{x}</button>)}</nav>
 </div>
}

function Home({sport,goals,workouts,results,profile,setProfile}:{sport:Sport;goals:Goal[];workouts:Workout[];results:Result[];profile:Profile;setProfile:any}){
 const gs=goals.length?Math.round(goals.reduce((a,g)=>a+g.progress,0)/goals.length):0;
 const ws=workouts.filter(x=>x.sport===sport),done=ws.filter(x=>x.completed).length;
 const rs=results.filter(x=>x.sport===sport);
 const score=pct(gs*.4+(ws.length?done/ws.length*30:0)+(rs.length?30:0));
 return <><div className="hero"><small>ATHLETE DASHBOARD</small><h1>{profile.name}</h1><p>{sport}{profile.position?" · "+profile.position:""}{profile.team?" · "+profile.team:""} · {profile.season}</p></div><div className="card profileCard"><h2>Athlete Profile</h2><div className="two"><label>Name<input value={profile.name??""} onChange={e=>setProfile((x:Profile)=>({...x,name:e.target.value}))}/></label><label>Position<select value={positions[sport].includes(profile.position)?profile.position:""} onChange={e=>setProfile((x:Profile)=>({...x,position:e.target.value}))}><option value="">Select position</option>{positions[sport].map(x=><option key={x}>{x}</option>)}</select></label><label>Team<input value={profile.team??""} onChange={e=>setProfile((x:Profile)=>({...x,team:e.target.value}))}/></label><label>Season<input value={profile.season??""} onChange={e=>setProfile((x:Profile)=>({...x,season:e.target.value}))}/></label><label>Height<input value={profile.height??""} onChange={e=>setProfile((x:Profile)=>({...x,height:e.target.value}))} placeholder="e.g. 5'10&quot;"/></label><label>Weight<input inputMode="decimal" value={profile.weight??""} onChange={e=>setProfile((x:Profile)=>({...x,weight:e.target.value}))} placeholder="e.g. 165 lb"/></label><label>Handedness<select value={profile.handedness??"Right"} onChange={e=>setProfile((x:Profile)=>({...x,handedness:e.target.value as "Right"|"Left"}))}><option>Right</option><option>Left</option></select></label></div></div>
 <div className="grid three"><div className="stat"><small>Performance</small><b>{score}</b><span>/100</span></div><div className="stat"><small>Goal Progress</small><b>{gs}%</b></div><div className="stat"><small>Tests Logged</small><b>{rs.length}</b></div></div>
 <div className="card"><div className="sectionHead"><h2>Today's Focus</h2><span>{today()}</span></div><p>{ws.find(x=>x.date===today()&&!x.completed)?.name||"No workout scheduled today."}</p></div>
 <div className="card"><h2>Quick Stats</h2><div className="quickStats"><span><b>{ws.filter(x=>x.completed).length}</b><small>Completed workouts</small></span><span><b>{rs.length}</b><small>Performance results</small></span><span><b>{goals.length}</b><small>Active goals</small></span></div></div><div className="card"><h2>Recent Activity</h2>{ws.slice(0,3).map(w=><div className="row line" key={w.id}><span>{w.name}<small>{w.date} · {w.minutes} min</small></span><b>{w.completed?"✓":"Scheduled"}</b></div>)}{!ws.length&&<p>No workouts yet. Add one from Calendar.</p>}</div></>
}

function Goals({goals,setGoals}:{goals:Goal[];setGoals:any}){
 const [title,setTitle]=useState(""),[type,setType]=useState<Goal["type"]>("Short-term");
 return <><h1>Goals</h1><div className="card"><label>Goal name<input value={title} onChange={e=>setTitle(e.target.value)} placeholder="e.g. Improve sprint time"/></label><label>Goal type<select value={type} onChange={e=>setType(e.target.value as Goal["type"])}><option>Short-term</option><option>Long-term</option></select></label><button className="primary" onClick={()=>{if(title.trim()){setGoals((g:Goal[])=>[{id:Date.now(),title:title.trim(),progress:0,type},...g]);setTitle("")}}}>Add Goal</button></div>
 {goals.map(g=><div className="card" key={g.id}><div className="row"><b>{g.title}</b><span className="tag">{g.type}</span></div><input type="range" value={g.progress} onChange={e=>setGoals((x:Goal[])=>x.map(a=>a.id===g.id?{...a,progress:+e.target.value}:a))}/><div className="progress"><i style={{width:`${g.progress}%`}}/></div><small>{g.progress}% complete</small></div>)}</>
}

function Calendar({sport,workouts,setWorkouts}:{sport:Sport;workouts:Workout[];setWorkouts:any}){
 const [date,setDate]=useState(today()),[name,setName]=useState("Sport Workout"),[cat,setCat]=useState("Conditioning"),[minutes,setMinutes]=useState("45");
 const rows=workouts.filter(w=>w.sport===sport).sort((a,b)=>a.date.localeCompare(b.date));
 return <><h1>Training Calendar</h1><div className="card"><div className="calendarTop"><button onClick={()=>{const d=new Date(date);d.setDate(d.getDate()-1);setDate(d.toISOString().slice(0,10))}}>‹</button><input type="date" value={date} onChange={e=>setDate(e.target.value)}/><button onClick={()=>{const d=new Date(date);d.setDate(d.getDate()+1);setDate(d.toISOString().slice(0,10))}}>›</button></div><label>Workout name<input value={name} onChange={e=>setName(e.target.value)}/></label><label>Workout category<select value={cat} onChange={e=>setCat(e.target.value)}>{categories.map(x=><option key={x}>{x}</option>)}</select></label><label>Duration<select value={minutes} onChange={e=>setMinutes(e.target.value)}>{["15","30","45","60","75","90","120"].map(x=><option key={x} value={x}>{x} minutes</option>)}</select></label><button className="primary" onClick={()=>setWorkouts((x:Workout[])=>[{id:Date.now(),date,name,category:cat,minutes:+minutes,completed:false,sport},...x])}>Schedule Workout</button></div>
 <h2>Upcoming & Recent</h2>{rows.map(w=><div className="card row" key={w.id}><span><b>{w.name}</b><small>{w.date} · {w.category} · {w.minutes} min</small></span><button onClick={()=>setWorkouts((x:Workout[])=>x.map(a=>a.id===w.id?{...a,completed:!a.completed}:a))}>{w.completed?"✓ Completed":"Complete"}</button></div>)}</>
}

function Testing({sport,library,custom,setCustom,results,setResults}:{sport:Sport;library:TestDef[];custom:CustomTest[];setCustom:any;results:Result[];setResults:any}){
 const [id,setId]=useState(library[0]?.id||""),[category,setCategory]=useState(""),[unit,setUnit]=useState(""),[value,setValue]=useState(""),[open,setOpen]=useState(false);
 const [name,setName]=useState(""),[newCat,setNewCat]=useState("Speed"),[newUnit,setNewUnit]=useState("sec"),[lower,setLower]=useState(true);
 useEffect(()=>{if(!library.some(x=>x.id===id))setId(library[0]?.id||"")},[sport,custom]);
 const t=library.find(x=>x.id===id), rows=results.filter(x=>x.sport===sport);
 useEffect(()=>{if(t){setCategory(t.category);setUnit(t.unit)}},[id]);
 const save=()=>{if(t&&value.trim()&&!isNaN(Number(value)))setResults((r:Result[])=>[{id:Date.now(),testId:t.id,name:t.name,category,unit,value:Number(value),date:today(),sport},...r])};
 return <><h1>Performance Testing</h1><div className="card">
 <label>Test Name<select value={id} onChange={e=>e.target.value==="__custom__"?setOpen(true):setId(e.target.value)}>{library.map(x=><option value={x.id} key={x.id}>{x.name}</option>)}<option value="__custom__">＋ Create Custom Test</option></select></label>
 <div className="two"><label>Category<select value={category} onChange={e=>setCategory(e.target.value)}>{categories.map(x=><option key={x}>{x}</option>)}</select></label><label>Unit of Measure<select value={unit} onChange={e=>setUnit(e.target.value)}>{units.map(x=><option key={x}>{x}</option>)}</select></label></div>
 {t&&<p>{t.lowerBetter?"Lower is better":"Higher is better"}</p>}<label>Result<input inputMode="decimal" value={value} onChange={e=>setValue(e.target.value)}/></label><button className="primary" disabled={!t} onClick={save}>Save Result</button></div>
 <h2>Test History</h2>{rows.map(r=><div className="card row" key={r.id}><span><b>{r.name}</b><small>{r.date} · {r.category}</small></span><strong>{r.value} {r.unit}</strong></div>)}
 {open&&<div className="overlay"><div className="modal"><div className="sectionHead"><h2>Create Custom Test</h2><button onClick={()=>setOpen(false)}>×</button></div><label>Test name<input value={name} onChange={e=>setName(e.target.value)} placeholder="e.g. Shot speed"/></label><label>Category<select value={newCat} onChange={e=>setNewCat(e.target.value)}>{categories.map(x=><option key={x}>{x}</option>)}</select></label><label>Unit of Measure<select value={newUnit} onChange={e=>setNewUnit(e.target.value)}>{units.map(x=><option key={x}>{x}</option>)}</select></label><label>Better result<select value={lower?"lower":"higher"} onChange={e=>setLower(e.target.value==="lower")}><option value="lower">Lower is better</option><option value="higher">Higher is better</option></select></label><button className="primary" onClick={()=>{if(name.trim()){const x={id:`custom-${Date.now()}`,name:name.trim(),category:newCat,unit:newUnit,lowerBetter:lower,sport};setCustom((c:CustomTest[])=>[...c,x]);setId(x.id);setOpen(false);setName("")}}}>Save Custom Test</button></div></div>}</>
}

function Analytics({sport,results,goals,workouts}:{sport:Sport;results:Result[];goals:Goal[];workouts:Workout[]}){
 const [range,setRange]=useState("all"),cutoff=range==="all"?0:Date.now()-Number(range)*86400000;
 const rows=results.filter(r=>r.sport===sport&&new Date(r.date).getTime()>=cutoff).sort((a,b)=>a.date.localeCompare(b.date)||a.id-b.id), groups=[...new Map(rows.map(r=>[r.testId,r])).values()];
 const avgGoal=goals.length?Math.round(goals.reduce((a,g)=>a+g.progress,0)/goals.length):0,ws=workouts.filter(w=>w.sport===sport),cons=ws.length?Math.round(ws.filter(w=>w.completed).length/ws.length*100):0,score=Math.round(avgGoal*.4+cons*.3+(groups.length?30:0));
 return <><h1>Analytics</h1><div className="analyticsActions"><button onClick={()=>exportResults(rows)}>Export Results CSV</button></div><div className="filters">{["30","90","365","all"].map(x=><button className={range===x?"sel":""} onClick={()=>setRange(x)} key={x}>{x==="all"?"All":x+"D"}</button>)}</div><div className="score"><small>ATHLETE PERFORMANCE SCORE</small><strong>{score}</strong><span>/100</span></div><div className="card"><h2>Personal Records & Trends</h2>
 {groups.length?groups.map(g=>{const r=rows.filter(x=>x.testId===g.testId).sort((a,b)=>a.date.localeCompare(b.date)||a.id-b.id),def=definitions(sport).find(x=>x.id===g.testId)||({lowerBetter:g.unit==="sec"} as TestDef),baseline=r[0]?.value??0,last=r[r.length-1]?.value??0,best=r.reduce((a,b)=>def.lowerBetter?Math.min(a,b.value):Math.max(a,b.value),baseline),imp=r.length>1?improvement(baseline,last,def.lowerBetter):0;return <div className="trend" key={g.testId}><div className="row"><div><b>{g.name}</b><small>{r.length} results · Best {best} {g.unit}</small></div><strong className={imp>=0?"good":"bad"}>{r.length>1?(imp>=0?"+":"")+imp+"%":"New"}</strong></div><TrendChart values={r.map(x=>x.value)} lower={def.lowerBetter}/><div className="trendAxis"><span>Baseline · {r[0]?.date}</span><span>Current · {r[r.length-1]?.date}</span></div><small>Baseline {baseline} {g.unit} → Current {last} {g.unit} · {r.length>1?`Improvement ${Math.abs(imp)}%`:"Add another result to calculate improvement"}</small></div>}) : <p>Record the same test more than once to see a trend line and quantified improvement.</p>}
 </div><CompareTests sport={sport} results={rows}/><div className="grid twoCards"><div className="card"><h2>Goal Progress</h2><b className="big">{avgGoal}%</b></div><div className="card"><h2>Training Consistency</h2><b className="big">{cons}%</b></div></div></>
}

function CompareTests({sport,results}:{sport:Sport;results:Result[]}){
 const tests=[...new Map(results.map(r=>[r.testId,r])).values()];
 const [a,setA]=useState(tests[0]?.testId||""),[b,setB]=useState(tests[1]?.testId||"");
 useEffect(()=>{if(!tests.some(x=>x.testId===a))setA(tests[0]?.testId||"");if(!tests.some(x=>x.testId===b))setB(tests[1]?.testId||"")},[results.length]);
 const series=(id:string)=>results.filter(r=>r.testId===id).sort((x,y)=>x.date.localeCompare(y.date)||x.id-y.id);
 const render=(id:string)=>{const r=series(id),t=r[r.length-1];if(!t)return <p>No result.</p>;const first=r[0],def=definitions(sport).find(x=>x.id===id)||({lowerBetter:t.unit==="sec"} as TestDef),imp=r.length>1?improvement(first.value,t.value,def.lowerBetter):0;return <div className="compareValue"><b>{t.name}</b><strong>{t.value} {t.unit}</strong><small>{r.length>1?`${imp>=0?"+":""}${imp}% from baseline`:"One result logged"}</small></div>};
 return <div className="card"><h2>Compare Tests</h2><div className="two"><label>Test A<select value={a} onChange={e=>setA(e.target.value)}>{tests.map(t=><option key={t.testId} value={t.testId}>{t.name}</option>)}</select></label><label>Test B<select value={b} onChange={e=>setB(e.target.value)}>{tests.map(t=><option key={t.testId} value={t.testId}>{t.name}</option>)}</select></label></div><div className="compareGrid">{render(a)}{render(b)}</div></div>
}
function exportResults(rows:Result[]){
 const header="Date,Test,Category,Unit,Value,Sport";
 const body=rows.map(r=>[r.date,r.name,r.category,r.unit,r.value,r.sport].map(v=>`"${String(v).replaceAll('"','""')}"`).join(",")).join("\n");
 const blob=new Blob([header+"\n"+body],{type:"text/csv;charset=utf-8"}),url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download="athlete-performance-results.csv";a.click();URL.revokeObjectURL(url);
}

function Development({sport,dev,setDev,results}:{sport:Sport;dev:DevelopmentItem[];setDev:any;results:Result[]}){
 const [title,setTitle]=useState(""),[category,setCategory]=useState("Skill"),[target,setTarget]=useState(""),[dueDate,setDueDate]=useState("");
 const add=()=>{if(!title.trim())return;setDev((x:DevelopmentItem[])=>[...x,{id:Date.now(),title:title.trim(),category,target,dueDate,status:"Not Started"}]);setTitle("");setTarget("");setDueDate("")};
 const toggle=(id:number)=>setDev((x:DevelopmentItem[])=>x.map(i=>i.id===id?{...i,status:i.status==="Complete"?"In Progress":"Complete"}:i));
 const remove=(id:number)=>setDev((x:DevelopmentItem[])=>x.filter(i=>i.id!==id));
 const complete=dev.filter(x=>x.status==="Complete").length;
 return <><div className="hero"><small>PLAYER DEVELOPMENT</small><h1>Development Plan</h1><p>{sport} · {complete}/{dev.length||0} objectives complete</p></div>
 <div className="card"><h2>Add Development Objective</h2><div className="two"><label>Objective<input value={title} onChange={e=>setTitle(e.target.value)} placeholder="e.g. Improve first-step quickness"/></label><label>Category<select value={category} onChange={e=>setCategory(e.target.value)}><option>Skill</option><option>Strength</option><option>Speed</option><option>Conditioning</option><option>Technique</option><option>Game Performance</option></select></label><label>Target<input value={target} onChange={e=>setTarget(e.target.value)} placeholder="e.g. 5% improvement"/></label><label>Target Date<input type="date" value={dueDate} onChange={e=>setDueDate(e.target.value)}/></label></div><button onClick={add}>Add Objective</button></div>
 <div className="card"><h2>Objectives</h2>{!dev.length?<p>No development objectives yet.</p>:dev.map(i=><div className="devRow" key={i.id}><div><b>{i.title}</b><small>{i.category}{i.target?" · "+i.target:""}{i.dueDate?" · Due "+i.dueDate:""}</small></div><div><button onClick={()=>toggle(i.id)}>{i.status}</button><button onClick={()=>remove(i.id)}>Delete</button></div></div>)}</div>
 <div className="card"><h2>Performance Snapshot</h2><div className="quickStats"><span><b>{results.length}</b><small>Results logged</small></span><span><b>{new Set(results.map(r=>r.testId)).size}</b><small>Tests tracked</small></span><span><b>{dev.length?Math.round(complete/dev.length*100):0}%</b><small>Plan completion</small></span></div></div></>
}
function TrendChart({values,lower}:{values:number[];lower:boolean}){const w=520,h=150,p=24,min=Math.min(...values),max=Math.max(...values),span=max-min||1;const pts=values.map((v,i)=>`${p+i*((w-2*p)/Math.max(1,values.length-1))},${h-p-((v-min)/span)*(h-2*p)}`).join(" ");return <svg className="chart" viewBox={`0 0 ${w} ${h}`} role="img" aria-label="Performance trend"><line x1={p} y1={h-p} x2={w-p} y2={h-p} stroke="currentColor" opacity=".2"/><polyline points={pts} fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"/>{values.map((v,i)=>{const x=p+i*((w-2*p)/Math.max(1,values.length-1)),y=h-p-((v-min)/span)*(h-2*p);return <circle key={i} cx={x} cy={y} r="5" fill="currentColor"/>})}</svg>}
