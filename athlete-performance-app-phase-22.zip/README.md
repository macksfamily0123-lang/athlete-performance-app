# Athlete Performance App — Phase 22

Built from Phase 21.

Phase 22 upgrades Calendar into Workouts 2.0 without adding another tab:
- Target workout intensity
- Session focus
- Completion workflow
- Session RPE (1–10)
- Session notes
- Training load = minutes × RPE
- 7-day training load
- 7-day completed minutes
- Average RPE
- Training-load guidance
- Existing season planning and training blocks preserved

All Phase 1–21 features remain included.
