import fs from "node:fs";

const athlete=fs.readFileSync("components/AthleteApp.tsx","utf8");
const beta=fs.readFileSync("components/BetaGate.tsx","utf8");
const css=fs.readFileSync("app/globals.css","utf8");
const migration=fs.readFileSync("supabase/migrations/009_player_more_cloud_test_athletes.sql","utf8");

const sportAssets=[
 "ice-hockey.svg","baseball.svg","football.svg","basketball.svg",
 "lacrosse.svg","wrestling.svg","soccer.svg","figure-skating.svg"
];

const checks=[
 ["RC16 ribbon",beta.includes("BETA · RC16 · v72.3.65")],
 ["Profile supports player photo",athlete.includes("photoDataUrl?:string")],
 ["Player photo is compressed before storage",athlete.includes("preparePlayerPhoto")&&athlete.includes('canvas.toDataURL("image/jpeg",.82)')],
 ["Player photo input accepts phone images",athlete.includes('id="player-photo-input"')&&athlete.includes('accept="image/*"')],
 ["Player photo can be changed or removed",athlete.includes('profileDraft.photoDataUrl?"Change Photo":"Add Photo"')&&athlete.includes('photoDataUrl:""')],
 ["Premium hero displays player photo",athlete.includes('premiumAthleteAvatar "+(profile.photoDataUrl?"hasPhoto":"")')],
 ["Local profile load preserves photo",athlete.includes('photoDataUrl:typeof x?.photoDataUrl==="string"?x.photoDataUrl:""')],
 ["Athlete snapshot load preserves photo",athlete.includes('photoDataUrl:typeof x?.profile?.photoDataUrl==="string"?x.profile.photoDataUrl:""')],
 ["Commercial UI CSS block",css.includes("Phase 72.3.65 — Commercial Sports UI")],
 ["Eight sport art files",sportAssets.every(name=>fs.existsSync(`public/sport-art/${name}`))],
 ["Hockey hero artwork",css.includes('url("/sport-art/ice-hockey.svg")')],
 ["Hockey artwork contains goal, stick and puck",fs.readFileSync("public/sport-art/ice-hockey.svg","utf8").includes("unmistakable goal")&&fs.readFileSync("public/sport-art/ice-hockey.svg","utf8").includes("very obvious stick and puck")],
 ["Baseball hero artwork",css.includes('url("/sport-art/baseball.svg")')],
 ["Football hero artwork",css.includes('url("/sport-art/football.svg")')],
 ["Basketball hero artwork",css.includes('url("/sport-art/basketball.svg")')],
 ["Lacrosse hero artwork",css.includes('url("/sport-art/lacrosse.svg")')],
 ["Wrestling hero artwork",css.includes('url("/sport-art/wrestling.svg")')],
 ["Soccer hero artwork",css.includes('url("/sport-art/soccer.svg")')],
 ["Figure Skating hero artwork",css.includes('url("/sport-art/figure-skating.svg")')],

 ["Color tones added to Player quick actions",athlete.includes('tone:"mint",label:juniorMode?"How I Feel":"Check In"')&&athlete.includes('tone:"blue",label:juniorMode?"My Training":"Next Training"')],
 ["Color tones added to Coach quick actions",athlete.includes('tone:"blue",label:"Roster"')&&athlete.includes('tone:"amber",label:"Player Goals"')],
 ["Color tones added to Parent quick actions",athlete.includes('tone:"blue",label:"Schedule"')&&athlete.includes('tone:"violet",label:"Support"')],
 ["Colored icon wells styled",css.includes(".premiumQuickGrid>button.tone-violet .premiumQuickIcon")&&css.includes(".premiumQuickGrid>button.tone-amber .premiumQuickIcon")],
 ["Metric cards visually varied",css.includes(".premiumMetricStrip button:nth-child(1)")&&css.includes(".premiumMetricStrip button:nth-child(3)")],
 ["More menu colored icon wells",css.includes(".simpleNavChoices button:nth-child(4n+3)>span")],
 ["Player daily CTA exists",athlete.includes('className="commercialPrimaryAction"')],
 ["Player daily CTA styled",css.includes(".commercialPrimaryAction{")],

 ["Graphical progress overview exists",athlete.includes('className="commercialProgressOverview"')],
 ["Progress ring is data-driven",athlete.includes('conic-gradient(#75d4a9 0 ${overall}%')],
 ["Five progress bars use instrument data",athlete.includes('instruments.map(item=><div className="commercialProgressBar"')],
 ["Progress signal chart exists",athlete.includes('className="commercialProgressSpark"')&&athlete.includes("<polyline points={sparkPolyline}/>")],
 ["Progress bars have multi-category colors",css.includes(".commercialProgressBar:nth-child(5)>i>b")],

 ["Premium 72.3.64 UI retained",css.includes("Phase 72.3.64 — Premium Performance / App Store UI")],
 ["72.3.63 hierarchy retained",css.includes("Phase 72.3.63 — Visual Hierarchy & Navigation Cleanup")],
 ["Player More gateway retained",athlete.includes('if(group==="More"&&effectiveRole==="Player"){setNavSheet("More");return}')],
 ["Cloud test athlete retained",athlete.includes("createAdminTestAthlete")&&beta.includes("admin_create_test_athlete")],
 ["Migration 009 retained",migration.includes("admin_create_test_athlete")],
 ["Persistent Admin Preview retained",athlete.includes('className="adminPreviewBar"')],
 ["Junior All Features retained",athlete.includes("juniorFeaturePalette")&&athlete.includes("See All My Features")],
 ["Junior Goal Entry retained",athlete.includes("juniorGoalEntryCard")],
 ["Family diagnostics retained",beta.includes("Family & Account Diagnostics")],
 ["No practice-plan generator",!athlete.includes("Generate Practice Plan")&&!athlete.includes("Practice Plan Generator")]
];

const failed=checks.filter(([,ok])=>!ok);
for(const [name,ok] of checks)console.log(`${ok?"PASS":"FAIL"}  ${name}`);
if(failed.length){
 console.error(`\n${failed.length}/${checks.length} Commercial Sports UI checks failed.`);
 process.exit(1);
}
console.log(`\nPASS: ${checks.length}/${checks.length} Commercial Sports UI checks.`);
