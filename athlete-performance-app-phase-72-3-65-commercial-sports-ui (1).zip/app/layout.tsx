import type {Metadata,Viewport} from "next";
import "./globals.css";

export const metadata:Metadata={
  title:"Athlete Performance Beta",
  description:"Athlete performance, development, testing, readiness, and training tools.",
  applicationName:"Athlete Performance",
  manifest:"/manifest.webmanifest",
  icons:{
    icon:[{url:"/icon-192.png",sizes:"192x192",type:"image/png"},{url:"/icon-512.png",sizes:"512x512",type:"image/png"}],
    apple:"/icon-192.png"
  }
};

export const viewport:Viewport={
  width:"device-width",
  initialScale:1,
  viewportFit:"cover",
  themeColor:"#0d0f0e"
};

export default function RootLayout({children}:{children:React.ReactNode}){
  return <html lang="en"><body>{children}</body></html>
}
