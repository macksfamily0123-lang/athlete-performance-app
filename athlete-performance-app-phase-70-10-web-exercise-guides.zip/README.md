# Athlete Performance App — Phase 70.10

Exercise guidance update:

- Removed the vague in-app exercise drawings.
- Every generated exercise now has a short plain-English "Simple instruction".
- Every exercise has:
  - Watch Video Demo — opens a web-accessible YouTube search for that exact exercise.
  - View Photos — opens a web image search for that exact exercise.
- Existing detailed How instructions remain available.
- Sets, reps/time, rest, coaching purpose, Gym Access / Body Weight selection, and all other features remain.

This approach avoids inaccurate generic drawings and gives athletes access to real demonstrations for each exercise.
