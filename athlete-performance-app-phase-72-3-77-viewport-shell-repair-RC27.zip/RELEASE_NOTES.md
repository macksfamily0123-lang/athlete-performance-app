# Phase 72.3.76 RC26 — Performance OS Redesign

RC26 is a full visual-system reset built on Phase 72.3.75 RC25.

## Design changes
- Replaces the repeated rounded-card dashboard language with a flatter performance-OS layout.
- Uses edge-to-edge photography and hard-edged hero composition on non-Junior Home screens.
- Converts Home metrics into a continuous ruled instrument rail.
- Uses flat editorial focus sections and numbered action rows instead of tile grids.
- Adds sharper cut geometry to the primary daily action.
- Converts Coach Home to a tactical command-board treatment.
- Converts Parent Home to a restrained support timeline.
- Converts Admin Home to a flat operations-console treatment.
- Keeps Junior intentionally friendlier while reducing card repetition.
- Makes cards, forms, lists, sub-navigation, dialogs, and bottom navigation much less rounded app-wide.
- Keeps circular geometry only where it communicates something: player photos, avatars, and readiness/progress instruments.
- Preserves the RC25 setup popup as a true modal, but restyles it as a sharper performance sheet.
- Includes dedicated 360–430 px mobile tuning.

## Preserved functionality
Supabase integration, role/permission rules, Junior mode, Player More fix, cloud test athletes, player photos, realistic all-sport non-Junior imagery, Parent/Coach workflows, Admin Preview, Readiness ring, and migration 009 are preserved.

No new Supabase migration is required.
