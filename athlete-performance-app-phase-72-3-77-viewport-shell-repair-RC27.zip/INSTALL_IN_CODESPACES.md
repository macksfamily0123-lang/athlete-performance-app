# Install Phase 72.3.76 RC26 in Codespaces

From `/workspaces/athlete-performance-app`, unzip the release over the current app, clear `.next`, install dependencies, run the RC26 design check and TypeScript check, then start the app.

```bash
unzip -o athlete-performance-app-phase-72-3-76-performance-os-redesign-RC26.zip
```

```bash
rm -rf .next
```

```bash
npm install
```

```bash
npm run test:performance-os
```

```bash
npm run test:typecheck
```

```bash
npm run dev -- -H 0.0.0.0 -p 3001
```

No new Supabase migration is required. Migration 009 remains the latest migration.
