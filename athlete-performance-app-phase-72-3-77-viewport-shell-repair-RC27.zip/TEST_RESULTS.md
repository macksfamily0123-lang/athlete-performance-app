# RC26 test results

Static/regression scripts were run against the packaged source before release.

- Performance OS design: 18/18 passed
- Role permissions: 41/41 passed
- Family reliability: 75/75 passed
- Player More / cloud athletes: 35/35 passed
- All-sport realistic headers: 22/22 passed
- Setup modal restoration: 12/12 passed
- Native sports redesign preservation: 18/18 passed
- Commercial UI / player photo checks: 19/19 passed
- All remaining standalone project regression scripts passed.

Migration 009 SHA-256 remains:
`ea088a53e3ffbb4ecfcab6e42fc9358b26a3c53e984299a436b887e8a008f626`

A dependency-backed `npm run test:typecheck` / `npm run build` should be run in Codespaces after `npm install`.
