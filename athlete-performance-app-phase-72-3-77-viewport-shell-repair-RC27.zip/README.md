# Phase 72.3.77 RC27 — Viewport Shell Repair

RC27 builds on the Phase 72.3.76 RC26 Performance OS redesign and fixes two shared-shell regressions found in beta testing: setup dialogs rendering at the bottom of the page and bottom navigation shifting off-screen.

## Goal
Keep the RC26 Performance OS design while making setup and navigation behave like a native mobile app on every role and every scrolling screen.

## What changed
- Guided setup, setup-incomplete warnings, and Player/Coach role setup now render through a document-body portal so they are always centered in the viewport.
- Setup overlays sit above the persistent navigation with a dimmed backdrop and mobile-safe sizing.
- Bottom navigation is now a true fixed viewport dock, not inherited sticky content.
- The old `translateX(-50%)` offset is explicitly cleared, fixing the dock shifting off the left edge.
- All five bottom tabs use equal-width columns and stay visible while content scrolls.
- Main content reserves safe-area-aware bottom space so the fixed dock does not cover page content.
- Performance OS root design system applied app-wide.
- Sharper 0–4 px geometry replaces most rounded cards, tabs, controls, sheets, and data panels.
- Home photography is full-bleed and hard-edged.
- Player Home reads as one editorial performance flow rather than a stack of tiles.
- Readiness remains circular because the circle communicates progress; avatars remain circular because they represent people.
- Goals, testing, schedule, roster, development, analytics, and other content areas use flatter rows and ruled sections.
- Coach Home is treated as a tactical command board.
- Parent Home is treated as a support timeline.
- Admin Home is treated as an operations console.
- Junior remains more approachable but uses fewer floating cards.
- Primary CTAs use a custom clipped sports geometry.
- Bottom navigation is integrated into the screen edge instead of floating as a rounded dock.
- Modal behavior from RC25 remains intact, with a sharper sheet treatment.
- Dedicated mobile treatment for narrow 360–430 px screens is included.

## Preserved
- Supabase integration
- Roles and permissions
- Junior mode
- Player More fix
- Cloud test athletes
- Player photos and initials fallback
- Realistic non-Junior sport imagery for all supported sports
- Parent / Coach / Admin flows
- Smooth Readiness ring
- Migration 009 unchanged

No new Supabase migration is required.

## Verification
Run:

```bash
npm run test:viewport-shell
```

Then preserve the design-system check:

```bash
npm run test:performance-os
```

Then:

```bash
npm run test:typecheck
```

The dependency-backed TypeScript / Next.js build should be verified in Codespaces after `npm install`.
