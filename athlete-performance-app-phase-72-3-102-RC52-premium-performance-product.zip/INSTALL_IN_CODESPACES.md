# Phase 72.3.102 RC52 — Premium Performance Product System

This is one full release. It includes the RC52 premium performance product system, RC51 forest-and-silver foundation, RC50 compact Junior banner and reliable Edit Player action, and every earlier feature. Tracker connectivity remains disabled.

## Codespaces

1. Upload `athlete-performance-app-phase-72-3-102-RC52-premium-performance-product.zip` to the root of your Codespace.

2. Open the terminal and go to the repository folder.

```bash
cd /workspaces/athlete-performance-app
```

3. Extract the release over the existing app.

```bash
unzip -o athlete-performance-app-phase-72-3-102-RC52-premium-performance-product.zip
```

4. Remove the uploaded ZIP so it is not committed to GitHub.

```bash
rm athlete-performance-app-phase-72-3-102-RC52-premium-performance-product.zip
```

5. Remove the old Next.js build cache.

```bash
rm -rf .next
```

6. Install the locked dependencies.

```bash
npm install
```

7. Run every automated check and the production build.

```bash
npm run release:check
```

8. If migration 014 has **not** already been run in this Supabase project, print it, copy its output, and run it once in the Supabase SQL Editor. If you already ran it when creating the Junior Player, skip this step. RC52 has no new migration.

```bash
cat supabase/migrations/014_parent_player_claim_code_repair.sql
```

9. Start the Codespaces preview.

```bash
npm run dev -- -H 0.0.0.0 -p 3001
```

## GitHub and Vercel

10. Check the changed files.

```bash
git status
```

11. Stage the release.

```bash
git add .
```

12. Commit the combined release.

```bash
git commit -m "Release Phase 72.3.102 RC52 premium performance product"
```

13. Push to GitHub. If your Vercel project tracks `main`, this push starts the deployment.

```bash
git push origin main
```

14. If Vercel is not connected to GitHub, deploy from Codespaces with the Vercel CLI.

```bash
npx vercel --prod
```

No Google Health/Fitbit, Oura, WHOOP, Strava, or KINEXON credentials are required. Keep migrations 010–014 in place; do not roll them back.
