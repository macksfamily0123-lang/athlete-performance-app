# Phase 72.3.90 RC40 — Codespaces Install

1. Upload the RC40 ZIP into `/workspaces/athlete-performance-app`.
2. Run:

```bash
cd /workspaces/athlete-performance-app
```

```bash
unzip -o athlete-performance-app-phase-72-3-90-google-health-fitbit-migration-RC40.zip
```

```bash
rm -rf .next
```

```bash
npm install
```

3. Run the RC40 tracker check:

```bash
npm run test:google-health
```

4. Run TypeScript and production build checks:

```bash
npm run test:typecheck
```

```bash
npm run build
```

5. Start local preview:

```bash
npm run dev -- -H 0.0.0.0 -p 3001
```

## Supabase
RC40 requires migration 011 after migration 010:
`supabase/migrations/011_google_health_fitbit_migration.sql`

Migration 011 only expands the allowed tracker provider values to include `google-health`; it does not recreate the tracker tables or weaken Player/Parent-only privacy.
