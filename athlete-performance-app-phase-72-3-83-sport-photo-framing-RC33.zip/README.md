# Athlete Performance App — Phase 72.3.83 RC33

RC33 is the full combined **Sport Photo Framing** release built on RC32.

The primary change is less aggressive realistic hero-photo cropping. Wide sport photography sits farther back with cinematic edge-fill, while Hockey Player and Hockey Coach receive framing tailored to their source image orientation. This keeps the large premium hero treatment while showing more of each original image and reducing the over-zoomed/pixelated appearance.

All RC32 functionality and prior fixes are included. Migration 009 remains the latest required migration.
