# Install Phase 72.3.83 RC33 in Codespaces

From `/workspaces/athlete-performance-app`:

```bash
unzip -o athlete-performance-app-phase-72-3-83-sport-photo-framing-RC33.zip
```

```bash
rm -rf .next
```

```bash
npm install
```

```bash
npm run test:photo-framing
```

```bash
npm run test:typecheck
```

```bash
npm run dev -- -H 0.0.0.0 -p 3001
```

No new Supabase migration is required.
