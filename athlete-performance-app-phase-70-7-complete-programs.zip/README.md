# Athlete Performance App — Phase 70.7

## Complete Program Generator
- Exercise Access dropdown:
  - Gym Access
  - Body Weight Only
- Every newly generated training day includes:
  - Warm-up
  - Main exercises
  - Sport-specific exercise
  - Finisher when appropriate
  - Cooldown
- Every exercise includes sets, reps/time, rest, and coaching notes.
- Programs still use sport, position, focus, and development priorities.
- Old saved programs remain compatible and can be regenerated for full exercise detail.
- Calendar integration is preserved.

All Phase 70.6 mental preparation, breathing, roster editing, and simplified UI features remain included.
