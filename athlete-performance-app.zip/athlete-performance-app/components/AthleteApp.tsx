"use client";

import { useEffect, useMemo, useState } from "react";

type Sport = "Baseball" | "Football" | "Ice Hockey" | "Basketball" | "Lacrosse" | "Wrestling";
type Goal = { id:number; title:string; sport:Sport; type:"Short-term"|"Long-term"; target:string; due:string; progress:number };
type Workout = { id:number; name:string; sport:Sport; category:string; duration:number; exercises:string[]; completed:boolean; date:string };

const sports: {name:Sport; icon:string; accent:string}[] = [
  {name:"Baseball",icon:"⚾",accent:"baseball"},
  {name:"Football",icon:"🏈",accent:"football"},
  {name:"Ice Hockey",icon:"🏒",accent:"hockey"},
  {name:"Basketball",icon:"🏀",accent:"basketball"},
  {name:"Lacrosse",icon:"🥍",accent:"lacrosse"},
  {name:"Wrestling",icon:"🤼",accent:"wrestling"},
];

const templates: Record<Sport, Workout[]> = {
  Baseball: [
    {id:101,name:"Explosive Baseball",sport:"Baseball",category:"Power",duration:38,exercises:["Medicine-ball rotational throws · 3×8","Lateral bounds · 3×6/side","Split-stance cable press · 3×10","Sprint starts · 6×15 yd"],completed:false,date:""},
    {id:102,name:"Arm Care + Mobility",sport:"Baseball",category:"Mobility",duration:25,exercises:["Band external rotation · 2×15","Scap push-ups · 2×12","Thoracic rotations · 2×10/side","Wrist/finger mobility · 5 min"],completed:false,date:""},
  ],
  Football: [
    {id:201,name:"Football Speed",sport:"Football",category:"Speed",duration:42,exercises:["10 yd acceleration · 6 reps","Flying 20s · 4 reps","Lateral shuffle to sprint · 5/side","Broad jump · 4×4"],completed:false,date:""},
    {id:202,name:"Football Strength",sport:"Football",category:"Strength",duration:50,exercises:["Goblet squat · 4×8","Romanian deadlift · 3×8","Push press · 3×6","Farmer carry · 4×30 yd"],completed:false,date:""},
  ],
  "Ice Hockey": [
    {id:301,name:"Hockey Skating Power",sport:"Ice Hockey",category:"Power",duration:40,exercises:["Lateral bounds · 4×5/side","Single-leg squat · 3×8/side","Copenhagen plank · 3×20 sec/side","Sprint intervals · 8×15 sec"],completed:false,date:""},
    {id:302,name:"Hockey Conditioning",sport:"Ice Hockey",category:"Conditioning",duration:35,exercises:["Bike sprint · 8×20 sec","Easy recovery · 60 sec","Core anti-rotation · 3×10/side","Mobility cooldown · 6 min"],completed:false,date:""},
  ],
  Basketball: [
    {id:401,name:"Basketball Vertical",sport:"Basketball",category:"Jump",duration:35,exercises:["Countermovement jump · 4×5","Pogo jumps · 3×15","Split squat · 3×8/side","Calf raise · 3×15"],completed:false,date:""},
    {id:402,name:"Basketball Change of Direction",sport:"Basketball",category:"Agility",duration:32,exercises:["5-10-5 shuttle · 5 reps","Closeout drill · 6 reps","Lateral bounds · 3×6/side","Defensive slides · 5×20 sec"],completed:false,date:""},
  ],
  Lacrosse: [
    {id:501,name:"Lacrosse Agility",sport:"Lacrosse",category:"Agility",duration:36,exercises:["Cone cuts · 5 reps","Crossover run · 4×20 yd","Reactive shuffle · 6 reps","Sprint deceleration · 5 reps"],completed:false,date:""},
    {id:502,name:"Lacrosse Core + Power",sport:"Lacrosse",category:"Power",duration:40,exercises:["Rotational med-ball throw · 4×6","Landmine rotation · 3×8/side","Push-up · 3×12","Dead bug · 3×10/side"],completed:false,date:""},
  ],
  Wrestling: [
    {id:601,name:"Wrestling Strength",sport:"Wrestling",category:"Strength",duration:48,exercises:["Front squat · 4×6","Pull-up · 4×AMRAP","Turkish get-up · 3×4/side","Bear crawl · 4×20 yd"],completed:false,date:""},
    {id:602,name:"Wrestling Conditioning",sport:"Wrestling",category:"Conditioning",duration:30,exercises:["Assault bike · 6×30 sec","Sprawl intervals · 5×20 sec","Grip carry · 4×30 sec","Mobility cooldown · 5 min"],completed:false,date:""},
  ],
};

const starterGoals: Goal[] = [
  {id:1,title:"Improve first-step speed",sport:"Ice Hockey",type:"Short-term",target:"10-yard sprint ≤ 1.75 sec",due:"Sep 15, 2026",progress:62},
  {id:2,title:"Increase lower-body power",sport:"Ice Hockey",type:"Long-term",target:"Vertical jump +4 inches",due:"Dec 31, 2026",progress:38},
  {id:3,title:"Build consistent training habit",sport:"Ice Hockey",type:"Short-term",target:"4 workouts/week",due:"Sep 30, 2026",progress:75},
];

function today() { return new Date().toISOString().slice(0,10); }

export default function AthleteApp() {
  const [sport,setSport] = useState<Sport>("Ice Hockey");
  const [tab,setTab] = useState<"home"|"goals"|"workouts"|"progress">("home");
  const [goals,setGoals] = useState<Goal[]>(starterGoals);
  const [workouts,setWorkouts] = useState<Workout[]>([]);
  const [showGoal,setShowGoal] = useState(false);
  const [showWorkout,setShowWorkout] = useState(false);
  const [goalTitle,setGoalTitle] = useState("");
  const [goalType,setGoalType] = useState<"Short-term"|"Long-term">("Short-term");
  const [goalTarget,setGoalTarget] = useState("");
  const [goalDue,setGoalDue] = useState("");
  const [workoutName,setWorkoutName] = useState("");
  const [workoutCategory,setWorkoutCategory] = useState("Strength");
  const [workoutDuration,setWorkoutDuration] = useState(30);
  const [workoutExercises,setWorkoutExercises] = useState("");

  useEffect(()=>{
    try {
      const g = localStorage.getItem("ap_goals"); const w = localStorage.getItem("ap_workouts");
      if(g) setGoals(JSON.parse(g)); if(w) setWorkouts(JSON.parse(w));
    } catch {}
  },[]);
  useEffect(()=>{ localStorage.setItem("ap_goals",JSON.stringify(goals)); },[goals]);
  useEffect(()=>{ localStorage.setItem("ap_workouts",JSON.stringify(workouts)); },[workouts]);

  const sportGoals = useMemo(()=>goals.filter(g=>g.sport===sport),[goals,sport]);
  const sportWorkouts = useMemo(()=>workouts.filter(w=>w.sport===sport),[workouts,sport]);
  const completed = sportWorkouts.filter(w=>w.completed).length;
  const weeklyTarget = 4;
  const progressAvg = sportGoals.length ? Math.round(sportGoals.reduce((a,g)=>a+g.progress,0)/sportGoals.length) : 0;

  function addGoal() {
    if(!goalTitle.trim()) return;
    setGoals([{id:Date.now(),title:goalTitle,sport,type:goalType,target:goalTarget || "Set a measurable target",due:goalDue || "No due date",progress:0},...goals]);
    setGoalTitle(""); setGoalTarget(""); setGoalDue(""); setShowGoal(false);
  }
  function addWorkout() {
    if(!workoutName.trim()) return;
    setWorkouts([{id:Date.now(),name:workoutName,sport,category:workoutCategory,duration:Number(workoutDuration),exercises:workoutExercises.split("\n").filter(Boolean),completed:false,date:""},...workouts]);
    setWorkoutName(""); setWorkoutExercises(""); setShowWorkout(false);
  }
  function useTemplate(w:Workout) {
    setWorkouts([{...w,id:Date.now(),date:"",completed:false},...workouts]);
  }
  function toggleWorkout(id:number) {
    setWorkouts(workouts.map(w=>w.id===id?{...w,completed:!w.completed,date:!w.completed?today():""}:w));
  }
  function updateGoal(id:number, p:number) {
    setGoals(goals.map(g=>g.id===id?{...g,progress:Math.max(0,Math.min(100,p))}:g));
  }

  return <div className="app-shell">
    <header className="topbar">
      <div className="brand"><div className="brand-mark">AP</div><div><b>Athlete Performance</b><span>Train with purpose.</span></div></div>
      <button className="profile">AM</button>
    </header>

    <main>
      <section className="sport-strip">
        <div className="eyebrow">MY SPORT</div>
        <div className="sport-scroll">{sports.map(s=><button key={s.name} className={`sport-pill ${sport===s.name?"selected":""}`} onClick={()=>setSport(s.name)}><span>{s.icon}</span>{s.name}</button>)}</div>
      </section>

      {tab==="home" && <Home sport={sport} goals={sportGoals} workouts={sportWorkouts} progressAvg={progressAvg} completed={completed} weeklyTarget={weeklyTarget} onGoals={()=>setTab("goals")} onWorkouts={()=>setTab("workouts")} onComplete={toggleWorkout} />}
      {tab==="goals" && <Goals goals={sportGoals} sport={sport} onAdd={()=>setShowGoal(true)} onUpdate={updateGoal} />}
      {tab==="workouts" && <Workouts sport={sport} workouts={sportWorkouts} onAdd={()=>setShowWorkout(true)} onTemplate={useTemplate} onComplete={toggleWorkout} />}
      {tab==="progress" && <Progress sport={sport} goals={sportGoals} workouts={sportWorkouts} />}

    </main>

    <nav className="bottom-nav">
      {([["home","⌂","Home"],["goals","◎","Goals"],["workouts","◆","Workouts"],["progress","↗","Progress"]] as const).map(([id,icon,label])=><button key={id} className={tab===id?"active":""} onClick={()=>setTab(id)}><span>{icon}</span>{label}</button>)}
    </nav>

    {showGoal && <Modal title="Create a goal" close={()=>setShowGoal(false)}>
      <label>Goal name<input value={goalTitle} onChange={e=>setGoalTitle(e.target.value)} placeholder="e.g. Improve skating acceleration"/></label>
      <label>Goal type<select value={goalType} onChange={e=>setGoalType(e.target.value as any)}><option>Short-term</option><option>Long-term</option></select></label>
      <label>Measurable target<input value={goalTarget} onChange={e=>setGoalTarget(e.target.value)} placeholder="e.g. 10-yard sprint ≤ 1.75 sec"/></label>
      <label>Due date<input type="date" value={goalDue} onChange={e=>setGoalDue(e.target.value)}/></label>
      <button className="primary full" onClick={addGoal}>Save goal</button>
    </Modal>}

    {showWorkout && <Modal title={`Create ${sport} workout`} close={()=>setShowWorkout(false)}>
      <label>Workout name<input value={workoutName} onChange={e=>setWorkoutName(e.target.value)} placeholder="e.g. Speed & Power"/></label>
      <label>Category<select value={workoutCategory} onChange={e=>setWorkoutCategory(e.target.value)}><option>Strength</option><option>Speed</option><option>Power</option><option>Agility</option><option>Conditioning</option><option>Mobility</option><option>Recovery</option></select></label>
      <label>Duration (minutes)<input type="number" min="5" value={workoutDuration} onChange={e=>setWorkoutDuration(Number(e.target.value))}/></label>
      <label>Exercises — one per line<textarea value={workoutExercises} onChange={e=>setWorkoutExercises(e.target.value)} placeholder={"Exercise · sets × reps\nExercise · sets × reps"}/></label>
      <button className="primary full" onClick={addWorkout}>Save workout</button>
    </Modal>}
  </div>
}

function Home({sport,goals,workouts,progressAvg,completed,weeklyTarget,onGoals,onWorkouts,onComplete}:{sport:Sport;goals:Goal[];workouts:Workout[];progressAvg:number;completed:number;weeklyTarget:number;onGoals:()=>void;onWorkouts:()=>void;onComplete:(id:number)=>void}) {
  return <div className="page">
    <div className="hero"><div><div className="eyebrow">YOUR PERFORMANCE PLAN</div><h1>{sport} <span>Dashboard</span></h1><p>Small improvements today become big performance gains later.</p></div><div className="hero-score"><b>{progressAvg}%</b><span>goal progress</span></div></div>
    <div className="stats"><Stat label="Goal progress" value={`${progressAvg}%`} /><Stat label="Workouts this week" value={`${completed}/${weeklyTarget}`} /><Stat label="Active goals" value={`${goals.length}`} /><Stat label="Training streak" value="6 days" /></div>
    <div className="section-head"><h2>Next up</h2><button onClick={onWorkouts}>See all</button></div>
    {workouts.length===0 ? <Empty text="No workouts yet. Add a sport-specific workout or use a template."/> : <div className="workout-card"><div className="workout-top"><div><span className="tag">{workouts[0].category}</span><h3>{workouts[0].name}</h3></div><b>{workouts[0].duration} min</b></div><ul>{workouts[0].exercises.slice(0,3).map((e,i)=><li key={i}>{e}</li>)}</ul><button className={`primary full ${workouts[0].completed?"done":""}`} onClick={()=>onComplete(workouts[0].id)}>{workouts[0].completed?"Completed ✓":"Mark workout complete"}</button></div>}
    <div className="section-head"><h2>Goals</h2><button onClick={onGoals}>Manage</button></div>
    <div className="goal-list">{goals.slice(0,3).map(g=><div className="goal-mini" key={g.id}><div><span className={`tag ${g.type==="Long-term"?"long":""}`}>{g.type}</span><h3>{g.title}</h3><small>{g.target}</small></div><div className="ring">{g.progress}%</div></div>)}</div>
  </div>
}

function Goals({goals,sport,onAdd,onUpdate}:{goals:Goal[];sport:Sport;onAdd:()=>void;onUpdate:(id:number,p:number)=>void}) {
  return <div className="page"><div className="page-title"><div><div className="eyebrow">{sport}</div><h1>Goals</h1></div><button className="primary" onClick={onAdd}>+ Add goal</button></div>
    <div className="goal-tabs"><span className="active">All</span><span>Short-term</span><span>Long-term</span></div>
    {goals.length===0?<Empty text="Create your first measurable goal."/>:goals.map(g=><div className="goal-card" key={g.id}><div className="goal-card-head"><div><span className={`tag ${g.type==="Long-term"?"long":""}`}>{g.type}</span><h2>{g.title}</h2><p>{g.target}</p></div><b>{g.progress}%</b></div><input className="range" type="range" min="0" max="100" value={g.progress} onChange={e=>onUpdate(g.id,Number(e.target.value))}/><div className="progress-meta"><span>Progress</span><span>Due {g.due}</span></div></div>)}
  </div>
}

function Workouts({sport,workouts,onAdd,onTemplate,onComplete}:{sport:Sport;workouts:Workout[];onAdd:()=>void;onTemplate:(w:Workout)=>void;onComplete:(id:number)=>void}) {
  return <div className="page"><div className="page-title"><div><div className="eyebrow">{sport}</div><h1>Workouts</h1></div><button className="primary" onClick={onAdd}>+ Create</button></div>
    <h2>Recommended for you</h2><div className="template-grid">{templates[sport].map(w=><div className="template" key={w.id}><span className="tag">{w.category}</span><h3>{w.name}</h3><p>{w.duration} min · {w.exercises.length} exercises</p><button className="secondary full" onClick={()=>onTemplate(w)}>Add to my workouts</button></div>)}</div>
    <div className="section-head"><h2>My workouts</h2></div>
    {workouts.length===0?<Empty text="Your saved workouts will appear here."/>:<div className="workout-stack">{workouts.map(w=><div className="saved-workout" key={w.id}><div><span className="tag">{w.category}</span><h3>{w.name}</h3><p>{w.duration} minutes</p></div><button className={`check ${w.completed?"checked":""}`} onClick={()=>onComplete(w.id)}>{w.completed?"✓":"○"}</button></div>)}</div>}
  </div>
}

function Progress({sport,goals,workouts}:{sport:Sport;goals:Goal[];workouts:Workout[]}) {
  const done=workouts.filter(w=>w.completed).length; const avg=goals.length?Math.round(goals.reduce((a,g)=>a+g.progress,0)/goals.length):0;
  return <div className="page"><div className="page-title"><div><div className="eyebrow">{sport}</div><h1>Progress</h1></div></div>
    <div className="progress-hero"><div><span>Overall goal progress</span><strong>{avg}%</strong></div><div className="big-bar"><i style={{width:`${avg}%`}}/></div></div>
    <div className="stats"><Stat label="Workouts completed" value={`${done}`} /><Stat label="Active goals" value={`${goals.length}`} /><Stat label="Avg. goal progress" value={`${avg}%`} /></div>
    <h2>Performance habits</h2><div className="habit"><span>Training consistency</span><b>Strong</b><div className="mini-bars">{[72,88,62,95,80,100,75].map((v,i)=><i key={i} style={{height:`${v}%`}}/>)}</div></div>
    <div className="note"><b>Coach insight</b><p>Keep building consistency. Your best results come from matching sport-specific training with measurable goals and recovery.</p></div>
  </div>
}

function Stat({label,value}:{label:string;value:string}) { return <div className="stat"><span>{label}</span><b>{value}</b></div> }
function Empty({text}:{text:string}) { return <div className="empty"><div>◎</div><p>{text}</p></div> }
function Modal({title,close,children}:{title:string;close:()=>void;children:React.ReactNode}) { return <div className="overlay"><div className="modal"><div className="modal-head"><h2>{title}</h2><button onClick={close}>×</button></div>{children}</div></div> }
