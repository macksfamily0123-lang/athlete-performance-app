import "./globals.css";

export const metadata = {
  title: "Athlete Performance",
  description: "Goals, workouts, progress and sport performance tracking",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}