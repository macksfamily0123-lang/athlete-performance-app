import AthleteApp from "../components/AthleteApp";

export default function Home() {
  return <AthleteApp />;
}