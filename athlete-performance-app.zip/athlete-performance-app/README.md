# Athlete Performance App

A mobile-first training app for Baseball, Football, Ice Hockey, Basketball, Lacrosse, and Wrestling.

## Included
- Sport selector
- Athlete dashboard
- Short-term and long-term goals
- Measurable targets and progress sliders
- Sport-specific workout templates
- Create custom workouts
- Mark workouts complete
- Progress dashboard
- Local persistence with browser localStorage
- Responsive mobile navigation

## Run
1. Open a terminal in this folder.
2. Run `npm install`
3. Run `npm run dev`
4. Open the URL shown by Next.js.

This version intentionally works without Supabase so it is easier to get running first. Data is saved in the browser on the device. A future production phase can replace localStorage with Supabase authentication/database without changing the main user experience.
