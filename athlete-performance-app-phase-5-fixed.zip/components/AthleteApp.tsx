
"use client";
import {useEffect,useMemo,useState} from "react";
type Sport="Baseball"|"Football"|"Ice Hockey"|"Basketball"|"Lacrosse"|"Wrestling";
type TestDef={id:string;name:string;category:string;unit:string;lowerBetter:boolean};
type Result={id:number;testId:string;name:string;category:string;unit:string;value:number;date:string;sport:Sport};
type Goal={id:number;title:string;progress:number;type:"Short-term"|"Long-term"};
type Session={id:number;date:string;name:string;minutes:number;completed:boolean;sport:Sport};
type CustomTest=TestDef&{sport:Sport};
const sports:Sport[]=["Baseball","Football","Ice Hockey","Basketball","Lacrosse","Wrestling"];
const defs:Record<Sport,TestDef[]>={
Baseball:[["10-yard sprint","Speed","sec",1],["20-yard sprint","Speed","sec",1],["5-10-5 shuttle","Agility","sec",1],["Vertical jump","Power","in",0],["Broad jump","Power","in",0],["Bench press","Strength","lb",0]],
Football:[["10-yard sprint","Speed","sec",1],["40-yard sprint","Speed","sec",1],["5-10-5 shuttle","Agility","sec",1],["Vertical jump","Power","in",0],["Broad jump","Power","in",0],["Bench press","Strength","lb",0],["Squat","Strength","lb",0]],
"Ice Hockey":[["10-yard sprint","Speed","sec",1],["20-yard sprint","Speed","sec",1],["Pro agility shuttle","Agility","sec",1],["Vertical jump","Power","in",0],["Broad jump","Power","in",0],["Squat","Strength","lb",0]],
Basketball:[["10-yard sprint","Speed","sec",1],["Lane agility","Agility","sec",1],["Vertical jump","Power","in",0],["Broad jump","Power","in",0],["Squat","Strength","lb",0]],
Lacrosse:[["20-yard sprint","Speed","sec",1],["Pro agility shuttle","Agility","sec",1],["Vertical jump","Power","in",0],["Broad jump","Power","in",0],["Bench press","Strength","lb",0]],
Wrestling:[["20-yard sprint","Speed","sec",1],["5-10-5 shuttle","Agility","sec",1],["Vertical jump","Power","in",0],["Broad jump","Power","in",0],["Squat","Strength","lb",0],["Pull-ups","Strength","reps",0]]
};
function makeDefs(s:Sport){return defs[s].map((x,i)=>({id:s.toLowerCase().replace(" ","-")+"-"+i,name:x[0],category:x[1],unit:x[2],lowerBetter:!!x[3]}))}
function today(){return new Date().toISOString().slice(0,10)}
function pct(a:number,b:number,lower:boolean){if(!b)return 0;return Math.round(((lower?a/b:b/a)-1)*100)}
export default function AthleteApp(){
 const [sport,setSport]=useState<Sport>("Ice Hockey"),[tab,setTab]=useState("Testing");
 const [results,setResults]=useState<Result[]>([]),[custom,setCustom]=useState<CustomTest[]>([]),[goals,setGoals]=useState<Goal[]>([]),[sessions,setSessions]=useState<Session[]>([]);
 useEffect(()=>{for(const [k,set] of [["results",setResults],["custom",setCustom],["goals",setGoals],["sessions",setSessions]] as any[]){try{const v=localStorage.getItem(k);if(v)set(JSON.parse(v))}catch{}}},[]);
 useEffect(()=>localStorage.setItem("results",JSON.stringify(results)),[results]);
 useEffect(()=>localStorage.setItem("custom",JSON.stringify(custom)),[custom]);
 useEffect(()=>localStorage.setItem("goals",JSON.stringify(goals)),[goals]);
 useEffect(()=>localStorage.setItem("sessions",JSON.stringify(sessions)),[sessions]);
 const library=[...makeDefs(sport),...custom.filter(x=>x.sport===sport)];
 return <div className="app"><header><b>AP</b><div><strong>Athlete Performance</strong><small>Train with purpose.</small></div></header>
 <main><div className="sports">{sports.map(s=><button className={sport===s?"sel":""} onClick={()=>setSport(s)} key={s}>{s}</button>)}</div>
 {tab==="Testing"&&<Testing sport={sport} library={library} results={results} setResults={setResults} custom={custom} setCustom={setCustom}/>}
 {tab==="Analytics"&&<Analytics sport={sport} results={results} goals={goals} sessions={sessions}/>}
 {tab==="Goals"&&<Goals goals={goals} setGoals={setGoals}/>}
 {tab==="Plan"&&<Plan sport={sport} sessions={sessions} setSessions={setSessions}/>}
 </main><nav>{["Testing","Goals","Plan","Analytics"].map(x=><button className={tab===x?"active":""} onClick={()=>setTab(x)} key={x}>{x}</button>)}</nav></div>
}
function Testing({sport,library,results,setResults,custom,setCustom}:{sport:Sport;library:TestDef[];results:Result[];setResults:any;custom:CustomTest[];setCustom:any}){
 const [id,setId]=useState(library[0]?.id||""),[value,setValue]=useState(""),[open,setOpen]=useState(false),[name,setName]=useState(""),[cat,setCat]=useState("Performance"),[unit,setUnit]=useState(""),[lower,setLower]=useState(true);
 useEffect(()=>{if(!library.some(x=>x.id===id))setId(library[0]?.id||"")},[sport,custom]);
 const t=library.find(x=>x.id===id),rows=results.filter(x=>x.sport===sport);
 return <><h1>Performance Testing</h1><div className="card"><label>Test Name<select value={id} onChange={e=>e.target.value==="custom"?setOpen(true):setId(e.target.value)}>{library.map(x=><option key={x.id} value={x.id}>{x.name}</option>)}<option value="custom">＋ Create Custom Test</option></select></label>
 {t&&<p>{t.category} · {t.unit} · {t.lowerBetter?"Lower is better":"Higher is better"}</p>}
 <label>Result<input inputMode="decimal" value={value} onChange={e=>setValue(e.target.value)}/></label><button className="primary" disabled={!t} onClick={()=>{if(t&&value.trim()&&!isNaN(Number(value)))setResults((r:Result[])=>[{id:Date.now(),testId:t.id,name:t.name,category:t.category,unit:t.unit,value:Number(value),date:today(),sport},...r])}}>Save Result</button></div>
 {rows.map(r=><div className="card row" key={r.id}><span>{r.name}<small>{r.date}</small></span><b>{r.value} {r.unit}</b></div>)}
 {open&&<div className="overlay"><div className="modal"><h2>Create Custom Test</h2><label>Test name<input value={name} onChange={e=>setName(e.target.value)}/></label><label>Category<input value={cat} onChange={e=>setCat(e.target.value)}/></label><label>Unit<input value={unit} onChange={e=>setUnit(e.target.value)} placeholder="mph, sec, lb..."/></label><label>Better result<select value={lower?"lower":"higher"} onChange={e=>setLower(e.target.value==="lower")}><option value="lower">Lower is better</option><option value="higher">Higher is better</option></select></label><button className="primary" onClick={()=>{if(name.trim()&&unit.trim()){const x={id:"custom-"+Date.now(),name:name.trim(),category:cat||"Performance",unit:unit.trim(),lowerBetter:lower,sport};setCustom((c:CustomTest[])=>[...c,x]);setId(x.id);setOpen(false);setName("");setUnit("")}}}>Save Custom Test</button><button onClick={()=>setOpen(false)}>Cancel</button></div></div>}</>
}
function Analytics({sport,results,goals,sessions}:{sport:Sport;results:Result[];goals:Goal[];sessions:Session[]}){const [range,setRange]=useState("all");const cutoff=range==="all"?0:Date.now()-Number(range)*86400000;const rows=results.filter(r=>r.sport===sport&&new Date(r.date).getTime()>=cutoff);const groups=[...new Map(rows.map(r=>[r.testId,r])).values()];const goal=goals.length?Math.round(goals.reduce((a,g)=>a+g.progress,0)/goals.length):0;const ss=sessions.filter(s=>s.sport===sport),done=ss.filter(s=>s.completed).length;const consistency=ss.length?Math.round(done/ss.length*100):0;const score=Math.round(goal*.4+consistency*.3+(groups.length?30:0));return <><h1>Analytics</h1><div className="filters">{["30","90","365","all"].map(x=><button className={range===x?"sel":""} onClick={()=>setRange(x)} key={x}>{x==="all"?"All":x+"D"}</button>)}</div><div className="score"><small>ATHLETE PERFORMANCE SCORE</small><strong>{score}</strong><span>/100</span></div><div className="card"><h2>Personal Records & Trends</h2>{groups.length?groups.map(g=>{const r=rows.filter(x=>x.testId===g.testId).sort((a,b)=>a.date.localeCompare(b.date));const d=makeDefs(sport).find(x=>x.id===g.testId)||{lowerBetter:g.unit==="sec"} as any;const best=r.reduce((a,b)=>d.lowerBetter?Math.min(a,b.value):Math.max(a,b.value),r[0].value);const latest=r[r.length-1].value;const imp=r.length>1?pct(r[r.length-2].value,latest,d.lowerBetter):0;return <div className="record" key={g.testId}><div className="row"><b>{g.name}</b><strong className="good">{r.length>1?(imp>=0?"+":"")+imp+"%":"New"}</strong></div><small>{r.length} results · Best {best} {g.unit} · Latest {latest} {g.unit}</small><div className="spark">{r.map(v=><i key={v.id}/>)}</div></div>}):<p>Record the same test more than once to see a trend.</p>}</div><div className="grid"><div className="card"><h2>Goals</h2><b className="big">{goal}%</b></div><div className="card"><h2>Training</h2><b className="big">{consistency}%</b></div></div></>}
function Goals({goals,setGoals}:{goals:Goal[];setGoals:any}){const [t,setT]=useState("");return <><h1>Goals</h1><div className="card"><input value={t} onChange={e=>setT(e.target.value)} placeholder="New goal"/><button className="primary" onClick={()=>{if(t){setGoals((g:Goal[])=>[{id:Date.now(),title:t,progress:0,type:"Short-term"},...g]);setT("")}}}>Add Goal</button></div>{goals.map(g=><div className="card" key={g.id}><b>{g.title}</b><input type="range" value={g.progress} onChange={e=>setGoals((x:Goal[])=>x.map(a=>a.id===g.id?{...a,progress:+e.target.value}:a))}/><small>{g.progress}%</small></div>)}</>}
function Plan({sport,sessions,setSessions}:{sport:Sport;sessions:Session[];setSessions:any}){const [name,setName]=useState("Sport Workout");return <><h1>Training Plan</h1><div className="card"><input value={name} onChange={e=>setName(e.target.value)}/><button className="primary" onClick={()=>setSessions((x:Session[])=>[{id:Date.now(),date:today(),name,minutes:45,completed:false,sport},...x])}>Add Workout</button></div>{sessions.filter(x=>x.sport===sport).map(s=><div className="card row" key={s.id}><span>{s.name}<small>{s.date} · {s.minutes} min</small></span><button onClick={()=>setSessions((x:Session[])=>x.map(a=>a.id===s.id?{...a,completed:!a.completed}:a))}>{s.completed?"✓ Done":"Complete"}</button></div>)}</>}
