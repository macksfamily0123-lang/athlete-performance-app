# Athlete Performance App — Phase 70.9 Exercise Visual Library

Every generated exercise now includes a Show Exercise control.

- Opens an in-app movement illustration.
- Common exercises have tailored movement diagrams.
- Sprint, strength, mobility, conditioning, reaction, footwork, and core patterns are covered.
- Dynamic sport-specific drills use a sport-drill visual fallback, so every generated exercise has a visual.
- Written How instructions, sets, reps/time, and rest remain visible.
- No external links are required, so the visual help works without relying on third-party image URLs.

All Phase 70.8 features remain preserved.
