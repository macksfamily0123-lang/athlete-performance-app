# Phase 72.3.76 RC26 — Performance OS Redesign

RC26 is a full-app visual-system rebuild on top of Phase 72.3.75 RC25.

## Goal
Move the product away from the repeated rounded-card / generic AI-dashboard look and toward a custom high-end sports performance product.

## What changed
- Performance OS root design system applied app-wide.
- Sharper 0–4 px geometry replaces most rounded cards, tabs, controls, sheets, and data panels.
- Home photography is full-bleed and hard-edged.
- Player Home reads as one editorial performance flow rather than a stack of tiles.
- Readiness remains circular because the circle communicates progress; avatars remain circular because they represent people.
- Goals, testing, schedule, roster, development, analytics, and other content areas use flatter rows and ruled sections.
- Coach Home is treated as a tactical command board.
- Parent Home is treated as a support timeline.
- Admin Home is treated as an operations console.
- Junior remains more approachable but uses fewer floating cards.
- Primary CTAs use a custom clipped sports geometry.
- Bottom navigation is integrated into the screen edge instead of floating as a rounded dock.
- Modal behavior from RC25 remains intact, with a sharper sheet treatment.
- Dedicated mobile treatment for narrow 360–430 px screens is included.

## Preserved
- Supabase integration
- Roles and permissions
- Junior mode
- Player More fix
- Cloud test athletes
- Player photos and initials fallback
- Realistic non-Junior sport imagery for all supported sports
- Parent / Coach / Admin flows
- Smooth Readiness ring
- Migration 009 unchanged

No new Supabase migration is required.

## Verification
Run:

```bash
npm run test:performance-os
```

Then:

```bash
npm run test:typecheck
```

The dependency-backed TypeScript / Next.js build should be verified in Codespaces after `npm install`.
