# Phase 70.12 — Readability + Mental Prep Reminder

- Increased exercise names, instructions, sub-exercise text, doses, and resource-link text.
- Mobile exercise text is enlarged further for easier reading.
- Every generated daily workout now starts with a prominent Mental Preparation & Breathing reminder.
- Reminder sequence:
  1. Settle attention / mental preparation.
  2. Reilly Rescue Breathing — 6–10 rounds.
  3. Box Breathing — 6–10 rounds.
- Existing program, exercise guides, video/photo links, roster, analytics, and development features are preserved.
