# Install Phase 72.3.69 RC19 in Codespaces

From `/workspaces/athlete-performance-app`:

```bash
unzip -o athlete-performance-app-phase-72-3-69-realistic-all-sports-RC19.zip
```

```bash
rm -rf .next
```

```bash
npm install
```

```bash
npm run test:realistic-all-sports
```

```bash
npm run dev
```

No new Supabase migration is required. Migration 009 remains unchanged.
