# Phase 72.3.69 RC19 — Realistic All-Sport Headers

Baseline: Phase 72.3.68 RC18, itself built from completed Phase 72.3.64 RC15.

## New in RC19
- Non-Junior hero imagery is now realistic for all 8 supported sports:
  Baseball, Football, Ice Hockey, Basketball, Lacrosse, Wrestling, Soccer, Figure Skating.
- The selected athlete's Player Profile Sport remains authoritative.
- Junior Player mode intentionally keeps the simpler sport graphics for now.
- Hockey Coach retains the dedicated realistic coach/team scene.
- Player, Parent, Admin, and non-Junior selected-athlete views receive the realistic sport scene.
- Added `npm run test:realistic-all-sports`.

## Preserved
- Supabase integration.
- Roles and permissions.
- Junior mode.
- Player More navigation fix.
- Cloud test athletes.
- Parent/Coach connection flows.
- Player photos.
- Migration 009 unchanged.
