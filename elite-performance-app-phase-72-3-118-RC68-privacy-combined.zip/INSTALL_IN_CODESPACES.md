# RC68 installation in your existing Codespace

Download and upload `elite-performance-app-phase-72-3-118-RC68-privacy-combined.zip` into the app folder. Use this complete ZIP; preserve `.env.local`. Stop the old preview with Ctrl+C. Run each command separately.

```bash
cd /workspaces/athlete-performance-app
```

Check and save any changes you want to retain before extracting:

```bash
git status
```

Create a review branch:

```bash
git switch -c release/rc68-parent-privacy
```

Extract:

```bash
unzip -o elite-performance-app-phase-72-3-118-RC68-privacy-combined.zip
```

Clear generated build files:

```bash
rm -rf .next
```

```bash
npm install
```

```bash
npm run test:typecheck
```

```bash
npm test
```

```bash
npm run build
```

Before using real accounts, follow SUPABASE_SETUP.md for migration 017, the deletion function and the additional public privacy variables. Keep the existing Supabase URL and anon key. New privacy authorization fails closed when migration 017 is missing.

Start the preview:

```bash
npm run dev -- --hostname 0.0.0.0 --port 3001
```

Open forwarded port 3001. Confirm RC68 · v72.3.118. Test with dedicated accounts before inviting families. Under-18 privacy approval is separate from Junior Mode. Existing minor or unknown-age records need verified guardian authorization; they are not silently approved by this update.
