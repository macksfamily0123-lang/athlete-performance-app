# RC68 Vercel deployment

Use your existing Vercel project and Supabase project. First apply migration 017 and deploy the deletion Edge Function using SUPABASE_SETUP.md.

Keep these existing variables in Preview and Production:

```text
NEXT_PUBLIC_SUPABASE_URL
```

```text
NEXT_PUBLIC_SUPABASE_ANON_KEY
```

Add these in both environments, and in the existing Codespace `.env.local`:

```text
NEXT_PUBLIC_PRIVACY_OPERATOR_NAME
```

Value: your actual business/operator name.

```text
NEXT_PUBLIC_PRIVACY_CONTACT_EMAIL
```

Value: an actual monitored privacy email address.

```text
NEXT_PUBLIC_PRIVACY_RETENTION_NOTE
```

Value: the actual active-record, verification-evidence and backup retention schedule you have verified with your providers. Do not enter a promise the service cannot meet. Missing contact or retention configuration blocks notice acceptance and new registration.

Run these from `/workspaces/athlete-performance-app`, one at a time:

```bash
npx vercel login
```

```bash
npx vercel link
```

Choose your existing account and project. Code directory: `./`. Framework: Next.js. Build: `npm run build`. Output directory: Next.js default.

Deploy a preview:

```bash
npx vercel
```

Add that exact origin to the Edge Function origin allowlist if testing account deletion there. Verify login, terms, Admin authenticator, reviewed guardian approval, authorization, linked-parent controls, Coach revocation and deletion using dedicated test accounts. Check /privacy and /terms for your actual contact and retention text. Supabase email redirect URLs must allow the preview if email callbacks are used.

When the preview and backend checks pass, deploy production:

```bash
npx vercel --prod
```

Alternatively merge the reviewed branch into the production branch of the existing Git-connected Vercel project. Do not deploy both independently without checking which commit is live. Close and reopen installed app clients and clear old device data when upgrading from RC67. No live deployment was performed while building this ZIP.
