import "./globals.css";
export const metadata={title:"Athlete Performance",description:"Goals, workouts, testing and training calendar"};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}