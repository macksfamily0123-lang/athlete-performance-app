# Phase 72.3.92 RC42 — Codespaces Install

RC42 is a full release containing RC41/RC40 and all prior functionality.

1. Upload the RC42 ZIP into `/workspaces/athlete-performance-app`.

```bash
cd /workspaces/athlete-performance-app
```

```bash
unzip -o athlete-performance-app-phase-72-3-92-clear-tracker-connect-RC42.zip
```

```bash
rm -rf .next
```

```bash
npm install
```

Run the new tracker connection UX check:

```bash
npm run test:tracker-connect-ux
```

Expected: `PASS: 13/13 RC42 Tracker Connection UX checks.`

Then run:

```bash
npm run test:google-health
```

```bash
npm run test:typecheck
```

Start the app:

```bash
npm run dev -- -H 0.0.0.0 -p 3001
```

## Supabase
No new migration is required for RC42. Migrations 010 and 011 remain unchanged and should already be installed.
