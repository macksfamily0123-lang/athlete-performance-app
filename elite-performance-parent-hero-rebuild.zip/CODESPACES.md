# Codespaces: update your existing app

Upload elite-performance-parent-hero-rebuild.zip into the repository through Explorer. It can be in the root, components or supabase folder. From /workspaces/athlete-performance-app, paste each box separately.

```bash
unzip -q "$(find . -maxdepth 3 -name 'elite-performance-parent-hero-rebuild.zip' -print -quit)" -d elite-parent-hero-update
```

```bash
python3 elite-parent-hero-update/INSTALL_UPDATE.py
```

If the installer reports Source changed, stop. It has changed nothing. Send the error instead of forcing an overwrite.

```bash
npm install
```

```bash
npm test
```

```bash
npm run build
```

The installer keeps backups of the three replaced files inside the extracted update folder. Do not commit the ZIP, extracted source, backups, environment files, or generated files. Follow GIT_PUSH.md's explicit file list.
