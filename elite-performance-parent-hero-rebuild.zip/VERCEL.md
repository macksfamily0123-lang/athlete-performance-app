# Vercel

1. The Git push triggers a Preview deployment in athlete-development-app. Wait for Ready for commit "Rebuild Parent hero with content-sized responsive layout".
2. Open that exact preview; older deployment URLs do not update. Test Parent Overview at phone and desktop widths. If your phone cannot access the protected Preview, open the preview on your Chromebook and use Chrome's device toolbar: press Ctrl+Shift+I, then Ctrl+Shift+M, select a responsive width of 390. Do not disable deployment protection just for this check.
3. Verify complete name, subtitle, team/position labels, full readiness ring, full-panel image, and no sideways scrolling. Add/remove a nonpersonal test Player photo and refresh to spot-check persistence.
4. Once satisfied, open the new GitHub PR and click Merge pull request, then Confirm merge.
5. In Vercel Deployments, wait for the resulting main Production deployment to show Ready.
6. Open https://athlete-development-app.vercel.app directly in Chrome on the Android phone. Refresh and confirm the same layout. The installed app may still display an older cached page; close it and reopen after verifying Chrome.

No environment variable, domain, sender, or Supabase credential changes are required.

Optional Codespaces local phone-layout inspection:

```bash
npm run dev -- --hostname 0.0.0.0
```

Open port 3000 in the Codespaces Ports panel, then use Chrome's device toolbar. This uses your existing environment settings.
