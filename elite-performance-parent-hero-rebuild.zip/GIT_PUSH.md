# Git push

After installation and checks succeed, run each separately in Codespaces:

```bash
git switch -c fix/parent-hero-rebuild
```

```bash
git add components/AthleteApp.tsx app/globals.css app/redesign.css
```

```bash
git commit -m "Rebuild Parent hero with content-sized responsive layout"
```

```bash
git push -u origin fix/parent-hero-rebuild
```

On GitHub, create a pull request comparing fix/parent-hero-rebuild into main. If your previous fix/parent-profile-photo PR is still open, this branch includes its committed changes from the uploaded source; use the new PR for the combined result. Review the diff before merging.
