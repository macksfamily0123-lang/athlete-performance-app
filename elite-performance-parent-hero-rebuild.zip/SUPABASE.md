# Supabase

No SQL needs to be run for this layout rebuild. Migrations 001–019 are identical to the uploaded current source. You already confirmed migration 019 succeeded.

Keep your existing Supabase project, environment values, email sender, deployed privacy functions and secrets. Do not rerun older migrations, reset the database, or enable the inactivity deletion schedule as part of this update. The schedule remains a separate unfinished setup task.
