from pathlib import Path
import hashlib,json,shutil,sys
from datetime import datetime
bundle=Path(__file__).resolve().parent
repo=Path.cwd()
if not (repo/'components/AthleteApp.tsx').is_file() or not (repo/'package.json').is_file():
 sys.exit('Run this installer from /workspaces/athlete-performance-app, not from the update folder.')
manifest=json.loads((bundle/'manifest.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
errors=[]
for rel,record in manifest.items():
 payload=bundle/'source'/rel;target=repo/rel
 if sha(payload)!=record['after']:errors.append('Damaged ZIP source: '+rel)
 if not target.is_file() or sha(target) not in [record['before'],record['after']]:errors.append('Source changed: '+rel)
if errors:sys.exit('\n'.join(errors)+'\nNo files were changed. Send this message to ChatGPT; do not force the installation.')
backup=bundle/'backups'/datetime.now().strftime('%Y%m%d-%H%M%S')
for rel,record in manifest.items():
 target=repo/rel
 if sha(target)==record['after']:
  print('Already installed: '+rel);continue
 saved=backup/rel;saved.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(target,saved)
 shutil.copyfile(bundle/'source'/rel,target);print('Updated: '+rel)
print('Installed. Supabase migrations, permissions, environment files and account data are unchanged.')
