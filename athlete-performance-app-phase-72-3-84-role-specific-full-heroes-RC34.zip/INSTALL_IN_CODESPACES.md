# Phase 72.3.84 RC34 — Codespaces Install

```bash
cd /workspaces/athlete-performance-app
```

```bash
unzip -o athlete-performance-app-phase-72-3-84-role-specific-full-heroes-RC34.zip
```

```bash
rm -rf .next
```

```bash
npm install
```

```bash
npm run test:role-specific-hero
```

```bash
npm run test:typecheck
```

```bash
npm run dev -- -H 0.0.0.0 -p 3001
```
