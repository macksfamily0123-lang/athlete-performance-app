# Phase 72.3.84 RC34 — Role-Specific Full Hero Photography

- Distinct Ice Hockey Player / Parent / Coach hero photography.
- Full-image foreground + full-bleed backdrop treatment for realistic heroes.
- Reduces over-cropping while still filling the complete hero region.
- Preserves RC33 sport-photo framing, RC32 professional athletic system, RC31 recovery/progress improvements, and all prior Supabase/role/Junior/cloud-athlete fixes.
- No new Supabase migration; migration 009 unchanged.

# Phase 72.3.83 RC33 — Sport Photo Framing

Full combined release based on **Phase 72.3.82 RC32 — Professional Athletic System**.

## RC33 visual correction
- Zooms realistic sport background photography out instead of forcing every image through aggressive `cover` scaling.
- Landscape sport images now use inset framing with dark cinematic edge-fill.
- Ice Hockey Player uses portrait-specific framing.
- Ice Hockey Coach uses wide-asset-specific framing.
- Phone and small-phone breakpoints show progressively more of the original photograph.
- Junior illustrated sport headers remain unchanged.

## Preserved visual milestones
- Phase 72.3.82 RC32 Professional Athletic System, including the wide 1600×900 Coach asset and explicit Player Home Progress labeling.
- RC31 Elite Home / Goals / Recovery refinements, including Recovery Tips on Player Home.
- RC30 Elite Performance Visual System.
- RC29 Coach/Roster action fixes.

## Preserved functionality
Persistent navigation, centered setup modal, roles/permissions, Junior mode, Player More, cloud test athletes, player photos, all-sport imagery, Parent/Coach/Admin workflows and Supabase integration remain included.

**Migration 009 remains unchanged and is still the latest required migration.**

Compatibility notes: the wide 1600×900 asset remains included, and migration 009 remains the latest required migration.
