# Athlete Performance App — Phase 70.1 Aesthetic Refresh

Built from the verified Phase 70 setup-link build.

Visual upgrades:
- Deeper athletic dark theme
- Refined glass header and context bar
- More dimensional hero panels
- Improved cards, stat tiles, shadows, and gradients
- Enhanced progress bars and primary actions
- Refined bottom navigation
- Better forms and input focus states
- Stronger onboarding and dashboard presentation
- Improved desktop hover states
- Better small-screen spacing
- Reduced-motion compatibility retained

This is a visual-only upgrade. Existing Phase 70 features and setup links are preserved.
