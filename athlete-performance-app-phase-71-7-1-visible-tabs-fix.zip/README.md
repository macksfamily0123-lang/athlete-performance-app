# Athlete Performance App — Phase 71.7.1

Fixes the startup error:

`Cannot access 'visibleTabs' before initialization`

The guided first-use walkthrough and the bottom navigation slider are preserved.
