# Athlete Performance App — Phase 12

Built from the verified Phase 11 app.

Phase 12 adds Coach / Parent Roster Management:
- Multi-athlete roster
- Add/remove athletes
- Athlete sport, position, team, season, height, weight, handedness
- Switch active athlete
- Roster summary
- Persistent roster and active-athlete selection
- Mobile-friendly Roster tab

All Phase 1–11 features remain included.

Phase 12.1: Roster position is now a sport-specific dropdown using the same position lists as the athlete profile.
