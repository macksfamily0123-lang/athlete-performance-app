# Athlete Performance App — Phase 14

Built from the verified Phase 13 app.

Phase 14 adds Backup & Restore:
- Backup current athlete to JSON
- Backup entire roster to JSON
- Restore individual-athlete backups
- Restore complete roster backups
- Preserve per-athlete isolated data
- Data-health counts
- Reset current athlete performance history
- Mobile-friendly Data tab

All Phase 1–13 features remain included.
