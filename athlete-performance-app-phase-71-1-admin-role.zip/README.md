# Athlete Performance App — Phase 71.1 Admin Role

## New Admin role
Admin has unrestricted access to:
- Player features
- Coach features
- Parent-facing information
- Roster Management
- Athlete switching
- Team tools
- Private coach notes
- Data/backup tools
- All analytics, testing, development, training, and competition tools

## Admin Test View
While signed in as Admin, the top context bar includes a Test View selector:
- Admin
- Coach
- Player
- Parent

This lets the owner/developer preview role-specific interfaces without signing out or creating separate accounts.

## Existing roles remain restricted
- Player does not get roster or private coach notes.
- Parent remains read-only and does not receive coach/roster/admin controls.
- Coach receives coaching and roster-management permissions.

## Important
The role system is still local/device-side in Phase 71.1. Production authentication should later use Supabase Auth plus database Row Level Security so Admin and Coach roles cannot be self-selected by ordinary users.
