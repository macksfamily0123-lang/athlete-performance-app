# Install Phase 72.3.74 RC24 in Codespaces

Upload `athlete-performance-app-phase-72-3-74-native-sports-app-redesign-RC24.zip` into `/workspaces/athlete-performance-app`, then unzip it over the current app, clear `.next`, install dependencies, run `npm run test:native-sports-redesign`, run `npm run test:typecheck`, and start with `npm run dev`.
