# Phase 72.3.74 RC24 — Native Sports App Redesign

RC24 is a structural Home-screen redesign built on RC23. It is intended to move Hockey Dev / Athlete Performance away from a generic rounded-card dashboard and toward a purpose-built high-end sports app.

## What changed
- Edge-to-edge realistic sport photography for non-Junior Home screens.
- Athlete identity and readiness integrated into the hero composition.
- Player Home uses an editorial flow: signature primary action, performance instrument rail, one focus story, and numbered action rows rather than a tile grid.
- Coach Home uses a tactical signal band and command bar.
- Parent Home uses a calm vertical support timeline.
- Admin Home uses an operations ticker and command list.
- Junior Home remains deliberately simpler and more visual.
- Older duplicate Home summaries are suppressed while setup, Player Profile, weekly reviews, Coach Command Center, Parent review content, and Admin audit tools remain available.
- Small-screen Home layout is designed edge-to-edge at phone width rather than shrinking a desktop composition.

## Preserved
Supabase integration, roles and permissions, Junior mode, Player More fix, cloud test athletes, player photos, realistic sport-specific imagery, smooth readiness SVG, Parent/Coach connections, and migration 009.

No new database migration is required.
