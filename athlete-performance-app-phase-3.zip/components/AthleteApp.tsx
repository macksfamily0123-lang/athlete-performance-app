
"use client";
import {useEffect,useMemo,useState} from "react";

type Sport="Baseball"|"Football"|"Ice Hockey"|"Basketball"|"Lacrosse"|"Wrestling";
type Athlete={name:string;age:string;sport:Sport;position:string;team:string;season:string;height:string;weight:string};
type Goal={id:number;title:string;type:"Short-term"|"Long-term";progress:number};
type Workout={id:number;name:string;category:string;duration:number;exercises:string[];completed:boolean};
type TestResult={id:number;name:string;category:string;value:number;unit:string;date:string;sport:Sport};

const sports:{name:Sport;icon:string}[]=[
 {name:"Baseball",icon:"⚾"},{name:"Football",icon:"🏈"},{name:"Ice Hockey",icon:"🏒"},
 {name:"Basketball",icon:"🏀"},{name:"Lacrosse",icon:"🥍"},{name:"Wrestling",icon:"🤼"}
];

const positions:Record<Sport,string[]>={
 Baseball:["Pitcher","Catcher","Infield","Outfield","Utility"],
 Football:["Quarterback","Running Back","Wide Receiver","Tight End","Offensive Line","Defensive Line","Linebacker","Defensive Back","Kicker"],
 "Ice Hockey":["Forward","Defense","Goalie"],
 Basketball:["Point Guard","Shooting Guard","Small Forward","Power Forward","Center"],
 Lacrosse:["Attack","Midfield","Defense","Goalie","Faceoff"],
 Wrestling:["Wrestler"]
};

const testCatalog:Record<Sport,{name:string;category:string;unit:string}[]>={
 Baseball:[
  {name:"10-yard sprint",category:"Speed",unit:"sec"},{name:"20-yard sprint",category:"Speed",unit:"sec"},
  {name:"5-10-5 shuttle",category:"Agility",unit:"sec"},{name:"Vertical jump",category:"Power",unit:"in"},
  {name:"Broad jump",category:"Power",unit:"in"},{name:"Bench press",category:"Strength",unit:"lb"}
 ],
 Football:[
  {name:"10-yard sprint",category:"Speed",unit:"sec"},{name:"40-yard sprint",category:"Speed",unit:"sec"},
  {name:"5-10-5 shuttle",category:"Agility",unit:"sec"},{name:"Vertical jump",category:"Power",unit:"in"},
  {name:"Broad jump",category:"Power",unit:"in"},{name:"Bench press",category:"Strength",unit:"lb"},{name:"Squat",category:"Strength",unit:"lb"}
 ],
 "Ice Hockey":[
  {name:"10-yard sprint",category:"Speed",unit:"sec"},{name:"20-yard sprint",category:"Speed",unit:"sec"},
  {name:"Pro agility shuttle",category:"Agility",unit:"sec"},{name:"Vertical jump",category:"Power",unit:"in"},
  {name:"Broad jump",category:"Power",unit:"in"},{name:"Squat",category:"Strength",unit:"lb"}
 ],
 Basketball:[
  {name:"10-yard sprint",category:"Speed",unit:"sec"},{name:"Lane agility",category:"Agility",unit:"sec"},
  {name:"Vertical jump",category:"Power",unit:"in"},{name:"Broad jump",category:"Power",unit:"in"},{name:"Squat",category:"Strength",unit:"lb"}
 ],
 Lacrosse:[
  {name:"20-yard sprint",category:"Speed",unit:"sec"},{name:"Pro agility shuttle",category:"Agility",unit:"sec"},
  {name:"Vertical jump",category:"Power",unit:"in"},{name:"Broad jump",category:"Power",unit:"in"},{name:"Bench press",category:"Strength",unit:"lb"}
 ],
 Wrestling:[
  {name:"20-yard sprint",category:"Speed",unit:"sec"},{name:"5-10-5 shuttle",category:"Agility",unit:"sec"},
  {name:"Vertical jump",category:"Power",unit:"in"},{name:"Broad jump",category:"Power",unit:"in"},
  {name:"Squat",category:"Strength",unit:"lb"},{name:"Pull-ups",category:"Strength",unit:"reps"}
 ]
};

const starterAthlete:Athlete={name:"My Athlete",age:"",sport:"Ice Hockey",position:"Forward",team:"",season:"2026-27",height:"",weight:""};

const templates:Record<Sport,Workout>={
 Baseball:{id:1,name:"Explosive Baseball",category:"Power",duration:38,exercises:["Medicine-ball rotational throws · 3×8","Lateral bounds · 3×6/side","Sprint starts · 6×15 yd"],completed:false},
 Football:{id:2,name:"Football Speed",category:"Speed",duration:42,exercises:["10 yd acceleration · 6 reps","Flying 20s · 4 reps","Broad jump · 4×4"],completed:false},
 "Ice Hockey":{id:3,name:"Hockey Skating Power",category:"Power",duration:40,exercises:["Lateral bounds · 4×5/side","Single-leg squat · 3×8/side","Sprint intervals · 8×15 sec"],completed:false},
 Basketball:{id:4,name:"Basketball Vertical",category:"Jump",duration:35,exercises:["Countermovement jump · 4×5","Pogo jumps · 3×15","Split squat · 3×8/side"],completed:false},
 Lacrosse:{id:5,name:"Lacrosse Agility",category:"Agility",duration:36,exercises:["Cone cuts · 5 reps","Crossover run · 4×20 yd","Reactive shuffle · 6 reps"],completed:false},
 Wrestling:{id:6,name:"Wrestling Strength",category:"Strength",duration:48,exercises:["Front squat · 4×6","Pull-up · 4×AMRAP","Bear crawl · 4×20 yd"],completed:false}
};

export default function AthleteApp(){
 const [athlete,setAthlete]=useState<Athlete>(starterAthlete);
 const [form,setForm]=useState<Athlete>(starterAthlete);
 const [showProfile,setShowProfile]=useState(false);
 const [sport,setSport]=useState<Sport>("Ice Hockey");
 const [tab,setTab]=useState("home");
 const [goals,setGoals]=useState<Goal[]>([]);
 const [workouts,setWorkouts]=useState<Workout[]>([]);
 const [tests,setTests]=useState<TestResult[]>([]);

 useEffect(()=>{
  try{
   const a=localStorage.getItem("athlete"),g=localStorage.getItem("goals"),w=localStorage.getItem("workouts"),t=localStorage.getItem("tests");
   if(a){const x=JSON.parse(a);setAthlete(x);setForm(x);setSport(x.sport)}
   if(g)setGoals(JSON.parse(g)); if(w)setWorkouts(JSON.parse(w)); if(t)setTests(JSON.parse(t));
  }catch{}
 },[]);
 useEffect(()=>localStorage.setItem("athlete",JSON.stringify(athlete)),[athlete]);
 useEffect(()=>localStorage.setItem("goals",JSON.stringify(goals)),[goals]);
 useEffect(()=>localStorage.setItem("workouts",JSON.stringify(workouts)),[workouts]);
 useEffect(()=>localStorage.setItem("tests",JSON.stringify(tests)),[tests]);

 const initials=athlete.name.split(" ").map(x=>x[0]).join("").slice(0,2).toUpperCase()||"AM";
 const saveProfile=()=>{setAthlete(form);setSport(form.sport);setShowProfile(false)};

 return <div className="shell">
  <header><div className="brand"><b>AP</b><span><strong>Athlete Performance</strong><small>Train with purpose.</small></span></div><button className="avatar" onClick={()=>{setForm(athlete);setShowProfile(true)}}>{initials}</button></header>
  <main>
   <section className="profile"><div className="avatar big">{initials}</div><div className="profiletext"><small>ATHLETE PROFILE</small><h2>{athlete.name}</h2><p>{athlete.position||"Add position"} · {athlete.team||"Add team"} · {athlete.season}</p></div><button onClick={()=>{setForm(athlete);setShowProfile(true)}}>Edit</button></section>
   <div className="sports">{sports.map(x=><button className={sport===x.name?"selected":""} onClick={()=>setSport(x.name)} key={x.name}>{x.icon} {x.name}</button>)}</div>
   {tab==="home"&&<Home athlete={athlete} sport={sport} goals={goals} workouts={workouts} tests={tests}/>}
   {tab==="goals"&&<Goals goals={goals} setGoals={setGoals}/>}
   {tab==="workouts"&&<Workouts sport={sport} workouts={workouts} setWorkouts={setWorkouts}/>}
   {tab==="tests"&&<Testing sport={sport} tests={tests} setTests={setTests}/>}
   {tab==="progress"&&<Progress goals={goals} workouts={workouts} tests={tests}/>}
  </main>
  <nav>{[["home","⌂","Home"],["goals","◎","Goals"],["workouts","◆","Workouts"],["tests","◈","Testing"],["progress","↗","Progress"]].map(x=><button className={tab===x[0]?"active":""} onClick={()=>setTab(x[0])} key={x[0]}><b>{x[1]}</b>{x[2]}</button>)}</nav>
  {showProfile&&<div className="overlay"><div className="modal">
   <div className="modalhead"><h2>Athlete Profile</h2><button onClick={()=>setShowProfile(false)}>×</button></div>
   <label>Full name<input value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/></label>
   <label>Age<input value={form.age} onChange={e=>setForm({...form,age:e.target.value})} placeholder="e.g. 14"/></label>
   <label>Sport<select value={form.sport} onChange={e=>{const x=e.target.value as Sport;setForm({...form,sport:x,position:positions[x][0]})}}>{sports.map(x=><option key={x.name}>{x.name}</option>)}</select></label>
   <label>Position<select value={form.position} onChange={e=>setForm({...form,position:e.target.value})}>{positions[form.sport].map(x=><option key={x}>{x}</option>)}</select></label>
   <div className="grid"><label>Team<input value={form.team} onChange={e=>setForm({...form,team:e.target.value})}/></label><label>Season<input value={form.season} onChange={e=>setForm({...form,season:e.target.value})}/></label></div>
   <div className="grid"><label>Height<input value={form.height} onChange={e=>setForm({...form,height:e.target.value})}/></label><label>Weight<input value={form.weight} onChange={e=>setForm({...form,weight:e.target.value})}/></label></div>
   <button className="primary" onClick={saveProfile}>Save athlete profile</button>
  </div></div>}
 </div>
}

function Home({athlete,sport,goals,workouts,tests}:{athlete:Athlete;sport:Sport;goals:Goal[];workouts:Workout[];tests:TestResult[]}){
 return <div><div className="hero"><small>{sport.toUpperCase()} DASHBOARD</small><h1>Build your next level.</h1><p>Track goals, train with purpose, and measure progress.</p></div>
  <div className="stats"><Stat a="Active goals" b={goals.length}/><Stat a="Workouts" b={workouts.length}/><Stat a="Tests" b={tests.filter(x=>x.sport===sport).length}/><Stat a="Season" b={athlete.season}/></div>
  <div className="card"><h2>Performance testing</h2><p>Record speed, agility, strength and power results from the Testing tab. Every result is dated and saved to the athlete profile.</p></div>
 </div>
}

function Goals({goals,setGoals}:{goals:Goal[];setGoals:React.Dispatch<React.SetStateAction<Goal[]>>}){
 const [title,setTitle]=useState("");
 return <div><h1>Goals</h1><div className="card"><input placeholder="New goal" value={title} onChange={e=>setTitle(e.target.value)}/><button className="primary" onClick={()=>{if(title){setGoals(g=>[{id:Date.now(),title,type:"Short-term",progress:0},...g]);setTitle("")}}}>Add goal</button></div>
 {goals.map(g=><div className="card" key={g.id}><span className="tag">{g.type}</span><h2>{g.title}</h2><input type="range" min="0" max="100" value={g.progress} onChange={e=>setGoals(xs=>xs.map(x=>x.id===g.id?{...x,progress:+e.target.value}:x))}/><b>{g.progress}%</b></div>)}</div>
}

function Workouts({sport,workouts,setWorkouts}:{sport:Sport;workouts:Workout[];setWorkouts:React.Dispatch<React.SetStateAction<Workout[]>>}){
 const t=templates[sport];
 return <div><h1>Workouts</h1><div className="card"><span className="tag">{t.category}</span><h2>{t.name}</h2><p>{t.duration} minutes</p>{t.exercises.map(x=><p key={x}>• {x}</p>)}<button className="primary" onClick={()=>setWorkouts(w=>[{...t,id:Date.now()},...w])}>Add workout</button></div>
 {workouts.map(w=><div className="card row" key={w.id}><div><h2>{w.name}</h2><p>{w.duration} minutes</p></div><button onClick={()=>setWorkouts(ws=>ws.map(x=>x.id===w.id?{...x,completed:!x.completed}:x))}>{w.completed?"✓ Done":"Complete"}</button></div>)}</div>
}

function Testing({sport,tests,setTests}:{sport:Sport;tests:TestResult[];setTests:React.Dispatch<React.SetStateAction<TestResult[]>>}){
 const catalog=testCatalog[sport]; const [name,setName]=useState(catalog[0].name); const [value,setValue]=useState("");
 const current=catalog.find(x=>x.name===name)||catalog[0];
 useEffect(()=>{if(!catalog.some(x=>x.name===name))setName(catalog[0].name)},[sport]);
 const history=tests.filter(x=>x.sport===sport);
 const add=()=>{const n=Number(value);if(!value||Number.isNaN(n))return;setTests(x=>[{id:Date.now(),name,category:current.category,value:n,unit:current.unit,date:new Date().toISOString().slice(0,10),sport},...x]);setValue("")};
 return <div><h1>Performance Testing</h1>
  <div className="card"><span className="tag">RECORD RESULT</span><h2>{sport} testing</h2>
   <label>Test<select value={name} onChange={e=>{setName(e.target.value);setValue("")}}>{catalog.map(x=><option key={x.name}>{x.name}</option>)}</select></label>
   <label>Result ({current.unit})<input inputMode="decimal" value={value} onChange={e=>setValue(e.target.value)} placeholder={current.unit==="sec"?"e.g. 1.82":current.unit==="lb"?"e.g. 185":"e.g. 24"}/></label>
   <button className="primary" onClick={add}>Save test result</button>
  </div>
  <h2>Test history</h2>{history.length===0&&<div className="card"><p>No results recorded yet.</p></div>}
  {history.map(x=><div className="card row" key={x.id}><div><span className="tag">{x.category}</span><h2>{x.name}</h2><p>{x.date}</p></div><strong className="test-value">{x.value} {x.unit}</strong></div>)}
 </div>
}

function Progress({goals,workouts,tests}:{goals:Goal[];workouts:Workout[];tests:TestResult[]}){
 const avg=goals.length?Math.round(goals.reduce((a,g)=>a+g.progress,0)/goals.length):0;
 const latest=tests.slice(0,4);
 return <div><h1>Progress</h1><div className="stats"><Stat a="Goal progress" b={avg+"%"}/><Stat a="Completed workouts" b={workouts.filter(x=>x.completed).length}/><Stat a="Test results" b={tests.length}/></div>
  <div className="card"><h2>Performance snapshot</h2>{latest.length===0?<p>Record tests to start building your performance history.</p>:<div className="test-summary">{latest.map(x=><div key={x.id}><small>{x.name}</small><b>{x.value} {x.unit}</b><em>{x.date}</em></div>)}</div>}</div>
  <div className="card"><h2>Goal progress</h2><div className="bar"><i style={{width:avg+"%"}}/></div><p>{avg}% average completion across current goals.</p></div>
 </div>
}
function Stat({a,b}:{a:string;b:any}){return <div className="stat"><small>{a}</small><strong>{b}</strong></div>}
