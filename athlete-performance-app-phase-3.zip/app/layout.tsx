import "./globals.css";
export const metadata={title:"Athlete Performance",description:"Goals, workouts and performance testing"};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}