
"use client";
import {useEffect,useMemo,useState} from "react";

type Sport="Baseball"|"Football"|"Ice Hockey"|"Basketball"|"Lacrosse"|"Wrestling";
type TestDef={id:string;name:string;category:string;unit:string;lowerBetter:boolean};
type CustomTest=TestDef&{sport:Sport};
type Result={id:number;testId:string;name:string;category:string;unit:string;value:number;date:string;sport:Sport};
type Goal={id:number;title:string;progress:number;type:"Short-term"|"Long-term"};
type Workout={id:number;date:string;name:string;category:string;minutes:number;completed:boolean;sport:Sport};

const sports:Sport[]=["Baseball","Football","Ice Hockey","Basketball","Lacrosse","Wrestling"];
const categories=["Speed","Agility","Power","Strength","Endurance","Skill","Conditioning","Other"];
const units=["sec","min","mph","km/h","in","ft","lb","kg","reps","yards","meters","points","%","Other"];

const raw:Record<Sport,string[][]>={
 Baseball:[["10-yard sprint","Speed","sec","1"],["20-yard sprint","Speed","sec","1"],["5-10-5 shuttle","Agility","sec","1"],["Vertical jump","Power","in","0"],["Broad jump","Power","in","0"],["Bench press","Strength","lb","0"]],
 Football:[["10-yard sprint","Speed","sec","1"],["40-yard sprint","Speed","sec","1"],["5-10-5 shuttle","Agility","sec","1"],["Vertical jump","Power","in","0"],["Broad jump","Power","in","0"],["Bench press","Strength","lb","0"],["Squat","Strength","lb","0"]],
 "Ice Hockey":[["10-yard sprint","Speed","sec","1"],["20-yard sprint","Speed","sec","1"],["Pro agility shuttle","Agility","sec","1"],["Vertical jump","Power","in","0"],["Broad jump","Power","in","0"],["Squat","Strength","lb","0"]],
 Basketball:[["10-yard sprint","Speed","sec","1"],["Lane agility","Agility","sec","1"],["Vertical jump","Power","in","0"],["Broad jump","Power","in","0"],["Squat","Strength","lb","0"]],
 Lacrosse:[["20-yard sprint","Speed","sec","1"],["Pro agility shuttle","Agility","sec","1"],["Vertical jump","Power","in","0"],["Broad jump","Power","in","0"],["Bench press","Strength","lb","0"]],
 Wrestling:[["20-yard sprint","Speed","sec","1"],["5-10-5 shuttle","Agility","sec","1"],["Vertical jump","Power","in","0"],["Broad jump","Power","in","0"],["Squat","Strength","lb","0"],["Pull-ups","Strength","reps","0"]]
};
const definitions=(sport:Sport):TestDef[]=>raw[sport].map((x,i)=>({id:`${sport}-${i}`,name:x[0],category:x[1],unit:x[2],lowerBetter:x[3]==="1"}));
const today=()=>new Date().toISOString().slice(0,10);
const daysAgo=(n:number)=>{const d=new Date();d.setDate(d.getDate()-n);return d.toISOString().slice(0,10)};
const improvement=(first:number,last:number,lower:boolean)=>first===0?0:Math.round((lower?(first-last)/first:(last-first)/first*100)*10)/10;
const pct=(n:number)=>Math.max(0,Math.min(100,Math.round(n)));

export default function AthleteApp(){
 const [sport,setSport]=useState<Sport>("Ice Hockey"),[tab,setTab]=useState("Home");
 const [results,setResults]=useState<Result[]>([]),[custom,setCustom]=useState<CustomTest[]>([]),[goals,setGoals]=useState<Goal[]>([]),[workouts,setWorkouts]=useState<Workout[]>([]);
 useEffect(()=>{for(const [key,setter] of [["results",setResults],["custom",setCustom],["goals",setGoals],["workouts",setWorkouts]] as any[]){try{const v=localStorage.getItem(key);if(v)setter(JSON.parse(v))}catch{}}},[]);
 useEffect(()=>localStorage.setItem("results",JSON.stringify(results)),[results]);
 useEffect(()=>localStorage.setItem("custom",JSON.stringify(custom)),[custom]);
 useEffect(()=>localStorage.setItem("goals",JSON.stringify(goals)),[goals]);
 useEffect(()=>localStorage.setItem("workouts",JSON.stringify(workouts)),[workouts]);
 return <div className="app">
  <header><div className="logo">AP</div><div><strong>Athlete Performance</strong><small>Train with purpose.</small></div></header>
  <main>
   <div className="sports">{sports.map(s=><button className={sport===s?"sel":""} onClick={()=>setSport(s)} key={s}>{s}</button>)}</div>
   {tab==="Home"&&<Home sport={sport} goals={goals} workouts={workouts} results={results}/>}
   {tab==="Goals"&&<Goals goals={goals} setGoals={setGoals}/>}
   {tab==="Calendar"&&<Calendar sport={sport} workouts={workouts} setWorkouts={setWorkouts}/>}
   {tab==="Testing"&&<Testing sport={sport} library={[...definitions(sport),...custom.filter(x=>x.sport===sport)]} custom={custom} setCustom={setCustom} results={results} setResults={setResults}/>}
   {tab==="Analytics"&&<Analytics sport={sport} results={results} goals={goals} workouts={workouts}/>}
  </main>
  <nav>{["Home","Goals","Calendar","Testing","Analytics"].map(x=><button className={tab===x?"active":""} onClick={()=>setTab(x)} key={x}>{x}</button>)}</nav>
 </div>
}

function Home({sport,goals,workouts,results}:{sport:Sport;goals:Goal[];workouts:Workout[];results:Result[]}){
 const gs=goals.length?Math.round(goals.reduce((a,g)=>a+g.progress,0)/goals.length):0;
 const ws=workouts.filter(x=>x.sport===sport),done=ws.filter(x=>x.completed).length;
 const rs=results.filter(x=>x.sport===sport);
 const score=pct(gs*.4+(ws.length?done/ws.length*30:0)+(rs.length?30:0));
 return <><div className="hero"><small>ATHLETE DASHBOARD</small><h1>{sport}</h1><p>Build skills. Track progress. Perform better.</p></div>
 <div className="grid three"><div className="stat"><small>Performance</small><b>{score}</b><span>/100</span></div><div className="stat"><small>Goal Progress</small><b>{gs}%</b></div><div className="stat"><small>Tests Logged</small><b>{rs.length}</b></div></div>
 <div className="card"><div className="sectionHead"><h2>Today's Focus</h2><span>{today()}</span></div><p>{ws.find(x=>x.date===today()&&!x.completed)?.name||"No workout scheduled today."}</p></div>
 <div className="card"><h2>Recent Activity</h2>{ws.slice(0,3).map(w=><div className="row line" key={w.id}><span>{w.name}<small>{w.date} · {w.minutes} min</small></span><b>{w.completed?"✓":"Scheduled"}</b></div>)}{!ws.length&&<p>No workouts yet. Add one from Calendar.</p>}</div></>
}

function Goals({goals,setGoals}:{goals:Goal[];setGoals:any}){
 const [title,setTitle]=useState(""),[type,setType]=useState<Goal["type"]>("Short-term");
 return <><h1>Goals</h1><div className="card"><label>Goal name<input value={title} onChange={e=>setTitle(e.target.value)} placeholder="e.g. Improve sprint time"/></label><label>Goal type<select value={type} onChange={e=>setType(e.target.value as Goal["type"])}><option>Short-term</option><option>Long-term</option></select></label><button className="primary" onClick={()=>{if(title.trim()){setGoals((g:Goal[])=>[{id:Date.now(),title:title.trim(),progress:0,type},...g]);setTitle("")}}}>Add Goal</button></div>
 {goals.map(g=><div className="card" key={g.id}><div className="row"><b>{g.title}</b><span className="tag">{g.type}</span></div><input type="range" value={g.progress} onChange={e=>setGoals((x:Goal[])=>x.map(a=>a.id===g.id?{...a,progress:+e.target.value}:a))}/><div className="progress"><i style={{width:`${g.progress}%`}}/></div><small>{g.progress}% complete</small></div>)}</>
}

function Calendar({sport,workouts,setWorkouts}:{sport:Sport;workouts:Workout[];setWorkouts:any}){
 const [date,setDate]=useState(today()),[name,setName]=useState("Sport Workout"),[cat,setCat]=useState("Conditioning"),[minutes,setMinutes]=useState("45");
 const rows=workouts.filter(w=>w.sport===sport).sort((a,b)=>a.date.localeCompare(b.date));
 return <><h1>Training Calendar</h1><div className="card"><div className="calendarTop"><button onClick={()=>{const d=new Date(date);d.setDate(d.getDate()-1);setDate(d.toISOString().slice(0,10))}}>‹</button><input type="date" value={date} onChange={e=>setDate(e.target.value)}/><button onClick={()=>{const d=new Date(date);d.setDate(d.getDate()+1);setDate(d.toISOString().slice(0,10))}}>›</button></div><label>Workout name<input value={name} onChange={e=>setName(e.target.value)}/></label><label>Workout category<select value={cat} onChange={e=>setCat(e.target.value)}>{categories.map(x=><option key={x}>{x}</option>)}</select></label><label>Duration<select value={minutes} onChange={e=>setMinutes(e.target.value)}>{["15","30","45","60","75","90","120"].map(x=><option key={x} value={x}>{x} minutes</option>)}</select></label><button className="primary" onClick={()=>setWorkouts((x:Workout[])=>[{id:Date.now(),date,name,category:cat,minutes:+minutes,completed:false,sport},...x])}>Schedule Workout</button></div>
 <h2>Upcoming & Recent</h2>{rows.map(w=><div className="card row" key={w.id}><span><b>{w.name}</b><small>{w.date} · {w.category} · {w.minutes} min</small></span><button onClick={()=>setWorkouts((x:Workout[])=>x.map(a=>a.id===w.id?{...a,completed:!a.completed}:a))}>{w.completed?"✓ Completed":"Complete"}</button></div>)}</>
}

function Testing({sport,library,custom,setCustom,results,setResults}:{sport:Sport;library:TestDef[];custom:CustomTest[];setCustom:any;results:Result[];setResults:any}){
 const [id,setId]=useState(library[0]?.id||""),[category,setCategory]=useState(""),[unit,setUnit]=useState(""),[value,setValue]=useState(""),[open,setOpen]=useState(false);
 const [name,setName]=useState(""),[newCat,setNewCat]=useState("Speed"),[newUnit,setNewUnit]=useState("sec"),[lower,setLower]=useState(true);
 useEffect(()=>{if(!library.some(x=>x.id===id))setId(library[0]?.id||"")},[sport,custom]);
 const t=library.find(x=>x.id===id), rows=results.filter(x=>x.sport===sport);
 useEffect(()=>{if(t){setCategory(t.category);setUnit(t.unit)}},[id]);
 const save=()=>{if(t&&value.trim()&&!isNaN(Number(value)))setResults((r:Result[])=>[{id:Date.now(),testId:t.id,name:t.name,category,unit,value:Number(value),date:today(),sport},...r])};
 return <><h1>Performance Testing</h1><div className="card">
 <label>Test Name<select value={id} onChange={e=>e.target.value==="__custom__"?setOpen(true):setId(e.target.value)}>{library.map(x=><option value={x.id} key={x.id}>{x.name}</option>)}<option value="__custom__">＋ Create Custom Test</option></select></label>
 <div className="two"><label>Category<select value={category} onChange={e=>setCategory(e.target.value)}>{categories.map(x=><option key={x}>{x}</option>)}</select></label><label>Unit of Measure<select value={unit} onChange={e=>setUnit(e.target.value)}>{units.map(x=><option key={x}>{x}</option>)}</select></label></div>
 {t&&<p>{t.lowerBetter?"Lower is better":"Higher is better"}</p>}<label>Result<input inputMode="decimal" value={value} onChange={e=>setValue(e.target.value)}/></label><button className="primary" disabled={!t} onClick={save}>Save Result</button></div>
 <h2>Test History</h2>{rows.map(r=><div className="card row" key={r.id}><span><b>{r.name}</b><small>{r.date} · {r.category}</small></span><strong>{r.value} {r.unit}</strong></div>)}
 {open&&<div className="overlay"><div className="modal"><div className="sectionHead"><h2>Create Custom Test</h2><button onClick={()=>setOpen(false)}>×</button></div><label>Test name<input value={name} onChange={e=>setName(e.target.value)} placeholder="e.g. Shot speed"/></label><label>Category<select value={newCat} onChange={e=>setNewCat(e.target.value)}>{categories.map(x=><option key={x}>{x}</option>)}</select></label><label>Unit of Measure<select value={newUnit} onChange={e=>setNewUnit(e.target.value)}>{units.map(x=><option key={x}>{x}</option>)}</select></label><label>Better result<select value={lower?"lower":"higher"} onChange={e=>setLower(e.target.value==="lower")}><option value="lower">Lower is better</option><option value="higher">Higher is better</option></select></label><button className="primary" onClick={()=>{if(name.trim()){const x={id:`custom-${Date.now()}`,name:name.trim(),category:newCat,unit:newUnit,lowerBetter:lower,sport};setCustom((c:CustomTest[])=>[...c,x]);setId(x.id);setOpen(false);setName("")}}}>Save Custom Test</button></div></div>}</>
}

function Analytics({sport,results,goals,workouts}:{sport:Sport;results:Result[];goals:Goal[];workouts:Workout[]}){
 const [range,setRange]=useState("all"),cutoff=range==="all"?0:Date.now()-Number(range)*86400000;
 const rows=results.filter(r=>r.sport===sport&&new Date(r.date).getTime()>=cutoff), groups=[...new Map(rows.map(r=>[r.testId,r])).values()];
 const avgGoal=goals.length?Math.round(goals.reduce((a,g)=>a+g.progress,0)/goals.length):0,ws=workouts.filter(w=>w.sport===sport),cons=ws.length?Math.round(ws.filter(w=>w.completed).length/ws.length*100):0,score=Math.round(avgGoal*.4+cons*.3+(groups.length?30:0));
 return <><h1>Analytics</h1><div className="filters">{["30","90","365","all"].map(x=><button className={range===x?"sel":""} onClick={()=>setRange(x)} key={x}>{x==="all"?"All":x+"D"}</button>)}</div><div className="score"><small>ATHLETE PERFORMANCE SCORE</small><strong>{score}</strong><span>/100</span></div><div className="card"><h2>Personal Records & Trends</h2>
 {groups.length?groups.map(g=>{const r=rows.filter(x=>x.testId===g.testId).sort((a,b)=>a.date.localeCompare(b.date)),def=definitions(sport).find(x=>x.id===g.testId)||({lowerBetter:g.unit==="sec"} as TestDef),best=r.reduce((a,b)=>def.lowerBetter?Math.min(a,b.value):Math.max(a,b.value),r[0].value),last=r[r.length-1].value,first=r[0].value,imp=r.length>1?improvement(first,last,def.lowerBetter):0;return <div className="trend" key={g.testId}><div className="row"><div><b>{g.name}</b><small>{r.length} results · Best {best} {g.unit}</small></div><strong className={imp>=0?"good":"bad"}>{r.length>1?(imp>=0?"+":"")+imp+"%":"New"}</strong></div><TrendChart values={r.map(x=>x.value)} lower={def.lowerBetter}/><small>Latest {last} {g.unit} · {r.length>1?`Improvement ${Math.abs(imp)}%`:"Add another result to calculate improvement"}</small></div>}) : <p>Record the same test more than once to see a trend line and quantified improvement.</p>}
 </div><div className="grid twoCards"><div className="card"><h2>Goal Progress</h2><b className="big">{avgGoal}%</b></div><div className="card"><h2>Training Consistency</h2><b className="big">{cons}%</b></div></div></>
}
function TrendChart({values,lower}:{values:number[];lower:boolean}){const w=520,h=150,p=24,min=Math.min(...values),max=Math.max(...values),span=max-min||1;const pts=values.map((v,i)=>`${p+i*((w-2*p)/Math.max(1,values.length-1))},${h-p-((v-min)/span)*(h-2*p)}`).join(" ");return <svg className="chart" viewBox={`0 0 ${w} ${h}`} role="img" aria-label="Performance trend"><line x1={p} y1={h-p} x2={w-p} y2={h-p} stroke="currentColor" opacity=".2"/><polyline points={pts} fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"/>{values.map((v,i)=>{const x=p+i*((w-2*p)/Math.max(1,values.length-1)),y=h-p-((v-min)/span)*(h-2*p);return <circle key={i} cx={x} cy={y} r="5" fill="currentColor"/>})}</svg>}
