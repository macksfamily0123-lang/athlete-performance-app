# Athlete Performance App — Phase 70.13

## Simplified information hierarchy
No features were removed.

Secondary information is now collapsed by default:
- Home: V1 Readiness, Performance Intelligence, Recent Activity
- Goals: Goal Insights and Completed Goals
- Calendar: Season & Training Insights
- Testing: Testing Details
- Competition: Competition Insights
- Development: More Development Tools

Primary actions and commonly used information remain visible.

## Forest-green visual update
- Added professional forest-green accents to the existing blue/cyan athletic palette.
- Updated hero gradients, active navigation, progress bars, tags, disclosures, and primary actions.
- Kept the overall dark professional sports aesthetic.

All Phase 70.12 workout readability, mental-preparation reminders, exercise guides, program generation, roster editing, and existing features are preserved.
