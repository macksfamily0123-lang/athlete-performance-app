# Athlete Performance App — Phase 70.4

- Every player in Roster Management has an Edit button.
- Edit activates that player, navigates to Home, and scrolls directly to Edit Profile.
- Edit Profile uses a sport-specific Position dropdown.
- Edit Profile includes a Right / Left Handedness dropdown.
- The simplified Phase 70.3 layout and all existing features are preserved.
