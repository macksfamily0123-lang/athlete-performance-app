# Athlete Performance App — Phase 71 Role Accounts & Permissions

## Separate role workspaces
A new entry screen separates:
- Player
- Coach
- Parent

The selected role is persisted on the device until Sign out.

## Player permissions
Player sees:
- Home
- Goals
- Calendar
- Testing
- Analytics
- Readiness
- Development
- Competition

Player does NOT see:
- Roster Management
- Team / athlete comparison
- Private coach notes
- Coach Plan

## Coach permissions
Coach sees the complete management workspace:
- athlete goals / schedule / testing / analytics
- Coach Plan
- private coach notes
- Development and Training Program
- Competition
- Roster Management
- Data / backup tools

## Parent permissions
Parent receives dedicated read-only pages:
- Home summary
- Schedule
- Progress
- Development
- Competition history

Parent cannot edit athlete data and does not see:
- private coach notes
- roster management
- team analytics
- coach plan
- athlete data administration

## Private coach notes
Existing Coach / Parent Notes have been upgraded to a Coach-only private notes area.
They do not render in the Player or Parent workspace.

## Security note
Phase 71 enforces role separation in the local app UI. It is the foundation for
real cloud accounts. Supabase/Auth + server/database Row Level Security should be
the next security phase before production use.

Existing Phase 70 functionality is preserved for the roles authorized to use it.
