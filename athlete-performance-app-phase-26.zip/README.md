# Athlete Performance App — Phase 26

Built from the combined Phase 24 + 25 update.

Phase 26 upgrades Roster to Roster 2.0 without adding another tab:
- Roster overview dashboard
- Athlete performance/activity summary cards
- Quick athlete switching
- Side-by-side athlete comparison
- Roster average score
- Total tests and competitions
- Sport-specific position dropdown preserved
- Per-athlete isolated data preserved
- Existing backup/data tools remain below Roster

All Phase 1–25 features remain included.
