# Athlete Performance App — Beta Release Candidate 1

Version: **72.3.50 RC1**

This release candidate freezes the current major feature set for beta testing.

## Core product direction
The app is an athlete development record and development-support system.
It is not a practice-plan builder.

## Role ownership
- Player owns Player Profile, Player goals, Daily Check-In, Player Weekly Review, and Player reflections.
- Coach supports Player-owned goals with suggestions/comments, owns Coach Weekly Review, manages the Athlete Development Plan, and records Practice Observations.
- Parent is support/read focused with Shared Notes as the primary write pathway.
- Admin has full administrative override access.

## Coach experience
- Coach Workspace Setup returns on each login while incomplete.
- Coach Home uses Development Command Center 2.0.
- Who Should I Review Next? prioritizes athletes from development-support signals.
- 7-step athlete development review:
  1. Readiness
  2. Player Goals
  3. Testing Trends
  4. Development Plan
  5. Practice Observations
  6. Coach Weekly Review
  7. Next Development Action

## Player experience
- Today-first Home
- simplified My Progress
- simplified My Development
- Player-owned Goals
- Athlete Development Plan visibility
- Daily Check-In and Weekly Review

## Parent experience
- support-focused Overview
- Schedule
- Recovery
- Progress
- Development Support
- Shared Notes

## Admin
- full athlete-data access
- cloud athlete selection
- full profile/data correction controls
- Coach Weekly Review override
- visible Role Ownership Matrix
- diagnostics / Beta Admin

## Database
No new migration is introduced in 72.3.50.
`004_admin_full_access.sql` remains required if not already applied.

## Release validation
Use:

`npm run release:check`

This runs:
- role permission audit
- regression suite
- full TypeScript typecheck
- Next.js production build


# Beta Release Candidate 2 — v72.3.51

Focus: reliability and beta testing.

Added:
- runtime error recovery boundary
- reload/report-error recovery actions
- online/offline banner
- diagnostic context on beta feedback
- transparent diagnostic disclosure
- Settings cloud reliability status
- automated reliability test suite

No new migration.


# Beta Release Candidate 3 — v72.3.52

Focus: Coach roster discoverability and Player invitation workflow.

Added:
- Invite Player directly in Coach Roster
- Manage Teams directly in Coach Roster
- invite-first Coach modal
- copy full invite message
- copy invite code only
- Player/Parent Join Team instructions
- already-joined team roster
- Coach Help + setup guidance for invitations

No new migration.


# Beta Release Candidate 4 — v72.3.53

Focus: Family account linking + Junior Player usability.

Added:
- Parent-managed Player accounts
- age captured when Parent adds a Player
- Junior Player Mode for age 10 and under
- simplified Junior Home and navigation
- simplified Junior goals
- easy-choice / emoji Daily Check-In
- Parent → managed Player session
- Return to Parent View
- Player Access Codes
- Player signup claim-code support
- existing fresh Player account claim flow
- one-athlete Player/Parent/Coach relationship model
- restricted Parent-managed Player cloud-save RPC
- duplicate-athlete protections
- migration 005

Preserved:
- Player-owned goals/check-ins/reviews
- Coach-owned formal Development Plan/Objectives
- Coach Practice Observations
- Coach Weekly Review security
- Parent support role
- Admin full-access override
- Coach Roster team invite workflow
- no practice-plan generation


# Beta Release Candidate 5 — v72.3.54

Focus: Junior Player usability and support-role scheduling/results.

Fixed:
- Junior Home `How am I doing?` button is green, clickable, and opens Progress.

Added:
- Parent workout scheduling
- Parent competition score/result entry
- Coach Home shortcuts for scheduling and competition results
- narrow `scheduleWorkout` permission
- narrow `enterCompetitionResult` permission
- Parent support cloud RPC
- migration 006
- score-only competition analytics protection

Preserved:
- Parent cannot broadly write training programs
- Parent cannot write Player reflections
- Parent cannot manage formal Coach Development Plan/Objectives
- Parent cannot create Practice Observations
- Player-owned goals/check-ins/reviews remain protected
- Coach-owned development workflow remains protected
- Coach can schedule workouts and log full competition records
- no practice-plan generation


# Beta Release Candidate 6 — v72.3.55

Focus: Junior Player goal-entry usability.

Fixed:
- Junior Player Goal page now always exposes the Player-owned goal form.
- The goal form is positioned at the top of the page instead of being easy to miss.
- Goal input fields are explicitly visible and touch-enabled on mobile.
- Save My Goal is a large forest-green primary action.
- Parent-managed Junior Player sessions can help type and save the Player's goal through the existing restricted managed-Player flow.

Preserved:
- Goals remain Player-owned.
- Coach cannot create or change Player goals.
- Parent normal view cannot create or change Player goals.
- Admin override remains available.
- No new database migration.
