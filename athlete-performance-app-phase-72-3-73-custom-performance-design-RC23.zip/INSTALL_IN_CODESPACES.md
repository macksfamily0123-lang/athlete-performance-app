# Install Phase 72.3.73 RC23 in Codespaces

Upload:

`athlete-performance-app-phase-72-3-73-custom-performance-design-RC23.zip`

Then run:

```bash
cd /workspaces/athlete-performance-app
```

```bash
unzip -o athlete-performance-app-phase-72-3-73-custom-performance-design-RC23.zip
```

```bash
rm -rf .next
```

```bash
npm install
```

```bash
npm run test:custom-design
```

```bash
npm run dev
```

No new Supabase migration is required. Migration 009 remains the latest required migration.
