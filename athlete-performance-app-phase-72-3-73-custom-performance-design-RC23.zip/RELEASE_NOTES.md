# Phase 72.3.73 RC23 — Custom Performance Design System

## Design system
RC23 replaces the generic rounded-card/dashboard look with a custom sports-product visual system. It uses photography-first hero composition, a continuous metric rail, restrained neutral surfaces, sharp typography hierarchy, role-specific accent tokens, a custom icon family, and a simplified navigation dock.

## Home
- Realistic all-sport non-Junior hero images remain.
- Junior keeps the illustrated/simplified sport treatment.
- Hero content is composed as an editorial overlay rather than a card inside a card.
- Goals / Next / Testing now read as one instrument panel.
- Quick actions use neutral performance-console tiles with category accents.
- Player/Admin Focus icon is now a solid trend mark to eliminate the center-background artifact.

## Navigation
- New SVG icon family for Home, Plan, Train, Progress, More, recovery, goals, schedule, and related Home actions.
- Active navigation uses a small role-accent indicator rather than a generic filled pill.

## Mobile
- Dedicated 700px and 390px layouts.
- Realistic hero has intentional crop, readable identity area, and protected readiness space.
- Mobile quick actions and bottom navigation are tuned for touch.

## Data / permissions
No data-model or permission changes. Migration 009 is unchanged and remains the latest required migration.
