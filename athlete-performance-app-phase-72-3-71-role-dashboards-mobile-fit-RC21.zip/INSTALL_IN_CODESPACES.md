# Install Phase 72.3.71 RC21 in Codespaces

From `/workspaces/athlete-performance-app`:

```bash
unzip -o athlete-performance-app-phase-72-3-71-role-dashboards-mobile-fit-RC21.zip
```

```bash
rm -rf .next
```

```bash
npm install
```

```bash
npm run test:role-dashboard-mobile
```

```bash
npm run dev
```

No new Supabase migration is required. Migration 009 remains unchanged.
