# Phase 72.3.67 RC17 — Codespaces install

This is a full app update built from the RC16 app, whose protected baseline is Phase 72.3.64 RC15. Phase 72.3.65 was not used.

1. Put the ZIP in `/workspaces/athlete-performance-app`.
2. From the app folder, unzip it with overwrite enabled.
3. Delete `.next`, install packages, run the sport-header check, then start the app.

Commands are supplied in the ChatGPT delivery message.

No new Supabase migration is required. Migration 009 remains the latest required migration.
