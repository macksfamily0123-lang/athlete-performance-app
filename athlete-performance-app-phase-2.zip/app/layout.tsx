import "./globals.css";
export const metadata={title:"Athlete Performance",description:"Athlete goals, workouts and performance tracking"};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}