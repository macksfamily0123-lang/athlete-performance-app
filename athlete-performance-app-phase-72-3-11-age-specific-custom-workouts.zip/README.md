# Athlete Performance App — Phase 72.3.11

## Simplified navigation

The bottom navigation is reduced to five clear destinations:

1. **Overview**
2. **Plan**
3. **Train**
4. **Progress**
5. **More**

No features were removed.

Grouped features:
- Plan → Goals + Schedule
- Train → Development + Readiness/Coach
- Progress → Testing + Analytics
- More → Competition + Roster when the role has Roster access

When a group contains multiple sections, a small contextual selector appears inside that area. The former quick-navigation search is still available through **More → Search All Features**.

## Sport + Position Workout Builder

The Training Program generator now uses both:
- athlete sport
- athlete position

Position-specific demand profiles are included for:
- Baseball
- Football
- Ice Hockey
- Basketball
- Lacrosse
- Wrestling
- Soccer
- Figure Skating

Examples:
- Hockey Goaltender → lateral power, deceleration, hip/adductor robustness, reaction
- Hockey Defense → backward-to-forward acceleration, crossover power, lower-body strength
- Football speed positions → acceleration, max-speed mechanics, COD, elastic power
- Soccer wide players → high-speed running, acceleration, hamstring strength
- Baseball Pitcher → lower-body force, rotational power, single-leg control, scapular robustness
- Basketball Guards → first-step speed, lateral COD, deceleration
- Lacrosse Midfield → repeated-sprint ability and aerobic support
- Figure Skating Singles → jump power, landing control, single-leg strength, rotation speed

## Evidence-informed programming framework

Generated programs now emphasize:
- sprint and power work before fatigue
- adequate recovery for quality sprint repetitions
- progressive strength with reps in reserve
- combined strength, plyometric, and sprint exposure
- reactive change-of-direction instead of only pre-planned drills
- position-specific work/rest demands
- season phase: Off-season, Pre-season, In-season
- readiness-aware volume reduction when readiness is below 60
- developmentally appropriate technique and supervision

All Phase 72.2 account, Parent multi-player, Coach Team, team invite, cloud sync, setup, Help, readiness, testing, goals, analytics, competition, and beta feedback features are preserved.


## Navigation scroll behavior

Whenever the user opens a different app section/tab, the page automatically returns to the top of the newly opened section. This applies to the simplified bottom navigation, grouped navigation, setup/help navigation, and feature-search navigation because they all use the same tab state.


## Phase 72.3.2 syntax fix

Removed an accidental leading backslash at the start of `components/BetaGate.tsx` that caused Next.js/SWC to report `Expected unicode escape`. No app functionality was removed.


## Phase 72.3.3 syntax fix

Fixed the malformed `mainSets("3","2")` call in the sport/position workout generator that caused Next.js to report `Expected ',', got 'numeric literal (3, 3)'`.

Everything from Phase 72.3.2 is preserved.


## Phase 72.3.4 verification fixes

A deeper code review found and corrected several non-syntax issues:

- cloud workspace switching now waits for the selected athlete's cloud data to finish loading before autosave can begin
- prevents a slow network response from risking the previous athlete's data being saved into a newly selected athlete workspace
- Parent accounts no longer attempt cloud writes that their read-only permissions correctly reject
- Soccer Center Back now receives a dedicated Center Back training-demand profile rather than the Fullback profile
- beta version labels and feedback version now match 72.3.4
- `.gitignore` is included in the release package

The previous BetaGate and workout-generator syntax fixes remain included.


## Phase 72.3.5 Supabase migration fix

Fixed the `parent_create_athlete` PostgreSQL function. Its `RETURNS TABLE` declaration used `position` as an output-column identifier, which PostgreSQL parsed as a keyword in this context and rejected with `syntax error at or near "position"`.

The output column is now `athlete_position`. The app only relies on the returned athlete id, workspace id, and display name, so this change does not remove or change any app functionality.

The migration remains safe to re-run over the partially created Phase 72.2/72.3 beta schema because its tables use `IF NOT EXISTS`, functions use `CREATE OR REPLACE`, triggers are dropped before recreation, and policies are dropped before recreation.


## Phase 72.3.6 Admin Roster fix

Fixed two Admin navigation issues introduced by the simplified navigation:
- Admin's visible tab list now includes `Roster`, so **More** correctly offers both Competition and Roster.
- The Roster page renderer now allows both Coach and Admin roles.

Also permanently includes the authenticated API grants that were required for the live Supabase beta so future database setups do not hit the false `Account is not active` state.


## Phase 72.3.7 — Setup + complete feature overview

The guided setup now teaches the simplified five-button navigation while users complete the essential setup tasks.

After setup finishes, the app automatically opens a quick role-specific tour containing:
- Overview / Plan / Train / Progress / More navigation map
- a 3-step explanation of how to navigate
- every in-app feature available to the signed-in role
- a short description of what each feature does
- exactly where each feature lives in the simple navigation
- direct Open buttons for every feature
- role-specific account tools for Player, Parent, Coach, or Admin
- Start Using App button after setup
- Restart Setup Guide option

After setup has already been completed, the header **Help** button opens the same feature guide as an always-available “How to use the app” reference.

No app functionality was removed.


## Phase 72.3.8 — Guided setup Continue label

Changed the green next-step button in Guided Setup from **Skip this step** to **Continue**. The final setup button remains **Finish**.


## Phase 72.3.9 — Player Setup save gate + sport-first profile

Fixed Guided Setup so Player Setup cannot advance while the user is still filling out the player.

Changes:
- Player profile editing now uses a temporary draft instead of saving every keystroke.
- Guided Setup advances only after **Save Player** is tapped and the required player fields are complete.
- The setup guide's Continue button cannot bypass an unsaved Player Setup step.
- Player Setup now includes **Sport** inside the profile form.
- Sport appears before Position and changing Sport resets Position, ensuring the Position dropdown always matches the selected sport.
- Profile edits can be canceled without changing saved player data.
- Player profile summary now includes Sport.


## Phase 72.3.10 — Guided setup exploration-step fix

Fixed the informational setup steps so opening a feature no longer immediately advances to the next setup step.

Updated Development, Competition, and Roster setup steps:
- tapping the green Open button now actually leaves the guide open in the selected app feature;
- the setup banner tells the user to explore the feature;
- **Return to Guide** brings the user back to the same setup step;
- **Continue** then advances manually to the next setup step.

Action-driven setup steps such as Player Setup, Goals, Testing, Schedule, and Readiness still auto-advance only after their required action is completed.


## Phase 72.3.11 — Age-aware, sport/position-specific workouts + custom workout builder

- Added player **Age** to Player Setup and profile data.
- The recommended workout generator now requires and uses Sport + exact Position + Age, then further adjusts for season phase, readiness, and equipment.
- Added age-band guardrails for weekly frequency, session length, strength volume, speed/power volume, and youth exercise progression.
- Replaced generic movement blocks with sport- and position-specific warm-ups, speed patterns, reaction drills, skill-transfer work, and conditioning patterns.
- Shared foundational strength remains only where the same movement quality is appropriate across sports.
- Removed generic YouTube search and Google image-search links. The app now shows a demo only when a specific curated resource is mapped to that exercise/sport/position.
- Added a Player-accessible **Create Your Own Custom Workout** builder with exercise-by-exercise phases, sets, reps/time, rest, purpose, and instructions. Custom workouts save directly to Schedule.
- Generated workouts now save their exercise list to Schedule too, and the Workout Log can expand those exercises.
- Existing cloud workspace storage automatically carries the new profile age and custom workout fields; no Supabase schema migration is required.
