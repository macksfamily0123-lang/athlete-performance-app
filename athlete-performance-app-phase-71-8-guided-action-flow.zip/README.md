# Athlete Performance App — Phase 71.8

## Action-driven setup guide
The first-use setup now works as an interactive workflow:

- Each setup step has a button that opens the exact part of the app needed for that step.
- The setup overlay closes while the user completes the action.
- Once the required information exists, the guide automatically reopens on the next step.
- A Setup in Progress banner remains visible while the app is waiting for the user to finish a step.
- Users can return to the guide manually at any time.
- Every step can still be skipped.
- The entire setup can still be skipped.

Required auto-advance steps:
1. Complete Player Profile
2. Create first Goal
3. Log first Performance Test
4. Schedule first Workout
5. Complete first Readiness check-in

Development, Competition, and Roster are guided exploration steps rather than required data-entry steps.

The bottom navigation slider from Phase 71.7 is preserved.
