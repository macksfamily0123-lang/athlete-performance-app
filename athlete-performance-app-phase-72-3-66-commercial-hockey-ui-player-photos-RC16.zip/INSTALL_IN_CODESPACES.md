# Phase 72.3.66 RC16 — Codespaces Install

Baseline: completed Phase 72.3.64 RC15 only. Phase 72.3.65 was not used.

## What this release changes
- Commercial Hockey Dev visual refresh based on the approved app-store concept.
- Recognizable hockey rink/skater/stick/puck hero art.
- Brighter forest green with blue, violet, amber/orange, mint, and cyan accents.
- Richer cards, menu styling, charts/progress accents, and mobile navigation.
- Mobile-first Add/Change Player Photo in Player Profile.
- Photos on Home, Roster, Coach cloud roster, Parent My Players, and athlete roster cards.
- Hockey fallback avatar when a photo has not been added.

## What this release preserves
- Supabase backend and cloud state flow.
- Player / Coach / Parent / Admin roles and permissions.
- Junior Player mode.
- Player More gateway fix.
- Cloud test athletes.
- Family/connection workflows.
- Migration 009 unchanged.

## Database
There is NO new database migration in 72.3.66. Migration 009 remains the newest required migration.
Player photos are resized on the phone and saved inside the existing cloud-synced Player Profile state.

## Install in Codespaces
From the root of your current app, make a backup first, then unzip this release over the project.

1. Stop the running dev server if it is currently running.
2. Upload this ZIP into the project root.
3. Run the commands from ChatGPT one at a time.
4. No Supabase SQL update is required if migration 009 is already installed.
