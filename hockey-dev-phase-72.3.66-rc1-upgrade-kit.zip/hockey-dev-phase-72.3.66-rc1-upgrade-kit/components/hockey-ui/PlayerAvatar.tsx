import React from "react";

type PlayerAvatarProps = {
  src?: string | null;
  name?: string | null;
  size?: number;
  className?: string;
  ring?: "green" | "blue" | "violet" | "amber" | "none";
};

export function PlayerAvatar({
  src,
  name = "Player",
  size = 56,
  className = "",
  ring = "green",
}: PlayerAvatarProps) {
  const fallback = "/hockey-ui/fallback-avatar.svg";
  return (
    <img
      src={src || fallback}
      alt={`${name || "Player"} profile`}
      width={size}
      height={size}
      loading="lazy"
      className={`hd-player-avatar hd-ring-${ring} ${className}`}
      onError={(e) => {
        const img = e.currentTarget;
        if (!img.src.endsWith(fallback)) img.src = fallback;
      }}
      style={{ width: size, height: size }}
    />
  );
}
