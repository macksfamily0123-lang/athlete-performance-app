import React from "react";

export function HockeyHero({ children }: { children?: React.ReactNode }) {
  return (
    <section className="hd-hockey-hero">
      <img
        src="/hockey-ui/hockey-player-hero.svg"
        alt="Hockey player skating with a stick and puck on the rink"
        className="hd-hockey-hero-art"
      />
      {children && <div className="hd-hockey-hero-content">{children}</div>}
    </section>
  );
}
