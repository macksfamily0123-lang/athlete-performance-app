/* Mobile-first player photo uploader.
   Wire savePhotoUrl() to the existing RC15 athlete/profile save flow.
   The helper below uploads to Supabase Storage bucket "player-photos".
*/
"use client";

import React, { useRef, useState } from "react";
import { PlayerAvatar } from "./PlayerAvatar";

type Props = {
  athleteId: string;
  playerName?: string | null;
  currentPhotoUrl?: string | null;
  supabase: any;
  onSaved?: (publicUrl: string) => void;
};

export function PlayerPhotoUploader({
  athleteId,
  playerName,
  currentPhotoUrl,
  supabase,
  onSaved,
}: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [preview, setPreview] = useState<string | null>(currentPhotoUrl || null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  async function choose(file?: File) {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setMessage("Choose a photo from your phone.");
      return;
    }
    if (file.size > 8 * 1024 * 1024) {
      setMessage("Photo must be 8 MB or smaller.");
      return;
    }

    const localPreview = URL.createObjectURL(file);
    setPreview(localPreview);
    setBusy(true);
    setMessage("Uploading…");

    try {
      const ext = (file.name.split(".").pop() || "jpg").toLowerCase();
      const path = `${athleteId}/profile-${Date.now()}.${ext}`;
      const { error } = await supabase.storage
        .from("player-photos")
        .upload(path, file, { upsert: true, cacheControl: "3600" });
      if (error) throw error;

      const { data } = supabase.storage.from("player-photos").getPublicUrl(path);
      const url = data.publicUrl;

      // Non-destructive companion table introduced by migration 010.
      const { error: upsertError } = await supabase
        .from("player_photos")
        .upsert({
          athlete_id: athleteId,
          photo_url: url,
          updated_at: new Date().toISOString(),
        }, { onConflict: "athlete_id" });
      if (upsertError) throw upsertError;

      setPreview(url);
      setMessage("Photo updated.");
      onSaved?.(url);
    } catch (err: any) {
      setMessage(err?.message || "Photo upload failed.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="hd-photo-uploader">
      <button
        type="button"
        className="hd-photo-button"
        aria-label="Add or change player photo"
        onClick={() => inputRef.current?.click()}
        disabled={busy}
      >
        <PlayerAvatar src={preview} name={playerName} size={112} />
        <span className="hd-photo-camera" aria-hidden>📷</span>
      </button>
      <button
        type="button"
        className="hd-photo-action"
        onClick={() => inputRef.current?.click()}
        disabled={busy}
      >
        {preview ? "Change player photo" : "Add player photo"}
      </button>
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        capture="user"
        hidden
        onChange={(e) => choose(e.target.files?.[0])}
      />
      {message && <div className="hd-photo-message" role="status">{message}</div>}
    </div>
  );
}
