#!/usr/bin/env bash
set -euo pipefail

echo "Hockey Dev Phase 72.3.66 RC1 upgrade layer"
echo "This installer is intentionally non-destructive."

if [ ! -f package.json ]; then
  echo "ERROR: Run this from the root of the completed Phase 72.3.64 RC15 app."
  exit 1
fi

if [ ! -d supabase/migrations ]; then
  echo "ERROR: supabase/migrations folder not found. RC15 baseline not verified."
  exit 1
fi

if ! find supabase/migrations -maxdepth 1 -type f | grep -Eq '/009[^/]*\.sql$'; then
  echo "ERROR: migration 009 was not found. Refusing to patch an unverified baseline."
  exit 1
fi

STAMP=$(date +%Y%m%d-%H%M%S)
mkdir -p ".phase-backups/$STAMP"
cp -R components styles public supabase/migrations ".phase-backups/$STAMP/" 2>/dev/null || true

mkdir -p components/hockey-ui styles public/hockey-ui supabase/migrations
cp -R ./phase-72.3.66-overlay/components/hockey-ui/* components/hockey-ui/
cp -R ./phase-72.3.66-overlay/styles/* styles/
cp -R ./phase-72.3.66-overlay/public/hockey-ui/* public/hockey-ui/
cp ./phase-72.3.66-overlay/supabase/migrations/010_player_photos.sql supabase/migrations/

echo
echo "Overlay files installed."
echo "Backup: .phase-backups/$STAMP"
echo
echo "IMPORTANT:"
echo "1) Import styles/hockey-commercial-refresh.css once in your global app entry."
echo "2) Wire PlayerPhotoUploader into the existing Player Profile using the existing Supabase client."
echo "3) Replace existing text/initial avatars with PlayerAvatar on Home, Roster, Parent My Players, Coach Roster and athlete cards."
echo "4) Run migration 010 in Supabase after reviewing your RC15 policies."
echo
echo "No existing RC15 source files were overwritten automatically."
