# Hockey Dev — Phase 72.3.66 RC1 Upgrade Kit

**Baseline:** Phase 72.3.64 RC15 only.

This package intentionally does **not** contain or use unfinished Phase 72.3.65 work.

## What is included
- Recognizable hockey player/skater + stick + puck + rink hero SVG.
- Forest-green commercial sports theme with blue, violet, amber/orange, mint, cyan and rose accents.
- Richer card, icon-tile, chart/accent and background styling.
- `PlayerAvatar` with a strong fallback avatar.
- Mobile-first `PlayerPhotoUploader` using phone camera/photo picker.
- Supabase Storage upload to `player-photos`.
- Non-destructive migration `010_player_photos.sql`; migration 009 remains untouched.
- Commercial app concept image for visual reference.

## Important baseline protection
The RC15 source ZIP was not available in the active File Library when this kit was created. Therefore this is an **upgrade layer**, not a falsely reconstructed full RC15 release. The installer refuses to run unless it can see migration 009.

## Integration targets
Wire `PlayerPhotoUploader` into Player Profile and use `PlayerAvatar` on:
- Player Home
- Roster
- Parent → My Players
- Coach → Roster
- Relevant athlete/player cards

Keep the existing RC15 role gates, permissions, Junior mode, Player More navigation, cloud test-athlete loading, and migration 009 unchanged.

## Styling
Import once from your existing global entry:

```ts
import "../styles/hockey-commercial-refresh.css";
```

Then add `hd-app-surface`, `hd-card`, `hd-icon-tile`, and accent classes alongside existing classes rather than deleting working RC15 classes.

## Supabase
Run `supabase/migrations/010_player_photos.sql` after reviewing it against the exact RC15 RLS conventions. It creates only a companion `player_photos` table and a `player-photos` Storage bucket.
