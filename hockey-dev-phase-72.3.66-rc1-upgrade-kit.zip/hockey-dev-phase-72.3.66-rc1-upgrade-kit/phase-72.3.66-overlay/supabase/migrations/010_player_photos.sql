-- Phase 72.3.66 RC1 companion migration.
-- Non-destructive: does not modify migration 009 or existing athlete/profile tables.

create table if not exists public.player_photos (
  athlete_id text primary key,
  photo_url text not null,
  updated_at timestamptz not null default now()
);

alter table public.player_photos enable row level security;

-- Existing RC15 role/permission logic remains authoritative for app access.
-- Authenticated users may read photo URLs; app-level athlete visibility still controls which athlete cards are rendered.
drop policy if exists "authenticated can read player photos" on public.player_photos;
create policy "authenticated can read player photos"
on public.player_photos for select
to authenticated
using (true);

drop policy if exists "authenticated can upsert player photos" on public.player_photos;
create policy "authenticated can upsert player photos"
on public.player_photos for insert
to authenticated
with check (true);

drop policy if exists "authenticated can update player photos" on public.player_photos;
create policy "authenticated can update player photos"
on public.player_photos for update
to authenticated
using (true)
with check (true);

insert into storage.buckets (id, name, public)
values ('player-photos','player-photos',true)
on conflict (id) do update set public = excluded.public;

drop policy if exists "authenticated can upload player photos" on storage.objects;
create policy "authenticated can upload player photos"
on storage.objects for insert
to authenticated
with check (bucket_id = 'player-photos');

drop policy if exists "authenticated can update player photos storage" on storage.objects;
create policy "authenticated can update player photos storage"
on storage.objects for update
to authenticated
using (bucket_id = 'player-photos')
with check (bucket_id = 'player-photos');

drop policy if exists "public can read player photos" on storage.objects;
create policy "public can read player photos"
on storage.objects for select
to public
using (bucket_id = 'player-photos');
