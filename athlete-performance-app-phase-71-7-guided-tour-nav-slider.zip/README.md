# Athlete Performance App — Phase 71.7

## New guided first-use walkthrough
After entering the app for the first time, users receive a step-by-step Getting Started guide.

The guide covers:
- profile setup
- sport selection
- Overview
- Goals
- Schedule
- Testing
- Progress
- Readiness / Coach tools
- Development and mental preparation
- Competition
- Roster for Coach/Admin users
- athlete switching for Coach/Parent/Admin users
- bottom navigation

Users can:
- Back up
- Skip / Next through every individual step
- Skip the entire tour
- replay the tour later with the new Help button

The completed-tour preference is saved on the device.

## Bottom navigation slider
The tab bar now includes:
- horizontal swipe/scroll
- a visible slider underneath the tabs
- “More tabs” and “Swipe ↔” guidance

Moving the slider actually scrolls the tab row, making hidden tabs discoverable on smaller phones.

All Phase 71.6 profile consolidation, role permissions, Figure Skating, training, testing, analytics, competition, and athlete-selector features are preserved.
