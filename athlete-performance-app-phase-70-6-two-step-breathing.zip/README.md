# Athlete Performance App — Phase 70.6

Mental preparation breathing update:
- Controlled Breathing is now a required two-step sequence.
- Step 1: Reilly Rescue Breathing — 6–10 rounds.
- Step 2: Box Breathing — 6–10 rounds.
- Reilly Rescue Breathing appears first by default.
- The athlete can move directly from Step 1 to Step 2.
- Final mental-preparation summary shows the Reilly Rescue → Box sequence.
- All Phase 70.5 features are preserved.
