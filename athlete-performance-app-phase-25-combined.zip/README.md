# Athlete Performance App — Combined Phase 24 + 25

Built from Phase 23 as one update.

## Phase 24 — Competition 2.0
- Confidence score
- Location and role/position context
- Biggest win / improve-next reflection
- Competition rating trend
- Recent and best rating
- Expanded season snapshot
- Existing sport-specific statistics preserved

## Phase 25 — Analytics 2.0
- Time-range filters
- Category filter
- Top improvement
- Needs-attention insight
- Baseline / current / best metrics
- Quantified trend cards
- Training consistency
- Goal progress
- CSV export
- Test comparison preserved

No new tabs were added. All Phase 1–23 functionality remains included.
