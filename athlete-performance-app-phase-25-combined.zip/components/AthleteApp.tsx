
"use client";
import {useEffect,useMemo,useState} from "react";

type Sport="Baseball"|"Football"|"Ice Hockey"|"Basketball"|"Lacrosse"|"Wrestling"|"Soccer";
type TestDef={id:string;name:string;category:string;unit:string;lowerBetter:boolean};
type CustomTest=TestDef&{sport:Sport};
type Result={id:number;testId:string;name:string;category:string;unit:string;value:number;date:string;sport:Sport};
type Goal={id:number;title:string;progress:number;type:"Short-term"|"Long-term";category?:string;deadline?:string;target?:string;linkedTestId?:string;status?:"Active"|"Complete"|"Paused";notes?:string};
type Workout={id:number;date:string;name:string;category:string;minutes:number;completed:boolean;sport:Sport;intensity?:"Easy"|"Moderate"|"Hard";rpe?:number;notes?:string;focus?:string};
type Profile={name:string;position:string;team:string;season:string;height:string;weight:string;handedness:"Right"|"Left"};
type DevelopmentItem={id:number,title:string,category:string,target:string,dueDate:string,status:"Not Started"|"In Progress"|"Complete"};
type ProgramSession={id:number;day:string;name:string;category:string;minutes:number;focus:string;completed:boolean};
type TrainingProgram={id:number;created:string;sport:Sport;position:string;focus:string;daysPerWeek:number;sessions:ProgramSession[]};
type ReadinessLog={id:number;date:string;sleep:number;soreness:number;energy:number;stress:number;notes:string};
type CoachNote={id:number;date:string;title:string;note:string;category:string};
type StatEntry={label:string;value:string};
type CompetitionLog={id:number;date:string;opponent:string;eventType:string;result:string;minutes:string;rating:number;notes:string;sport:Sport;stats:StatEntry[];location?:string;role?:string;keyWin?:string;improveNext?:string;confidence?:number};
type ReportNote={id:number;date:string;title:string;body:string};
type AthleteRecord={id:string;name:string;sport:Sport;position:string;team:string;season:string;height:string;weight:string;handedness:"Right"|"Left"};
type AthleteSnapshot={profile:Profile;goals:Goal[];workouts:Workout[];results:Result[];development:DevelopmentItem[];program:TrainingProgram|null;readiness:ReadinessLog[];coachNotes:CoachNote[];competitions:CompetitionLog[];reportNotes:ReportNote[]};
type BackupEnvelope={version:string;created:string;activeAthleteId:string;roster:AthleteRecord[];athletes:Record<string,AthleteSnapshot>};
type Achievement={id:string;title:string;description:string;category:string;earned:boolean;progress:number};
type Milestone={id:number;date:string;title:string;detail:string;category:string};
type Recommendation={id:string;title:string;reason:string;action:string;priority:"High"|"Medium"|"Low";category:string};
type WeeklyReview={id:number;weekStart:string;wins:string;challenges:string;focus:string;rating:number};
type TestTarget={id:string;testId:string;sport:Sport;target:string;retestDate:string;notes:string};
type TestProtocol={name:string;setup:string;instructions:string;quality:string};

type SeasonEvent={id:number;date:string;title:string;eventType:"Game"|"Tournament"|"Testing"|"Training Block"|"Recovery"|"Other";priority:"High"|"Normal";notes:string};
type TrainingBlock={id:number;name:string;startDate:string;endDate:string;focus:string;target:string;completed:boolean};







const navMeta:Record<string,{icon:string;label:string}>={
 Home:{icon:"⌂",label:"Home"},
 Goals:{icon:"◎",label:"Goals"},
 Calendar:{icon:"◫",label:"Calendar"},
 Testing:{icon:"⚡",label:"Testing"},
 Analytics:{icon:"⌁",label:"Analytics"},
 Coach:{icon:"✦",label:"Coach"},
 Development:{icon:"◇",label:"Development"},
 Competition:{icon:"◆",label:"Competition"},
 Roster:{icon:"◉",label:"Roster"}
};
const sports:Sport[]=["Baseball","Football","Ice Hockey","Basketball","Lacrosse","Wrestling","Soccer"];
const categories=["Speed","Agility","Power","Strength","Endurance","Skill","Conditioning","Other"];
const units=["sec","min","mph","km/h","in","ft","lb","kg","reps","yards","meters","points","%","Other"];
const competitionStats:Record<Sport,string[]>={
 Baseball:["At Bats","Hits","Runs","RBI","Walks","Strikeouts","Stolen Bases"],
 Football:["Touches","Yards","Receptions","Tackles","Sacks","Touchdowns","Interceptions"],
 "Ice Hockey":["Goals","Assists","Shots","Plus/Minus","Penalty Minutes","Faceoff %"],
 Basketball:["Points","Rebounds","Assists","Steals","Blocks","Turnovers"],
 Lacrosse:["Goals","Assists","Shots","Ground Balls","Caused Turnovers","Faceoff %"],
 Wrestling:["Takedowns","Escapes","Reversals","Near Fall","Penalty Points","Match Points"],
 Soccer:["Goals","Assists","Shots","Shots on Target","Pass %","Tackles","Saves"]
};

const testProtocols:Record<string,TestProtocol>={
 "10-yard sprint":{name:"10-yard sprint",setup:"Flat surface, measured 10-yard lane, consistent start line.",instructions:"Use the same starting stance each time. Sprint through the finish. Record the best valid time.",quality:"Use the same timing method, shoes, surface, and warm-up each session."},
 "20-yard sprint":{name:"20-yard sprint",setup:"Flat measured 20-yard lane with clear start and finish.",instructions:"Use a consistent stance and sprint through the line. Record the best valid time.",quality:"Keep timing method and surface consistent."},
 "40-yard sprint":{name:"40-yard sprint",setup:"Flat measured 40-yard lane.",instructions:"Use the same starting stance and record the best clean attempt.",quality:"Use the same timing system and rest fully between attempts."},
 "5-10-5 shuttle":{name:"5-10-5 shuttle",setup:"Three lines spaced 5 yards apart.",instructions:"Start at the middle line, sprint 5 yards, change direction 10 yards, then finish through the middle.",quality:"Use the same first direction and hand-touch standard every time."},
 "Vertical jump":{name:"Vertical jump",setup:"Use the same jump device or wall-reach method.",instructions:"Use a consistent countermovement and record the best valid jump.",quality:"Keep arm-swing rules and measuring method identical."},
 "Broad jump":{name:"Broad jump",setup:"Flat non-slip surface and tape measure.",instructions:"Two-foot takeoff and landing. Measure from start line to the nearest heel.",quality:"Use the same footwear and landing standard."},
 "Bench press":{name:"Bench press",setup:"Standard bench, barbell, safety spotter.",instructions:"Use the same testing method each time, such as 1RM or fixed-rep load.",quality:"Do not compare different rep schemes as the same test."},
 "Squat":{name:"Squat",setup:"Rack, barbell, safety setup.",instructions:"Use the same squat style, depth standard, and rep scheme each test.",quality:"Keep technique standard consistent before comparing results."},
 "Pull-ups":{name:"Pull-ups",setup:"Stable pull-up bar.",instructions:"Use the same grip and full range-of-motion standard each test.",quality:"Avoid changing grip width or kipping rules between tests."}
};


const positions:Record<Sport,string[]>={
 Soccer:["Goalkeeper","Center Back","Left Back","Right Back","Defensive Midfielder","Central Midfielder","Attacking Midfielder","Left Wing","Right Wing","Striker","Forward"],
 Baseball:["Pitcher","Catcher","First Base","Second Base","Third Base","Shortstop","Left Field","Center Field","Right Field","Utility"],
 Football:["Quarterback","Running Back","Fullback","Wide Receiver","Tight End","Offensive Line","Defensive Line","Linebacker","Cornerback","Safety","Kicker","Punter","Long Snapper"],
 "Ice Hockey":["Center","Left Wing","Right Wing","Defense","Goaltender"],
 Basketball:["Point Guard","Shooting Guard","Small Forward","Power Forward","Center"],
 Lacrosse:["Attack","Midfield","Defense","Faceoff Specialist","Goalie"],
 Wrestling:["Wrestler"]
};

const raw:Record<Sport,string[][]>={
 Baseball:[["10-yard sprint","Speed","sec","1"],["20-yard sprint","Speed","sec","1"],["5-10-5 shuttle","Agility","sec","1"],["Vertical jump","Power","in","0"],["Broad jump","Power","in","0"],["Bench press","Strength","lb","0"]],
 Football:[["10-yard sprint","Speed","sec","1"],["40-yard sprint","Speed","sec","1"],["5-10-5 shuttle","Agility","sec","1"],["Vertical jump","Power","in","0"],["Broad jump","Power","in","0"],["Bench press","Strength","lb","0"],["Squat","Strength","lb","0"]],
 "Ice Hockey":[["10-yard sprint","Speed","sec","1"],["20-yard sprint","Speed","sec","1"],["Pro agility shuttle","Agility","sec","1"],["Vertical jump","Power","in","0"],["Broad jump","Power","in","0"],["Squat","Strength","lb","0"]],
 Basketball:[["10-yard sprint","Speed","sec","1"],["Lane agility","Agility","sec","1"],["Vertical jump","Power","in","0"],["Broad jump","Power","in","0"],["Squat","Strength","lb","0"]],
 Lacrosse:[["20-yard sprint","Speed","sec","1"],["Pro agility shuttle","Agility","sec","1"],["Vertical jump","Power","in","0"],["Broad jump","Power","in","0"],["Bench press","Strength","lb","0"]],
 Wrestling:[["20-yard sprint","Speed","sec","1"],["5-10-5 shuttle","Agility","sec","1"],["Vertical jump","Power","in","0"],["Broad jump","Power","in","0"],["Squat","Strength","lb","0"],["Pull-ups","Strength","reps","0"]]
};
const definitions=(sport:Sport):TestDef[]=>raw[sport].map((x,i)=>({id:`${sport}-${i}`,name:x[0],category:x[1],unit:x[2],lowerBetter:x[3]==="1"}));
const today=()=>new Date().toISOString().slice(0,10);
const daysAgo=(n:number)=>{const d=new Date();d.setDate(d.getDate()-n);return d.toISOString().slice(0,10)};
const improvement=(first:number,last:number,lower:boolean)=>first===0?0:Math.round((lower?(first-last)/first:(last-first)/first*100)*10)/10;
const pct=(n:number)=>Math.max(0,Math.min(100,Math.round(n)));

export default function AthleteApp(){
 const [sport,setSport]=useState<Sport>("Ice Hockey"),[tab,setTab]=useState("Home");
 const [results,setResults]=useState<Result[]>([]),[custom,setCustom]=useState<CustomTest[]>([]),[goals,setGoals]=useState<Goal[]>([]),[workouts,setWorkouts]=useState<Workout[]>([]),[profile,setProfile]=useState<Profile>({name:"Athlete",position:"",team:"",season:"2026-27",height:"",weight:"",handedness:"Right"});
 const [dev,setDev]=useState<DevelopmentItem[]>([]);
 const [program,setProgram]=useState<TrainingProgram|null>(null);
 const [readiness,setReadiness]=useState<ReadinessLog[]>([]);
 const [coachNotes,setCoachNotes]=useState<CoachNote[]>([]);
 const [competitions,setCompetitions]=useState<CompetitionLog[]>([]);
 const [reportNotes,setReportNotes]=useState<ReportNote[]>([]);
 const [roster,setRoster]=useState<AthleteRecord[]>([]);
 const [activeAthleteId,setActiveAthleteId]=useState("primary");
 const [milestones,setMilestones]=useState<Milestone[]>([]);
 const [seasonEvents,setSeasonEvents]=useState<SeasonEvent[]>([]);
 const [trainingBlocks,setTrainingBlocks]=useState<TrainingBlock[]>([]);
 const [weeklyReviews,setWeeklyReviews]=useState<WeeklyReview[]>([]);
 const [testTargets,setTestTargets]=useState<TestTarget[]>([]);
 const [mounted,setMounted]=useState(false);
 useEffect(()=>{for(const [key,setter] of [["results",setResults],["custom",setCustom],["goals",setGoals],["workouts",setWorkouts]] as any[]){try{const v=localStorage.getItem(key);if(v)setter(JSON.parse(v))}catch{}}},[]);
 useEffect(()=>localStorage.setItem("results",JSON.stringify(results)),[results]);
 useEffect(()=>localStorage.setItem("custom",JSON.stringify(custom)),[custom]);
 useEffect(()=>localStorage.setItem("goals",JSON.stringify(goals)),[goals]);
 useEffect(()=>localStorage.setItem("workouts",JSON.stringify(workouts)),[workouts]);
useEffect(()=>{try{const v=localStorage.getItem("profile");if(v){const x=JSON.parse(v);setProfile({name:x?.name??"Athlete",position:x?.position??"",team:x?.team??"",season:x?.season??"2026-27",height:x?.height??"",weight:x?.weight??"",handedness:x?.handedness==="Left"?"Left":"Right"})}}catch{}},[]);
useEffect(()=>localStorage.setItem("profile",JSON.stringify(profile)),[profile]);
useEffect(()=>{try{const v=localStorage.getItem("development");if(v)setDev(JSON.parse(v))}catch{}},[]);
useEffect(()=>localStorage.setItem("development",JSON.stringify(dev)),[dev]);
useEffect(()=>{try{const v=localStorage.getItem("trainingProgram");if(v)setProgram(JSON.parse(v))}catch{}},[]);
useEffect(()=>{if(program)localStorage.setItem("trainingProgram",JSON.stringify(program));else localStorage.removeItem("trainingProgram")},[program]);
 useEffect(()=>{try{const v=localStorage.getItem("readiness");if(v)setReadiness(JSON.parse(v))}catch{}},[]);
 useEffect(()=>localStorage.setItem("readiness",JSON.stringify(readiness)),[readiness]);
 useEffect(()=>{try{const v=localStorage.getItem("coachNotes");if(v)setCoachNotes(JSON.parse(v))}catch{}},[]);
 useEffect(()=>localStorage.setItem("coachNotes",JSON.stringify(coachNotes)),[coachNotes]);
 useEffect(()=>{try{const v=localStorage.getItem("competitions");if(v)setCompetitions(JSON.parse(v))}catch{}},[]);
 useEffect(()=>localStorage.setItem("competitions",JSON.stringify(competitions)),[competitions]);
 useEffect(()=>{try{const v=localStorage.getItem("reportNotes");if(v)setReportNotes(JSON.parse(v))}catch{}},[]);
 useEffect(()=>localStorage.setItem("reportNotes",JSON.stringify(reportNotes)),[reportNotes]);
 useEffect(()=>{try{const v=localStorage.getItem("athleteRoster");if(v)setRoster(JSON.parse(v))}catch{}},[]);
 useEffect(()=>localStorage.setItem("athleteRoster",JSON.stringify(roster)),[roster]);
 useEffect(()=>{try{const v=localStorage.getItem("activeAthleteId");if(v)setActiveAthleteId(v)}catch{}},[]);
 useEffect(()=>localStorage.setItem("activeAthleteId",activeAthleteId),[activeAthleteId]);
 useEffect(()=>{try{const v=localStorage.getItem(`milestones:${activeAthleteId}`);setMilestones(v?JSON.parse(v):[])}catch{setMilestones([])}},[activeAthleteId]);
 useEffect(()=>{try{localStorage.setItem(`milestones:${activeAthleteId}`,JSON.stringify(milestones))}catch{}},[activeAthleteId,milestones]);
 useEffect(()=>{try{const v=localStorage.getItem(`seasonEvents:${activeAthleteId}`);setSeasonEvents(v?JSON.parse(v):[])}catch{setSeasonEvents([])}},[activeAthleteId]);
 useEffect(()=>{try{localStorage.setItem(`seasonEvents:${activeAthleteId}`,JSON.stringify(seasonEvents))}catch{}},[activeAthleteId,seasonEvents]);
 useEffect(()=>{try{const v=localStorage.getItem(`trainingBlocks:${activeAthleteId}`);setTrainingBlocks(v?JSON.parse(v):[])}catch{setTrainingBlocks([])}},[activeAthleteId]);
 useEffect(()=>{try{localStorage.setItem(`trainingBlocks:${activeAthleteId}`,JSON.stringify(trainingBlocks))}catch{}},[activeAthleteId,trainingBlocks]);
 useEffect(()=>{try{const v=localStorage.getItem(`weeklyReviews:${activeAthleteId}`);setWeeklyReviews(v?JSON.parse(v):[])}catch{setWeeklyReviews([])}},[activeAthleteId]);
 useEffect(()=>{try{localStorage.setItem(`weeklyReviews:${activeAthleteId}`,JSON.stringify(weeklyReviews))}catch{}},[activeAthleteId,weeklyReviews]);
 useEffect(()=>{try{const v=localStorage.getItem(`testTargets:${activeAthleteId}`);setTestTargets(v?JSON.parse(v):[])}catch{setTestTargets([])}},[activeAthleteId]);
 useEffect(()=>{try{localStorage.setItem(`testTargets:${activeAthleteId}`,JSON.stringify(testTargets))}catch{}},[activeAthleteId,testTargets]);
 useEffect(()=>setMounted(true),[]);
 useEffect(()=>{try{localStorage.setItem(`athleteData:${activeAthleteId}`,JSON.stringify({profile,goals,workouts,results,development:dev,program,readiness,coachNotes,competitions,reportNotes}))}catch{}},[activeAthleteId,profile,goals,workouts,results,dev,program,readiness,coachNotes,competitions,reportNotes]);

 
 const storageKey=(id:string)=>`athleteData:${id}`;

 const buildSnapshot=():AthleteSnapshot=>({
   profile:{...profile},goals:[...goals],workouts:[...workouts],results:[...results],development:[...dev],program:program?{...program,sessions:program.sessions.map(x=>({...x}))}:null,readiness:[...readiness],coachNotes:[...coachNotes],competitions:[...competitions],reportNotes:[...reportNotes]
 });

 const saveActiveSnapshot=()=>{
   try{localStorage.setItem(storageKey(activeAthleteId),JSON.stringify(buildSnapshot()))}catch{}
 };

 const loadAthleteSnapshot=(id:string,record?:AthleteRecord)=>{
   try{
     const raw=localStorage.getItem(storageKey(id));
     if(raw){
       const x=JSON.parse(raw);
       setProfile({name:x?.profile?.name??record?.name??"Athlete",position:x?.profile?.position??record?.position??"",team:x?.profile?.team??record?.team??"",season:x?.profile?.season??record?.season??"2026-27",height:x?.profile?.height??record?.height??"",weight:x?.profile?.weight??record?.weight??"",handedness:x?.profile?.handedness==="Left"?"Left":"Right"});
       setGoals(Array.isArray(x?.goals)?x.goals:[]);
       setWorkouts(Array.isArray(x?.workouts)?x.workouts:[]);
       setResults(Array.isArray(x?.results)?x.results:[]);
       setDev(Array.isArray(x?.development)?x.development:[]);
       setProgram(x?.program??null);
       setReadiness(Array.isArray(x?.readiness)?x.readiness:[]);
       setCoachNotes(Array.isArray(x?.coachNotes)?x.coachNotes:[]);
       setCompetitions(Array.isArray(x?.competitions)?x.competitions:[]);
       setReportNotes(Array.isArray(x?.reportNotes)?x.reportNotes:[]);
     }else if(record){
       setProfile({name:record.name,position:record.position,team:record.team,season:record.season,height:record.height,weight:record.weight,handedness:record.handedness});
       setGoals([]);setWorkouts([]);setResults([]);setDev([]);setProgram(null);setReadiness([]);setCoachNotes([]);setCompetitions([]);setReportNotes([]);
     }
     if(record)setSport(record.sport);
   }catch{}
 };

 const switchAthlete=(record:AthleteRecord)=>{
   saveActiveSnapshot();
   setActiveAthleteId(record.id);
   loadAthleteSnapshot(record.id,record);
 };

 if(!mounted)return <div className="app hydrationShell"><header><div className="logo">AP</div><div><strong>Athlete Performance</strong><small>Loading athlete dashboard…</small></div></header><main><div className="hydrationCard"><div className="hydrationPulse"/><div><b>Loading your performance data</b><small>Your saved athlete data will appear in a moment.</small></div></div></main></div>;
 return <div className="app">
  <header><div className="logo">AP</div><div><strong>Athlete Performance</strong><small>Train with purpose.</small></div></header>
  <div className="contextBar"><span className="contextAthlete">{profile.name}</span><span>•</span><span>{sport}</span>{profile.position&&<><span>•</span><span>{profile.position}</span></>}</div>
  <main>
   <div className="sports">{sports.map(s=><button className={sport===s?"sel":""} onClick={()=>{setSport(s);setProfile((x:Profile)=>({...x,position:positions[s].includes(x.position)?x.position:""}))}} key={s}>{s}</button>)}</div>
   {tab==="Home"&&<Home sport={sport} goals={goals} workouts={workouts} results={results} profile={profile} setProfile={setProfile} readiness={readiness} competitions={competitions} dev={dev} program={program} weeklyReviews={weeklyReviews} setWeeklyReviews={setWeeklyReviews}/>} 
   {tab==="Goals"&&<Goals goals={goals} setGoals={setGoals}/>}
   {tab==="Calendar"&&<Calendar sport={sport} workouts={workouts} setWorkouts={setWorkouts} profile={profile} seasonEvents={seasonEvents} setSeasonEvents={setSeasonEvents} trainingBlocks={trainingBlocks} setTrainingBlocks={setTrainingBlocks} competitions={competitions}/>} 
   {tab==="Testing"&&<Testing sport={sport} library={[...definitions(sport),...custom.filter(x=>x.sport===sport)]} custom={custom} setCustom={setCustom} results={results} setResults={setResults} testTargets={testTargets} setTestTargets={setTestTargets}/>} 
   {tab==="Analytics"&&<><Analytics sport={sport} results={results} goals={goals} workouts={workouts}/><Reports sport={sport} profile={profile} goals={goals} workouts={workouts} results={results} dev={dev} program={program} readiness={readiness} competitions={competitions} reportNotes={reportNotes} setReportNotes={setReportNotes}/></>} 
   {tab==="Coach"&&<><Readiness sport={sport} readiness={readiness} setReadiness={setReadiness} coachNotes={coachNotes} setCoachNotes={setCoachNotes} program={program} workouts={workouts}/><SmartCoach sport={sport} profile={profile} goals={goals} workouts={workouts} results={results} dev={dev} program={program} readiness={readiness} competitions={competitions}/></>} 
   
   {tab==="Development"&&<><Development sport={sport} profile={profile} dev={dev} setDev={setDev} results={results} goals={goals} workouts={workouts} program={program} readiness={readiness} competitions={competitions} milestones={milestones} setMilestones={setMilestones}/><Program sport={sport} profile={profile} dev={dev} results={results} program={program} setProgram={setProgram} setWorkouts={setWorkouts}/></>} 
   
   
   {tab==="Competition"&&<Competition sport={sport} competitions={competitions} setCompetitions={setCompetitions} profile={profile}/>} 
   
   {tab==="Roster"&&<><Roster sport={sport} profile={profile} roster={roster} setRoster={setRoster} activeAthleteId={activeAthleteId} switchAthlete={switchAthlete}/><DataCenter profile={profile} sport={sport} roster={roster} activeAthleteId={activeAthleteId} goals={goals} workouts={workouts} results={results} dev={dev} program={program} readiness={readiness} coachNotes={coachNotes} competitions={competitions} reportNotes={reportNotes} setProfile={setProfile} setGoals={setGoals} setWorkouts={setWorkouts} setResults={setResults} setDev={setDev} setProgram={setProgram} setReadiness={setReadiness} setCoachNotes={setCoachNotes} setCompetitions={setCompetitions} setReportNotes={setReportNotes} setRoster={setRoster} setActiveAthleteId={setActiveAthleteId} setSport={setSport}/></>} 
   
    
  </main>
  <nav className="mainNav">{["Home","Goals","Calendar","Testing","Analytics","Coach","Development","Competition","Roster"].map(x=><button className={tab===x?"active":""} onClick={()=>setTab(x)} key={x}><span className="navIcon">{navMeta[x]?.icon||"•"}</span><span className="navLabel">{navMeta[x]?.label||x}</span></button>)}</nav>
 </div>
}

function Home({sport,goals,workouts,results,profile,setProfile,readiness,competitions,dev,program,weeklyReviews,setWeeklyReviews}:{sport:Sport;goals:Goal[];workouts:Workout[];results:Result[];profile:Profile;setProfile:any;readiness:ReadinessLog[];competitions:CompetitionLog[];dev:DevelopmentItem[];program:TrainingProgram|null;weeklyReviews:WeeklyReview[];setWeeklyReviews:React.Dispatch<React.SetStateAction<WeeklyReview[]>>}){
 const gs=goals.length?Math.round(goals.reduce((a,g)=>a+g.progress,0)/goals.length):0;
 const ws=workouts.filter(x=>x.sport===sport),done=ws.filter(x=>x.completed).length;
 const rs=results.filter(x=>x.sport===sport);
 const score=pct(gs*.4+(ws.length?done/ws.length*30:0)+(rs.length?30:0));

 const todayDate=today();
 const upcoming=ws.filter(w=>!w.completed&&w.date>=todayDate).sort((a,b)=>a.date.localeCompare(b.date)).slice(0,3);
 const sportComps=competitions.filter(c=>c.sport===sport&&c.date>=todayDate).sort((a,b)=>a.date.localeCompare(b.date)).slice(0,2);
 const openDev=dev.filter(d=>d.status!=="Complete").slice(0,2);

 const recentReadiness=readiness.slice(0,7);
 const avgReadiness=recentReadiness.length?Math.round(recentReadiness.reduce((a,r)=>a+Math.max(0,Math.min(100,Math.round(Math.min(10,r.sleep/8*10)*2.5+(10-Math.min(10,r.soreness))*2.5+Math.min(10,r.energy)*2.5+(10-Math.min(10,r.stress))*2.5))),0)/recentReadiness.length):0;

 const completedThisWeek=ws.filter(w=>w.completed&&new Date(w.date).getTime()>=Date.now()-7*86400000).length;
 const testingThisWeek=rs.filter(r=>new Date(r.date).getTime()>=Date.now()-7*86400000).length;
 const programPct=program?.sessions.length?Math.round(program.sessions.filter(s=>s.completed).length/program.sessions.length*100):0;

 const [wins,setWins]=useState(""),[challenges,setChallenges]=useState(""),[focus,setFocus]=useState(""),[rating,setRating]=useState("8");
 const weekStart=(()=>{const d=new Date();const day=d.getDay();d.setDate(d.getDate()-((day+6)%7));return d.toISOString().slice(0,10)})();
 const currentReview=weeklyReviews.find(r=>r.weekStart===weekStart);

 const saveReview=()=>{
  const item:WeeklyReview={id:currentReview?.id||Date.now(),weekStart,wins:wins.trim(),challenges:challenges.trim(),focus:focus.trim(),rating:Number(rating)||0};
  setWeeklyReviews(x=>[item,...x.filter(r=>r.weekStart!==weekStart)]);
 };

 useEffect(()=>{
  if(currentReview){setWins(currentReview.wins);setChallenges(currentReview.challenges);setFocus(currentReview.focus);setRating(String(currentReview.rating))}
 },[currentReview?.id]);

 const streak=(()=>{
  const dates=[...new Set(ws.filter(w=>w.completed).map(w=>w.date))].sort((a,b)=>b.localeCompare(a));
  if(!dates.length)return 0;
  let count=0;let cursor=new Date(todayDate);
  for(let i=0;i<14;i++){
    const d=cursor.toISOString().slice(0,10);
    if(dates.includes(d)){count++;cursor.setDate(cursor.getDate()-1)}
    else if(i===0){cursor.setDate(cursor.getDate()-1)}
    else break;
  }
  return count;
 })();

 return <><div className="activeAthleteBanner"><small>ACTIVE ATHLETE</small><b>{profile.name}</b><span>{sport}{profile.position?" · "+profile.position:""}</span></div>
 <div className="hero homeHero"><small>ATHLETE COMMAND CENTER</small><h1>{profile.name}</h1><p>{sport}{profile.position?" · "+profile.position:""}{profile.team?" · "+profile.team:""} · {profile.season}</p><div className="heroBadges"><span>{score}/100 Performance</span><span>{avgReadiness||"—"} Readiness</span><span>{streak} Day Streak</span></div></div>

 <div className="grid three homeStats">
  <div className="stat"><small>Performance</small><b>{score}</b><span>/100</span></div>
  <div className="stat"><small>Goal Progress</small><b>{gs}%</b></div>
  <div className="stat"><small>Program</small><b>{program?programPct+"%":"—"}</b></div>
 </div>

 <div className="card profileCard"><div className="sectionHead"><h2>Athlete Profile</h2><span className="tag">{sport}</span></div><div className="two"><label>Name<input value={profile.name??""} onChange={e=>setProfile((x:Profile)=>({...x,name:e.target.value}))}/></label><label>Position<select value={positions[sport].includes(profile.position)?profile.position:""} onChange={e=>setProfile((x:Profile)=>({...x,position:e.target.value}))}><option value="">Select position</option>{positions[sport].map(x=><option key={x}>{x}</option>)}</select></label><label>Team<input value={profile.team??""} onChange={e=>setProfile((x:Profile)=>({...x,team:e.target.value}))}/></label><label>Season<input value={profile.season??""} onChange={e=>setProfile((x:Profile)=>({...x,season:e.target.value}))}/></label><label>Height<input value={profile.height??""} onChange={e=>setProfile((x:Profile)=>({...x,height:e.target.value}))} placeholder="e.g. 5'10&quot;"/></label><label>Weight<input inputMode="decimal" value={profile.weight??""} onChange={e=>setProfile((x:Profile)=>({...x,weight:e.target.value}))} placeholder="e.g. 165 lb"/></label><label>Handedness<select value={profile.handedness??"Right"} onChange={e=>setProfile((x:Profile)=>({...x,handedness:e.target.value as "Right"|"Left"}))}><option>Right</option><option>Left</option></select></label></div></div>

 <div className="sectionDivider"><span><i/>This Week</span></div>
 <div className="grid three">
  <div className="stat"><small>Workouts Done</small><b>{completedThisWeek}</b></div>
  <div className="stat"><small>Tests Logged</small><b>{testingThisWeek}</b></div>
  <div className="stat"><small>7-Day Readiness</small><b>{avgReadiness||"—"}</b></div>
 </div>

 <div className="grid twoCards">
  <div className="card"><h2>Coming Up</h2>{upcoming.length===0&&sportComps.length===0?<p>No upcoming workouts or competitions.</p>:<>{upcoming.map(w=><div className="dashboardRow" key={w.id}><span className="dashDate">{w.date.slice(5)}</span><div><b>{w.name}</b><small>{w.category} · {w.minutes} min</small></div></div>)}{sportComps.map(c=><div className="dashboardRow" key={c.id}><span className="dashDate">{c.date.slice(5)}</span><div><b>{c.opponent||c.eventType}</b><small>Competition{c.result?" · "+c.result:""}</small></div></div>)}</>}</div>
  <div className="card"><h2>Development Focus</h2>{openDev.length?openDev.map(d=><div className="focusCard" key={d.id}><span className="tag">{d.category}</span><b>{d.title}</b><small>{d.target||"Keep progressing this objective."}</small></div>):<p>No open development objectives.</p>}</div>
 </div>

 <div className="sectionDivider"><span><i/>Weekly Review</span></div>
 <div className="card weeklyReview"><div className="sectionHead"><h2>Weekly Review</h2><span>{weekStart}</span></div><div className="two"><label>Biggest Win<input value={wins} onChange={e=>setWins(e.target.value)} placeholder="What went well?"/></label><label>Main Challenge<input value={challenges} onChange={e=>setChallenges(e.target.value)} placeholder="What held you back?"/></label><label>Next Week Focus<input value={focus} onChange={e=>setFocus(e.target.value)} placeholder="One priority for next week"/></label><label>Week Rating<select value={rating} onChange={e=>setRating(e.target.value)}>{Array.from({length:10},(_,i)=>String(i+1)).map(x=><option key={x}>{x}/10</option>)}</select></label></div><button className="primary" onClick={saveReview}>{currentReview?"Update Weekly Review":"Save Weekly Review"}</button></div>

 <div className="card"><h2>Recent Weekly Reviews</h2>{weeklyReviews.length===0?<p>No weekly reviews yet.</p>:weeklyReviews.slice(0,5).map(r=><div className="reviewRow" key={r.id}><div className="reviewRating">{r.rating}<small>/10</small></div><div><b>{r.weekStart}</b><small>{r.wins?"Win: "+r.wins:""}{r.focus?" · Next: "+r.focus:""}</small></div></div>)}</div>
 </>;
}

function Goals({goals,setGoals}:{goals:Goal[];setGoals:any}){
 const [title,setTitle]=useState(""),[type,setType]=useState<Goal["type"]>("Short-term"),[category,setCategory]=useState("Performance"),[deadline,setDeadline]=useState(""),[target,setTarget]=useState(""),[notes,setNotes]=useState("");
 const active=goals.filter(g=>(g.status||"Active")!=="Complete"),complete=goals.filter(g=>(g.status||"Active")==="Complete");
 const avg=goals.length?Math.round(goals.reduce((a,g)=>a+g.progress,0)/goals.length):0;

 const add=()=>{
  if(!title.trim())return;
  setGoals((g:Goal[])=>[{id:Date.now(),title:title.trim(),progress:0,type,category,deadline,target:target.trim(),status:"Active",notes:notes.trim()},...g]);
  setTitle("");setDeadline("");setTarget("");setNotes("");
 };

 const update=(id:number,patch:Partial<Goal>)=>setGoals((x:Goal[])=>x.map(g=>g.id===id?{...g,...patch}:g));
 const remove=(id:number)=>setGoals((x:Goal[])=>x.filter(g=>g.id!==id));

 return <><div className="hero"><small>PHASE 23 · GOALS 2.0</small><h1>Goals</h1><p>Turn outcomes into measurable, time-bound development targets.</p></div>

 <div className="grid three">
  <div className="stat"><small>Active Goals</small><b>{active.length}</b></div>
  <div className="stat"><small>Completed</small><b>{complete.length}</b></div>
  <div className="stat"><small>Average Progress</small><b>{avg}%</b></div>
 </div>

 <div className="card"><h2>Create Goal</h2><div className="two">
  <label>Goal name<input value={title} onChange={e=>setTitle(e.target.value)} placeholder="e.g. Improve 10-yard sprint"/></label>
  <label>Goal type<select value={type} onChange={e=>setType(e.target.value as Goal["type"])}><option>Short-term</option><option>Long-term</option></select></label>
  <label>Category<select value={category} onChange={e=>setCategory(e.target.value)}><option>Performance</option><option>Training</option><option>Skill</option><option>Strength</option><option>Speed</option><option>Conditioning</option><option>Competition</option><option>Recovery</option><option>Personal</option></select></label>
  <label>Deadline<input type="date" value={deadline} onChange={e=>setDeadline(e.target.value)}/></label>
 </div>
 <label>Target / success criteria<input value={target} onChange={e=>setTarget(e.target.value)} placeholder="e.g. Run 10-yard sprint in 1.80 sec"/></label>
 <label>Notes<input value={notes} onChange={e=>setNotes(e.target.value)} placeholder="Why this matters or how you will achieve it"/></label>
 <button className="primary" onClick={add}>Add Goal</button></div>

 <div className="card"><h2>Active Goals</h2>{active.length===0?<p>No active goals.</p>:active.map(g=><div className="goalCard" key={g.id}>
  <div className="row"><div><span className="tag">{g.category||"Performance"}</span><h2>{g.title}</h2><small>{g.type}{g.deadline?" · Due "+g.deadline:""}{g.target?" · Target: "+g.target:""}</small></div><strong>{g.progress}%</strong></div>
  <input type="range" min="0" max="100" value={g.progress} onChange={e=>update(g.id,{progress:+e.target.value})}/>
  <div className="progress"><i style={{width:`${g.progress}%`}}/></div>
  {g.notes&&<p>{g.notes}</p>}
  <div className="goalActions"><button onClick={()=>update(g.id,{status:"Paused"})}>Pause</button><button className="primary" onClick={()=>update(g.id,{status:"Complete",progress:100})}>Mark Complete</button><button onClick={()=>remove(g.id)}>Delete</button></div>
 </div>)}</div>

 {goals.some(g=>(g.status||"Active")==="Paused")&&<div className="card"><h2>Paused Goals</h2>{goals.filter(g=>(g.status||"Active")==="Paused").map(g=><div className="goalCard compact" key={g.id}><div><b>{g.title}</b><small>{g.category||"Performance"} · {g.progress}%</small></div><button onClick={()=>update(g.id,{status:"Active"})}>Resume</button></div>)}</div>}

 <div className="card"><h2>Completed Goals</h2>{complete.length===0?<p>No completed goals yet.</p>:complete.slice(0,10).map(g=><div className="goalCard compact doneGoal" key={g.id}><div><b>{g.title}</b><small>{g.category||"Performance"}{g.deadline?" · "+g.deadline:""}</small></div><span>✓ Complete</span></div>)}</div>
 </>;
}

function Calendar({sport,workouts,setWorkouts,profile,seasonEvents,setSeasonEvents,trainingBlocks,setTrainingBlocks,competitions}:{sport:Sport;workouts:Workout[];setWorkouts:any;profile:Profile;seasonEvents:SeasonEvent[];setSeasonEvents:React.Dispatch<React.SetStateAction<SeasonEvent[]>>;trainingBlocks:TrainingBlock[];setTrainingBlocks:React.Dispatch<React.SetStateAction<TrainingBlock[]>>;competitions:CompetitionLog[]}){
 const [date,setDate]=useState(today()),[name,setName]=useState("Sport Workout"),[cat,setCat]=useState("Conditioning"),[minutes,setMinutes]=useState("45"),[intensity,setIntensity]=useState<"Easy"|"Moderate"|"Hard">("Moderate"),[focusNote,setFocusNote]=useState("");
 const [eventDate,setEventDate]=useState(today()),[eventTitle,setEventTitle]=useState(""),[eventType,setEventType]=useState<SeasonEvent["eventType"]>("Game"),[priority,setPriority]=useState<SeasonEvent["priority"]>("Normal"),[eventNotes,setEventNotes]=useState("");
 const [blockName,setBlockName]=useState(""),[startDate,setStartDate]=useState(today()),[endDate,setEndDate]=useState(today()),[focus,setFocus]=useState("Speed"),[target,setTarget]=useState("");

 const rows=workouts.filter(w=>w.sport===sport).sort((a,b)=>a.date.localeCompare(b.date));
 const addWorkout=()=>{
   const item:Workout={id:Date.now(),date,name,category:cat,minutes:+minutes,completed:false,sport,intensity,focus:focusNote.trim()};
   setWorkouts((x:Workout[])=>[item,...x]);
   setFocusNote("");
 };
 const completeWorkout=(id:number,rpe:number,notes:string)=>setWorkouts((x:Workout[])=>x.map(a=>a.id===id?{...a,completed:true,rpe,notes}:a));
 const reopenWorkout=(id:number)=>setWorkouts((x:Workout[])=>x.map(a=>a.id===id?{...a,completed:false}:a));

 const addEvent=()=>{if(!eventTitle.trim())return;setSeasonEvents(x=>[...x,{id:Date.now(),date:eventDate,title:eventTitle.trim(),eventType,priority,notes:eventNotes.trim()}].sort((a,b)=>a.date.localeCompare(b.date)));setEventTitle("");setEventNotes("")};
 const addBlock=()=>{if(!blockName.trim())return;setTrainingBlocks(x=>[...x,{id:Date.now(),name:blockName.trim(),startDate,endDate,focus,target:target.trim(),completed:false}].sort((a,b)=>a.startDate.localeCompare(b.startDate)));setBlockName("");setTarget("")};

 const upcoming=seasonEvents.filter(e=>e.date>=today()).sort((a,b)=>a.date.localeCompare(b.date)).slice(0,8);
 const sportComps=competitions.filter(c=>c.sport===sport);
 const nextCompetition=[...upcoming.filter(e=>["Game","Tournament"].includes(e.eventType)).map(e=>({date:e.date,title:e.title})),...sportComps.filter(c=>c.date>=today()).map(c=>({date:c.date,title:c.opponent||c.eventType}))].sort((a,b)=>a.date.localeCompare(b.date))[0];
 const next14=new Date();next14.setDate(next14.getDate()+14);const next14s=next14.toISOString().slice(0,10);
 const plannedWorkouts=workouts.filter(w=>w.sport===sport&&w.date>=today()&&w.date<=next14s).length;
 const highEvents=seasonEvents.filter(e=>e.date>=today()&&e.date<=next14s&&e.priority==="High").length;
 const loadStatus=highEvents>=3||plannedWorkouts>=8?"High":highEvents>=1||plannedWorkouts>=5?"Moderate":"Manageable";

 const last7=rows.filter(w=>w.completed&&new Date(w.date).getTime()>=Date.now()-7*86400000);
 const sessionLoad=(w:Workout)=>w.minutes*(w.rpe||({Easy:4,Moderate:6,Hard:8}[w.intensity||"Moderate"]));
 const sevenDayLoad=Math.round(last7.reduce((a,w)=>a+sessionLoad(w),0));
 const avgRpe=last7.filter(w=>w.rpe).length?Math.round(last7.filter(w=>w.rpe).reduce((a,w)=>a+(w.rpe||0),0)/last7.filter(w=>w.rpe).length*10)/10:0;
 const completedMinutes=last7.reduce((a,w)=>a+w.minutes,0);

 return <><div className="hero"><small>PHASE 22 · WORKOUTS 2.0</small><h1>Calendar</h1><p>{profile.name} · {sport} · Schedule, complete, and measure training load in one place.</p></div>

 <div className="grid three">
  <div className="stat"><small>7-Day Load</small><b>{sevenDayLoad}</b><span>AU</span></div>
  <div className="stat"><small>7-Day Minutes</small><b>{completedMinutes}</b></div>
  <div className="stat"><small>Average RPE</small><b>{avgRpe||"—"}</b><span>/10</span></div>
 </div>

 <div className="card"><h2>Schedule Workout</h2><div className="calendarTop"><button onClick={()=>{const d=new Date(date);d.setDate(d.getDate()-1);setDate(d.toISOString().slice(0,10))}}>‹</button><input type="date" value={date} onChange={e=>setDate(e.target.value)}/><button onClick={()=>{const d=new Date(date);d.setDate(d.getDate()+1);setDate(d.toISOString().slice(0,10))}}>›</button></div>
 <label>Workout name<input value={name} onChange={e=>setName(e.target.value)}/></label>
 <div className="two"><label>Workout category<select value={cat} onChange={e=>setCat(e.target.value)}>{categories.map(x=><option key={x}>{x}</option>)}</select></label><label>Duration<select value={minutes} onChange={e=>setMinutes(e.target.value)}>{["15","30","45","60","75","90","120"].map(x=><option key={x} value={x}>{x} minutes</option>)}</select></label><label>Target Intensity<select value={intensity} onChange={e=>setIntensity(e.target.value as "Easy"|"Moderate"|"Hard")}><option>Easy</option><option>Moderate</option><option>Hard</option></select></label><label>Session Focus<input value={focusNote} onChange={e=>setFocusNote(e.target.value)} placeholder="e.g. acceleration + edge work"/></label></div>
 <button className="primary" onClick={addWorkout}>Schedule Workout</button></div>

 <div className="card"><h2>Workout Log</h2>{rows.length===0?<p>No workouts yet.</p>:rows.map(w=><WorkoutLogCard key={w.id} workout={w} onComplete={completeWorkout} onReopen={reopenWorkout}/>)}</div>

 <div className="grid three">
  <div className="stat"><small>Upcoming Events</small><b>{upcoming.length}</b></div>
  <div className="stat"><small>14-Day Workouts</small><b>{plannedWorkouts}</b></div>
  <div className="stat"><small>Load Outlook</small><b>{loadStatus}</b></div>
 </div>

 <div className="card"><h2>Season Planning</h2><div className="two">
  <label>Date<input type="date" value={eventDate} onChange={e=>setEventDate(e.target.value)}/></label>
  <label>Event Type<select value={eventType} onChange={e=>setEventType(e.target.value as SeasonEvent["eventType"])}><option>Game</option><option>Tournament</option><option>Testing</option><option>Training Block</option><option>Recovery</option><option>Other</option></select></label>
  <label>Event<input value={eventTitle} onChange={e=>setEventTitle(e.target.value)} placeholder="e.g. Regional tournament"/></label>
  <label>Priority<select value={priority} onChange={e=>setPriority(e.target.value as SeasonEvent["priority"])}><option>Normal</option><option>High</option></select></label>
 </div><label>Notes<input value={eventNotes} onChange={e=>setEventNotes(e.target.value)} placeholder="Travel, taper, testing prep, etc."/></label><button className="primary" onClick={addEvent}>Add Season Event</button></div>

 <div className="card"><h2>Training Block</h2><div className="two">
  <label>Block Name<input value={blockName} onChange={e=>setBlockName(e.target.value)} placeholder="e.g. Preseason Speed Block"/></label>
  <label>Focus<select value={focus} onChange={e=>setFocus(e.target.value)}><option>Speed</option><option>Strength</option><option>Power</option><option>Skill</option><option>Conditioning</option><option>Recovery</option><option>Competition Prep</option></select></label>
  <label>Start Date<input type="date" value={startDate} onChange={e=>setStartDate(e.target.value)}/></label>
  <label>End Date<input type="date" value={endDate} onChange={e=>setEndDate(e.target.value)}/></label>
 </div><label>Block Target<input value={target} onChange={e=>setTarget(e.target.value)} placeholder="e.g. Improve 10-yard sprint by 3%"/></label><button className="primary" onClick={addBlock}>Add Training Block</button></div>

 <div className="grid twoCards">
  <div className="card"><h2>Upcoming Season Events</h2>{upcoming.length===0?<p>No season events scheduled.</p>:upcoming.map(e=><div className="plannerRow" key={e.id}><div><span className="tag">{e.eventType}</span><b>{e.title}</b><small>{e.date}{e.priority==="High"?" · High Priority":""}{e.notes?" · "+e.notes:""}</small></div><button onClick={()=>setSeasonEvents(x=>x.filter(a=>a.id!==e.id))}>Delete</button></div>)}</div>
  <div className="card"><h2>Next Competition</h2>{nextCompetition?<><b>{nextCompetition.title}</b><p>{nextCompetition.date}</p><p>{loadStatus==="High"?"Training load is already high. Consider reducing volume before this event.":loadStatus==="Moderate"?"Maintain quality and watch readiness as the event approaches.":"There is room to build training quality before the event."}</p></>:<p>No upcoming competition found.</p>}</div>
 </div>

 <div className="card"><h2>Training Blocks</h2>{trainingBlocks.length===0?<p>No training blocks created yet.</p>:trainingBlocks.map(b=><div className="blockRow" key={b.id}><div><span className="tag">{b.focus}</span><b>{b.name}</b><small>{b.startDate} → {b.endDate}{b.target?" · "+b.target:""}</small></div><div><button onClick={()=>setTrainingBlocks(x=>x.map(a=>a.id===b.id?{...a,completed:!a.completed}:a))}>{b.completed?"✓ Complete":"Mark Complete"}</button><button onClick={()=>setTrainingBlocks(x=>x.filter(a=>a.id!==b.id))}>Delete</button></div></div>)}</div>

 <div className="card"><h2>Training Load Guidance</h2><div className="coachChecklist"><span>✓ RPE is how hard the workout felt on a 1–10 scale.</span><span>✓ Session load = minutes × RPE.</span><span>✓ Large load spikes plus low readiness are a signal to reduce volume.</span><span>✓ Keep hard days hard and easy days truly easy.</span></div></div>
 </>;
}

function WorkoutLogCard({workout,onComplete,onReopen}:{workout:Workout;onComplete:(id:number,rpe:number,notes:string)=>void;onReopen:(id:number)=>void}){
 const [rpe,setRpe]=useState(String(workout.rpe||6)),[notes,setNotes]=useState(workout.notes||"");
 const load=workout.completed?workout.minutes*(workout.rpe||6):0;
 return <div className={"workoutLogCard "+(workout.completed?"done":"")}><div className="workoutLogTop"><div><span className="tag">{workout.category}</span><h2>{workout.name}</h2><small>{workout.date} · {workout.minutes} min · {workout.intensity||"Moderate"}{workout.focus?" · "+workout.focus:""}</small></div>{workout.completed&&<div className="loadBadge"><b>{load}</b><small>load</small></div>}</div>
 {workout.completed?<div className="completedWorkout"><span>RPE {workout.rpe||"—"}/10</span>{workout.notes&&<p>{workout.notes}</p>}<button onClick={()=>onReopen(workout.id)}>Reopen</button></div>:<div className="completeWorkoutForm"><label>Session RPE<select value={rpe} onChange={e=>setRpe(e.target.value)}>{Array.from({length:10},(_,i)=>String(i+1)).map(x=><option key={x}>{x}/10</option>)}</select></label><label>Session Notes<input value={notes} onChange={e=>setNotes(e.target.value)} placeholder="What went well? Any soreness or changes?"/></label><button className="primary" onClick={()=>onComplete(workout.id,Number(rpe),notes.trim())}>Complete Workout</button></div>}</div>
}

function Testing({sport,library,custom,setCustom,results,setResults,testTargets,setTestTargets}:{sport:Sport;library:TestDef[];custom:CustomTest[];setCustom:any;results:Result[];setResults:any;testTargets:TestTarget[];setTestTargets:React.Dispatch<React.SetStateAction<TestTarget[]>>}){
 const [id,setId]=useState(library[0]?.id||""),[category,setCategory]=useState(""),[unit,setUnit]=useState(""),[value,setValue]=useState(""),[open,setOpen]=useState(false);
 const [name,setName]=useState(""),[newCat,setNewCat]=useState("Speed"),[newUnit,setNewUnit]=useState("sec"),[lower,setLower]=useState(true);
 const [target,setTarget]=useState(""),[retestDate,setRetestDate]=useState(""),[targetNotes,setTargetNotes]=useState("");

 useEffect(()=>{if(!library.some(x=>x.id===id))setId(library[0]?.id||"")},[sport,custom]);
 const t=library.find(x=>x.id===id), rows=results.filter(x=>x.sport===sport);
 useEffect(()=>{if(t){setCategory(t.category);setUnit(t.unit);const saved=testTargets.find(x=>x.testId===t.id&&x.sport===sport);setTarget(saved?.target||"");setRetestDate(saved?.retestDate||"");setTargetNotes(saved?.notes||"")}},[id,sport,testTargets.length]);

 const sameTest=t?rows.filter(r=>r.testId===t.id).sort((a,b)=>a.date.localeCompare(b.date)||a.id-b.id):[];
 const baseline=sameTest[0]?.value;
 const current=sameTest[sameTest.length-1]?.value;
 const best=t&&sameTest.length?sameTest.reduce((best,r)=>t.lowerBetter?Math.min(best,r.value):Math.max(best,r.value),sameTest[0].value):undefined;
 const imp=t&&sameTest.length>1&&baseline!==undefined&&current!==undefined?improvement(baseline,current,t.lowerBetter):0;
 const isPR=t&&current!==undefined&&best!==undefined&&current===best;
 const protocol=t?testProtocols[t.name]:undefined;

 const save=()=>{
  if(t&&value.trim()&&!isNaN(Number(value))){
   const n=Number(value);
   setResults((r:Result[])=>[{id:Date.now(),testId:t.id,name:t.name,category,unit,value:n,date:today(),sport},...r]);
   setValue("");
  }
 };

 const saveTarget=()=>{
  if(!t)return;
  const item:TestTarget={id:`${sport}-${t.id}`,testId:t.id,sport,target:target.trim(),retestDate,notes:targetNotes.trim()};
  setTestTargets(x=>[item,...x.filter(a=>!(a.testId===t.id&&a.sport===sport))]);
 };

 return <><div className="hero"><small>PHASE 21 · TESTING 2.0</small><h1>Performance Testing</h1><p>{sport} · Standardized testing, targets, PRs, and retest planning.</p></div>

 <div className="card">
 <label>Test Name<select value={id} onChange={e=>e.target.value==="__custom__"?setOpen(true):setId(e.target.value)}>{library.map(x=><option value={x.id} key={x.id}>{x.name}</option>)}<option value="__custom__">＋ Create Custom Test</option></select></label>
 <div className="two"><label>Category<select value={category} onChange={e=>setCategory(e.target.value)}>{categories.map(x=><option key={x}>{x}</option>)}</select></label><label>Unit of Measure<select value={unit} onChange={e=>setUnit(e.target.value)}>{units.map(x=><option key={x}>{x}</option>)}</select></label></div>

 {t&&<div className="testSummary">
   <div><small>Baseline</small><b>{baseline!==undefined?`${baseline} ${unit}`:"—"}</b></div>
   <div><small>Current</small><b>{current!==undefined?`${current} ${unit}`:"—"}</b></div>
   <div><small>Best</small><b>{best!==undefined?`${best} ${unit}`:"—"}</b></div>
   <div><small>Improvement</small><b className={imp>=0?"good":"bad"}>{sameTest.length>1?(imp>=0?"+":"")+imp+"%":"—"}</b></div>
 </div>}
 {isPR&&<div className="prBanner">★ Personal Record — latest result matches your best.</div>}

 {protocol&&<div className="protocolCard"><div className="sectionHead"><h2>Test Protocol</h2><span className="tag">Standardize It</span></div><p><b>Setup:</b> {protocol.setup}</p><p><b>How:</b> {protocol.instructions}</p><p><b>Consistency:</b> {protocol.quality}</p></div>}

 {t&&<p>{t.lowerBetter?"Lower is better":"Higher is better"}</p>}
 <label>Result<input inputMode="decimal" value={value} onChange={e=>setValue(e.target.value)} placeholder={unit?`Enter result in ${unit}`:"Enter result"}/></label><button className="primary" disabled={!t} onClick={save}>Save Result</button></div>

 <div className="card"><h2>Target & Retest Plan</h2><div className="two"><label>Target Result<input value={target} onChange={e=>setTarget(e.target.value)} placeholder={unit?`e.g. ${unit}`:"Target result"}/></label><label>Next Retest<input type="date" value={retestDate} onChange={e=>setRetestDate(e.target.value)}/></label></div><label>Notes<input value={targetNotes} onChange={e=>setTargetNotes(e.target.value)} placeholder="Testing conditions, goal, or coaching note"/></label><button onClick={saveTarget}>Save Test Plan</button>{retestDate&&<p className="retestCallout">Next retest: <b>{retestDate}</b>{target?` · Target ${target} ${unit}`:""}</p>}</div>

 <div className="card"><h2>Test History</h2>{sameTest.length===0?<p>No results for this test yet.</p>:sameTest.slice().reverse().map((r,i)=><div className="testHistoryRow" key={r.id}><div><b>{r.value} {r.unit}</b><small>{r.date} · {r.category}</small></div><span className={best===r.value?"prChip":""}>{best===r.value?"PR":"Result"}</span></div>)}</div>

 {open&&<div className="overlay"><div className="modal"><div className="sectionHead"><h2>Create Custom Test</h2><button onClick={()=>setOpen(false)}>×</button></div><label>Test name<input value={name} onChange={e=>setName(e.target.value)} placeholder="e.g. Shot speed"/></label><label>Category<select value={newCat} onChange={e=>setNewCat(e.target.value)}>{categories.map(x=><option key={x}>{x}</option>)}</select></label><label>Unit of Measure<select value={newUnit} onChange={e=>setNewUnit(e.target.value)}>{units.map(x=><option key={x}>{x}</option>)}</select></label><label>Better result<select value={lower?"lower":"higher"} onChange={e=>setLower(e.target.value==="lower")}><option value="lower">Lower is better</option><option value="higher">Higher is better</option></select></label><button className="primary" onClick={()=>{if(name.trim()){const x={id:`custom-${Date.now()}`,name:name.trim(),category:newCat,unit:newUnit,lowerBetter:lower,sport};setCustom((c:CustomTest[])=>[...c,x]);setId(x.id);setOpen(false);setName("")}}}>Save Custom Test</button></div></div>}</>
}

function Analytics({sport,results,goals,workouts}:{sport:Sport;results:Result[];goals:Goal[];workouts:Workout[]}){
 const [range,setRange]=useState("All"),[categoryFilter,setCategoryFilter]=useState("All");
 const cutoff=range==="30 Days"?Date.now()-30*86400000:range==="90 Days"?Date.now()-90*86400000:range==="1 Year"?Date.now()-365*86400000:0;
 const rows=results.filter(r=>r.sport===sport&&new Date(r.date).getTime()>=cutoff).filter(r=>categoryFilter==="All"||r.category===categoryFilter).sort((a,b)=>a.date.localeCompare(b.date)||a.id-b.id);
 const groups=[...new Map(rows.map(r=>[r.testId,r])).values()];
 const categoriesAvailable=["All",...new Set(results.filter(r=>r.sport===sport).map(r=>r.category))];

 const summaries=groups.map(g=>{
  const r=rows.filter(x=>x.testId===g.testId).sort((a,b)=>a.date.localeCompare(b.date)||a.id-b.id);
  const def=definitions(sport).find(x=>x.id===g.testId)||({lowerBetter:g.unit==="sec"} as TestDef);
  const baseline=r[0]?.value??0,current=r[r.length-1]?.value??0;
  const best=r.length?r.reduce((a,b)=>def.lowerBetter?Math.min(a,b.value):Math.max(a,b.value),baseline):0;
  const imp=r.length>1?improvement(baseline,current,def.lowerBetter):0;
  return {g,r,def,baseline,current,best,imp};
 });

 const improving=summaries.filter(x=>x.r.length>1&&x.imp>0).sort((a,b)=>b.imp-a.imp);
 const declining=summaries.filter(x=>x.r.length>1&&x.imp<0).sort((a,b)=>a.imp-b.imp);
 const avgImprovement=improving.length?Math.round(improving.reduce((a,x)=>a+x.imp,0)/improving.length*10)/10:0;

 const sportWorkouts=workouts.filter(w=>w.sport===sport);
 const completed=sportWorkouts.filter(w=>w.completed).length;
 const consistency=sportWorkouts.length?Math.round(completed/sportWorkouts.length*100):0;
 const goalProgress=goals.length?Math.round(goals.reduce((a,g)=>a+g.progress,0)/goals.length):0;

 return <><div className="hero"><small>PHASE 25 · ANALYTICS 2.0</small><h1>Analytics</h1><p>{sport} · Trends, improvement, consistency, and attention areas in one performance view.</p></div>

 <div className="analyticsToolbar">
  <div className="filters">{["All","30 Days","90 Days","1 Year"].map(x=><button className={range===x?"sel":""} key={x} onClick={()=>setRange(x)}>{x}</button>)}</div>
  <select value={categoryFilter} onChange={e=>setCategoryFilter(e.target.value)}>{categoriesAvailable.map(x=><option key={x}>{x}</option>)}</select>
 </div>

 <div className="grid three">
  <div className="stat"><small>Tests Tracked</small><b>{summaries.length}</b></div>
  <div className="stat"><small>Avg Positive Trend</small><b>{avgImprovement?`+${avgImprovement}%`:"—"}</b></div>
  <div className="stat"><small>Training Consistency</small><b>{consistency}%</b></div>
 </div>

 <div className="grid twoCards">
  <div className="card insightPanel"><h2>Top Improvement</h2>{improving[0]?<><b className="big good">+{improving[0].imp}%</b><p>{improving[0].g.name}</p><small>Baseline {improving[0].baseline} {improving[0].g.unit} → Current {improving[0].current} {improving[0].g.unit}</small></>:<p>No positive repeated-test trend yet.</p>}</div>
  <div className="card insightPanel"><h2>Needs Attention</h2>{declining[0]?<><b className="big bad">{declining[0].imp}%</b><p>{declining[0].g.name}</p><small>Baseline {declining[0].baseline} {declining[0].g.unit} → Current {declining[0].current} {declining[0].g.unit}</small></>:<p>No declining repeated-test trend detected.</p>}</div>
 </div>

 <div className="card"><div className="sectionHead"><h2>Performance Trends</h2><button onClick={()=>exportResults(rows)}>Export Results CSV</button></div>
 {summaries.length===0?<p>No matching test results.</p>:summaries.map(({g,r,def,baseline,current,best,imp})=><div className="trend" key={g.testId}>
   <div className="row"><span><b>{g.name}</b><small>{g.category} · {r.length} results</small></span><strong className={imp>=0?"good":"bad"}>{r.length>1?(imp>=0?"+":"")+imp+"%":"New"}</strong></div>
   <TrendChart values={r.map(x=>x.value)} lower={def.lowerBetter}/>
   <div className="trendAxis"><span>Baseline · {r[0]?.date}</span><span>Current · {r[r.length-1]?.date}</span></div>
   <div className="analyticsMetrics"><span><small>Baseline</small><b>{baseline} {g.unit}</b></span><span><small>Current</small><b>{current} {g.unit}</b></span><span><small>Best</small><b>{best} {g.unit}</b></span></div>
 </div>)}</div>

 <CompareTests sport={sport} results={rows}/>

 <div className="grid twoCards">
  <div className="card"><h2>Goal Progress</h2><div className="big">{goalProgress}%</div><div className="progress"><i style={{width:`${goalProgress}%`}}/></div><p>{goals.length} goals tracked.</p></div>
  <div className="card"><h2>Training Consistency</h2><div className="big">{consistency}%</div><div className="progress"><i style={{width:`${consistency}%`}}/></div><p>{completed}/{sportWorkouts.length} workouts complete.</p></div>
 </div>
 </>;
}

function CompareTests({sport,results}:{sport:Sport;results:Result[]}){
 const tests=[...new Map(results.map(r=>[r.testId,r])).values()];
 const [a,setA]=useState(tests[0]?.testId||""),[b,setB]=useState(tests[1]?.testId||"");
 useEffect(()=>{if(!tests.some(x=>x.testId===a))setA(tests[0]?.testId||"");if(!tests.some(x=>x.testId===b))setB(tests[1]?.testId||"")},[results.length]);
 const series=(id:string)=>results.filter(r=>r.testId===id).sort((x,y)=>x.date.localeCompare(y.date)||x.id-y.id);
 const render=(id:string)=>{const r=series(id),t=r[r.length-1];if(!t)return <p>No result.</p>;const first=r[0],def=definitions(sport).find(x=>x.id===id)||({lowerBetter:t.unit==="sec"} as TestDef),imp=r.length>1?improvement(first.value,t.value,def.lowerBetter):0;return <div className="compareValue"><b>{t.name}</b><strong>{t.value} {t.unit}</strong><small>{r.length>1?`${imp>=0?"+":""}${imp}% from baseline`:"One result logged"}</small></div>};
 return <div className="card"><h2>Compare Tests</h2><div className="two"><label>Test A<select value={a} onChange={e=>setA(e.target.value)}>{tests.map(t=><option key={t.testId} value={t.testId}>{t.name}</option>)}</select></label><label>Test B<select value={b} onChange={e=>setB(e.target.value)}>{tests.map(t=><option key={t.testId} value={t.testId}>{t.name}</option>)}</select></label></div><div className="compareGrid">{render(a)}{render(b)}</div></div>
}
function exportResults(rows:Result[]){
 const header="Date,Test,Category,Unit,Value,Sport";
 const body=rows.map(r=>[r.date,r.name,r.category,r.unit,r.value,r.sport].map(v=>`"${String(v).replaceAll('"','""')}"`).join(",")).join("\n");
 const blob=new Blob([header+"\n"+body],{type:"text/csv;charset=utf-8"}),url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download="athlete-performance-results.csv";a.click();URL.revokeObjectURL(url);
}
function Development({sport,profile,dev,setDev,results,goals,workouts,program,readiness,competitions,milestones,setMilestones}:{sport:Sport;profile:Profile;dev:DevelopmentItem[];setDev:React.Dispatch<React.SetStateAction<DevelopmentItem[]>>;results:Result[];goals:Goal[];workouts:Workout[];program:TrainingProgram|null;readiness:ReadinessLog[];competitions:CompetitionLog[];milestones:Milestone[];setMilestones:React.Dispatch<React.SetStateAction<Milestone[]>>}){
 const [title,setTitle]=useState(""),[category,setCategory]=useState("Skill"),[target,setTarget]=useState(""),[dueDate,setDueDate]=useState("");
 const [milestoneTitle,setMilestoneTitle]=useState(""),[milestoneDetail,setMilestoneDetail]=useState(""),[milestoneCategory,setMilestoneCategory]=useState("Personal");

 const add=()=>{if(!title.trim())return;setDev(x=>[...x,{id:Date.now(),title:title.trim(),category,target,dueDate,status:"Not Started"}]);setTitle("");setTarget("");setDueDate("")};
 const toggle=(id:number)=>setDev(x=>x.map(i=>i.id===id?{...i,status:i.status==="Complete"?"In Progress":"Complete"}:i));
 const remove=(id:number)=>setDev(x=>x.filter(i=>i.id!==id));
 const complete=dev.filter(i=>i.status==="Complete").length;

 const sportResults=results.filter(r=>r.sport===sport);
 const sportWorkouts=workouts.filter(w=>w.sport===sport);
 const sportComps=competitions.filter(c=>c.sport===sport);
 const completedGoals=goals.filter(g=>g.progress>=100).length;
 const completedWorkouts=sportWorkouts.filter(w=>w.completed).length;
 const repeatedTests=[...new Map(sportResults.map(r=>[r.testId,r])).keys()].filter(id=>sportResults.filter(r=>r.testId===id).length>=2).length;
 const readinessStreak=readiness.slice(0,7).length;
 const programComplete=program?.sessions.filter(s=>s.completed).length||0;

 const achievements:Achievement[]=[
  {id:"first-test",title:"First Test Logged",description:"Record your first performance test.",category:"Testing",earned:sportResults.length>=1,progress:Math.min(100,sportResults.length*100)},
  {id:"five-tests",title:"Testing Habit",description:"Log 5 performance test results.",category:"Testing",earned:sportResults.length>=5,progress:Math.min(100,sportResults.length/5*100)},
  {id:"trend-maker",title:"Trend Builder",description:"Create 3 repeated-test trends.",category:"Analytics",earned:repeatedTests>=3,progress:Math.min(100,repeatedTests/3*100)},
  {id:"five-workouts",title:"Training Streak",description:"Complete 5 workouts.",category:"Training",earned:completedWorkouts>=5,progress:Math.min(100,completedWorkouts/5*100)},
  {id:"ten-workouts",title:"Consistency Builder",description:"Complete 10 workouts.",category:"Training",earned:completedWorkouts>=10,progress:Math.min(100,completedWorkouts/10*100)},
  {id:"goal-complete",title:"Goal Getter",description:"Complete your first goal.",category:"Goals",earned:completedGoals>=1,progress:Math.min(100,completedGoals*100)},
  {id:"dev-complete",title:"Development Win",description:"Complete a development objective.",category:"Development",earned:complete>=1,progress:Math.min(100,complete*100)},
  {id:"program-five",title:"Program Progress",description:"Complete 5 weekly-program sessions.",category:"Program",earned:programComplete>=5,progress:Math.min(100,programComplete/5*100)},
  {id:"readiness-week",title:"Recovery Awareness",description:"Log readiness 7 times.",category:"Readiness",earned:readinessStreak>=7,progress:Math.min(100,readinessStreak/7*100)},
  {id:"first-competition",title:"Competition Logged",description:"Log your first game or competition.",category:"Competition",earned:sportComps.length>=1,progress:Math.min(100,sportComps.length*100)},
  {id:"five-competitions",title:"Season Builder",description:"Log 5 competitions.",category:"Competition",earned:sportComps.length>=5,progress:Math.min(100,sportComps.length/5*100)}
 ];
 const earned=achievements.filter(a=>a.earned).length;

 const addMilestone=()=>{
  if(!milestoneTitle.trim())return;
  setMilestones(x=>[{id:Date.now(),date:today(),title:milestoneTitle.trim(),detail:milestoneDetail.trim(),category:milestoneCategory},...x]);
  setMilestoneTitle("");setMilestoneDetail("");
 };

 return <><div className="hero"><small>PLAYER DEVELOPMENT</small><h1>Development Plan</h1><p>{sport} · {complete}/{dev.length} objectives complete · {earned} achievements earned</p></div>

 <div className="card"><h2>Add Development Objective</h2><div className="two"><label>Objective<input value={title} onChange={e=>setTitle(e.target.value)} placeholder="e.g. Improve first-step quickness"/></label><label>Category<select value={category} onChange={e=>setCategory(e.target.value)}><option>Skill</option><option>Strength</option><option>Speed</option><option>Conditioning</option><option>Technique</option><option>Game Performance</option></select></label><label>Target<input value={target} onChange={e=>setTarget(e.target.value)} placeholder="e.g. 5% improvement"/></label><label>Target Date<input type="date" value={dueDate} onChange={e=>setDueDate(e.target.value)}/></label></div><button onClick={add}>Add Objective</button></div>

 <div className="card"><h2>Objectives</h2>{dev.length===0?<p>No development objectives yet.</p>:dev.map(i=><div className="devRow" key={i.id}><div><b>{i.title}</b><small>{i.category}{i.target?" · "+i.target:""}{i.dueDate?" · Due "+i.dueDate:""}</small></div><div><button onClick={()=>toggle(i.id)}>{i.status}</button><button onClick={()=>remove(i.id)}>Delete</button></div></div>)}</div>

 <div className="card"><div className="sectionHead"><h2>Achievements</h2><span>{earned}/{achievements.length} earned</span></div><div className="achievementGrid">{achievements.map(a=><div className={"achievement "+(a.earned?"earned":"")} key={a.id}><div className="achievementIcon">{a.earned?"✓":"○"}</div><div><b>{a.title}</b><small>{a.category} · {a.description}</small><div className="progress"><i style={{width:`${Math.round(a.progress)}%`}}/></div><small>{Math.round(a.progress)}%</small></div></div>)}</div></div>

 <div className="card"><h2>Add Personal Milestone</h2><div className="two"><label>Milestone<input value={milestoneTitle} onChange={e=>setMilestoneTitle(e.target.value)} placeholder="e.g. Made varsity roster"/></label><label>Category<select value={milestoneCategory} onChange={e=>setMilestoneCategory(e.target.value)}><option>Personal</option><option>Team</option><option>Testing</option><option>Training</option><option>Competition</option><option>Development</option></select></label></div><label>Details<input value={milestoneDetail} onChange={e=>setMilestoneDetail(e.target.value)} placeholder="Why this matters"/></label><button className="primary" onClick={addMilestone}>Save Milestone</button></div>

 <div className="card"><h2>Milestone Timeline</h2>{milestones.length===0?<p>No personal milestones saved yet.</p>:milestones.map(m=><div className="timelineRow" key={m.id}><div className="timelineDot"/><div><span className="tag">{m.category}</span><b>{m.title}</b><small>{m.date}{m.detail?" · "+m.detail:""}</small></div><button onClick={()=>setMilestones(x=>x.filter(a=>a.id!==m.id))}>Delete</button></div>)}</div>

 <div className="card"><h2>Performance Snapshot</h2><div className="quickStats"><span><b>{results.length}</b><small>Results logged</small></span><span><b>{new Set(results.map(r=>r.testId)).size}</b><small>Tests tracked</small></span><span><b>{dev.length?Math.round(complete/dev.length*100):0}%</b><small>Plan completion</small></span></div></div></>
}

const sportProgramTemplates:Record<Sport,{speed:string[];strength:string[];skill:string[];conditioning:string[]}>={
 Baseball:{speed:["Acceleration sprints","Lateral reaction starts","Base-running burst work"],strength:["Rotational medicine-ball power","Single-leg strength","Upper-body push/pull"],skill:["Throwing mechanics","Fielding footwork","Bat-speed drill"],conditioning:["Tempo runs","Bike intervals","Mobility recovery"]},
 Football:{speed:["10-yard acceleration","Flying sprint mechanics","Change-of-direction starts"],strength:["Lower-body strength","Upper-body power","Posterior-chain training"],skill:["Position footwork","Reaction drill","Route/coverage technique"],conditioning:["Repeated sprint intervals","Tempo conditioning","Mobility recovery"]},
 "Ice Hockey":{speed:["First-step acceleration","Lateral power bounds","Short sprint intervals"],strength:["Single-leg strength","Posterior-chain strength","Core anti-rotation"],skill:["Edge-control footwork","Stickhandling tempo","Reaction and hand-speed"],conditioning:["Bike shift intervals","Repeated sprint conditioning","Hip mobility recovery"]},
 Basketball:{speed:["First-step acceleration","Closeout-to-sprint","Lateral change of direction"],strength:["Jump strength","Single-leg strength","Upper-body strength"],skill:["Ball-handling pace","Finishing footwork","Shooting movement"],conditioning:["Court intervals","Tempo runs","Mobility recovery"]},
 Lacrosse:{speed:["20-yard acceleration","Reactive cuts","Crossover sprint mechanics"],strength:["Rotational power","Single-leg strength","Upper-body push/pull"],skill:["Stick-skill tempo","Dodging footwork","Passing on the move"],conditioning:["Field intervals","Repeated sprint conditioning","Mobility recovery"]},
 Wrestling:{speed:["Short acceleration","Sprawl reaction","Lateral movement"],strength:["Total-body strength","Grip strength","Posterior-chain strength"],skill:["Stance and motion","Shot-entry technique","Hand-fighting drill"],conditioning:["Match intervals","Bike intervals","Mobility recovery"]},
 Soccer:{speed:["10-meter acceleration","Flying sprint","Change-of-direction sprint"],strength:["Single-leg strength","Hamstring strength","Core stability"],skill:["First-touch drill","Passing on the move","Dribbling change of direction"],conditioning:["Repeated sprint intervals","Aerobic tempo work","Mobility recovery"]}
};

function Program({sport,profile,dev,results,program,setProgram,setWorkouts}:{sport:Sport;profile:Profile;dev:DevelopmentItem[];results:Result[];program:TrainingProgram|null;setProgram:React.Dispatch<React.SetStateAction<TrainingProgram|null>>;setWorkouts:any}){
 const [focus,setFocus]=useState("Balanced"),[days,setDays]=useState("4");
 const templates=sportProgramTemplates[sport];
 const generate=()=>{
  const n=Math.max(2,Math.min(6,Number(days)||4)),week=["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
  const cycle=focus==="Balanced"?["speed","strength","skill","conditioning"]:Array(n).fill(focus.toLowerCase());
  const sessions:ProgramSession[]=Array.from({length:n},(_,i)=>{
   const category=cycle[i%cycle.length] as "speed"|"strength"|"skill"|"conditioning";
   const objective=dev.find(d=>d.status!=="Complete"&&d.category.toLowerCase().includes(category))?.title;
   return {id:Date.now()+i,day:week[i],name:templates[category][i%templates[category].length],category:category[0].toUpperCase()+category.slice(1),minutes:category==="conditioning"?35:45,focus:objective||`${sport} ${category} development`,completed:false};
  });
  setProgram({id:Date.now(),created:today(),sport,position:profile.position||"",focus,daysPerWeek:n,sessions});
 };
 const toggle=(id:number)=>setProgram(x=>x?{...x,sessions:x.sessions.map(s=>s.id===id?{...s,completed:!s.completed}:s)}:x);
 const addToCalendar=()=>{
  if(!program)return;
  const start=new Date(),dayIndex:Record<string,number>={Sunday:0,Monday:1,Tuesday:2,Wednesday:3,Thursday:4,Friday:5,Saturday:6},current=start.getDay();
  setWorkouts((existing:Workout[])=>[...program.sessions.map((session,i)=>{let offset=(dayIndex[session.day]-current+7)%7;if(offset===0&&i>0)offset=7;const d=new Date(start);d.setDate(start.getDate()+offset);return {id:Date.now()+i,date:d.toISOString().slice(0,10),name:session.name,category:session.category,minutes:session.minutes,completed:false,sport};}),...existing]);
 };
 const completion=program?.sessions.length?Math.round(program.sessions.filter(s=>s.completed).length/program.sessions.length*100):0;
 return <><div className="sectionDivider"><span><i/>Training Program</span></div><div className="hero"><small>TRAINING PROGRAM</small><h1>Weekly Program Builder</h1><p>{sport}{profile.position?" · "+profile.position:""} · Build a plan around your development priorities.</p></div>
 <div className="card"><h2>Generate Program</h2><div className="two"><label>Primary Focus<select value={focus} onChange={e=>setFocus(e.target.value)}>{["Balanced","Speed","Strength","Skill","Conditioning"].map(x=><option key={x}>{x}</option>)}</select></label><label>Training Days / Week<select value={days} onChange={e=>setDays(e.target.value)}>{["2","3","4","5","6"].map(x=><option key={x}>{x}</option>)}</select></label></div><button className="primary" onClick={generate}>Build My Program</button></div>
 {program&&<><div className="card"><div className="sectionHead"><h2>Current Program</h2><span>{completion}% complete</span></div><div className="progress"><i style={{width:`${completion}%`}}/></div><p>{program.focus} · {program.daysPerWeek} days/week · Created {program.created}</p><button className="primary" onClick={addToCalendar}>Add Program to Calendar</button></div>
 {program.sessions.map(session=><div className="card programSession" key={session.id}><div className="row"><div><span className="tag">{session.day} · {session.category}</span><h2>{session.name}</h2><p>{session.minutes} min · {session.focus}</p></div><button onClick={()=>toggle(session.id)}>{session.completed?"✓ Complete":"Mark Complete"}</button></div></div>)}
 <div className="card"><h2>Program Inputs</h2><div className="quickStats"><span><b>{dev.filter(d=>d.status!=="Complete").length}</b><small>Open development objectives</small></span><span><b>{results.filter(r=>r.sport===sport).length}</b><small>Sport test results</small></span><span><b>{profile.position||"—"}</b><small>Position</small></span></div></div></>}
 </>;
}

function Readiness({sport,readiness,setReadiness,coachNotes,setCoachNotes,program,workouts}:{sport:Sport;readiness:ReadinessLog[];setReadiness:React.Dispatch<React.SetStateAction<ReadinessLog[]>>;coachNotes:CoachNote[];setCoachNotes:React.Dispatch<React.SetStateAction<CoachNote[]>>;program:TrainingProgram|null;workouts:Workout[]}){
 const [sleep,setSleep]=useState("8"),[soreness,setSoreness]=useState("3"),[energy,setEnergy]=useState("7"),[stress,setStress]=useState("3"),[notes,setNotes]=useState("");
 const [noteTitle,setNoteTitle]=useState(""),[noteText,setNoteText]=useState(""),[noteCategory,setNoteCategory]=useState("Coach");
 const saveReadiness=()=>{
  const item:ReadinessLog={id:Date.now(),date:today(),sleep:Number(sleep)||0,soreness:Number(soreness)||0,energy:Number(energy)||0,stress:Number(stress)||0,notes};
  setReadiness(x=>[item,...x.filter(r=>r.date!==item.date)]);
  setNotes("");
 };
 const saveCoachNote=()=>{
  if(!noteTitle.trim()&&!noteText.trim())return;
  setCoachNotes(x=>[{id:Date.now(),date:today(),title:noteTitle.trim()||"Note",note:noteText.trim(),category:noteCategory},...x]);
  setNoteTitle("");setNoteText("");
 };
 const todayLog=readiness.find(r=>r.date===today());
 const score=todayLog?Math.max(0,Math.min(100,Math.round(
  Math.min(10,todayLog.sleep/8*10)*2.5 +
  (10-Math.min(10,todayLog.soreness))*2.5 +
  Math.min(10,todayLog.energy)*2.5 +
  (10-Math.min(10,todayLog.stress))*2.5
 ))):0;
 const status=score>=80?"Ready to Train":score>=60?"Train with Moderation":score>0?"Recovery Focus":"Log Today";
 const recent=readiness.slice(0,7).reverse();
 const nextWorkout=workouts.filter(w=>w.sport===sport&&!w.completed&&w.date>=today()).sort((a,b)=>a.date.localeCompare(b.date))[0];
 return <><div className="sectionDivider"><span><i/>Readiness</span></div><div className="hero"><small>READINESS & RECOVERY</small><h1>Daily Readiness</h1><p>{sport} · Track how your body feels before training.</p></div>
 <div className="readinessHero"><div><small>READINESS SCORE</small><strong>{score}</strong><span>/100</span></div><div><b>{status}</b><p>{score>=80?"Good day for normal training intensity.":score>=60?"Keep quality high but watch fatigue.":score>0?"Prioritize recovery, mobility, and lower intensity.":"Complete today's check-in to get a score."}</p></div></div>
 <div className="card"><h2>Daily Check-In</h2><div className="two">
  <label>Sleep (hours)<select value={sleep} onChange={e=>setSleep(e.target.value)}>{["4","5","6","7","8","9","10"].map(x=><option key={x}>{x}</option>)}</select></label>
  <label>Energy (1–10)<select value={energy} onChange={e=>setEnergy(e.target.value)}>{Array.from({length:10},(_,i)=>String(i+1)).map(x=><option key={x}>{x}</option>)}</select></label>
  <label>Soreness (1–10)<select value={soreness} onChange={e=>setSoreness(e.target.value)}>{Array.from({length:10},(_,i)=>String(i+1)).map(x=><option key={x}>{x}</option>)}</select></label>
  <label>Stress (1–10)<select value={stress} onChange={e=>setStress(e.target.value)}>{Array.from({length:10},(_,i)=>String(i+1)).map(x=><option key={x}>{x}</option>)}</select></label>
 </div><label>Notes<input value={notes} onChange={e=>setNotes(e.target.value)} placeholder="Sleep quality, soreness location, school stress, etc."/></label><button className="primary" onClick={saveReadiness}>Save Today's Readiness</button></div>
 <div className="card"><h2>7-Day Readiness Trend</h2>{recent.length?<div className="readinessBars">{recent.map(r=>{const v=Math.max(0,Math.min(100,Math.round(Math.min(10,r.sleep/8*10)*2.5+(10-Math.min(10,r.soreness))*2.5+Math.min(10,r.energy)*2.5+(10-Math.min(10,r.stress))*2.5)));return <div key={r.id}><i style={{height:`${v}%`}}/><small>{r.date.slice(5)}</small><b>{v}</b></div>})}</div>:<p>Log readiness each day to build a recovery trend.</p>}</div>
 <div className="grid twoCards"><div className="card"><h2>Training Recommendation</h2><p>{score>=80?"Proceed with the planned session.":score>=60?"Complete the session, but reduce volume if performance drops.":score>0?"Use recovery, mobility, technique, or an easier conditioning session.":"Log readiness first."}</p>{nextWorkout&&<p><b>Next:</b> {nextWorkout.name} · {nextWorkout.date}</p>}</div><div className="card"><h2>Program Status</h2><p>{program?`${program.focus} · ${program.daysPerWeek} days/week`:"No active Phase 8 program yet."}</p></div></div>
 <div className="card"><h2>Coach / Parent Notes</h2><div className="two"><label>Category<select value={noteCategory} onChange={e=>setNoteCategory(e.target.value)}><option>Coach</option><option>Parent</option><option>Athlete</option><option>Medical / Recovery</option><option>Game Review</option></select></label><label>Title<input value={noteTitle} onChange={e=>setNoteTitle(e.target.value)} placeholder="e.g. Practice feedback"/></label></div><label>Note<input value={noteText} onChange={e=>setNoteText(e.target.value)} placeholder="Add observations or feedback"/></label><button onClick={saveCoachNote}>Save Note</button></div>
 {coachNotes.slice(0,8).map(n=><div className="card row" key={n.id}><div><span className="tag">{n.category}</span><h2>{n.title}</h2><p>{n.note}</p></div><small>{n.date}</small></div>)}
 </>;
}

function Competition({sport,competitions,setCompetitions,profile}:{sport:Sport;competitions:CompetitionLog[];setCompetitions:React.Dispatch<React.SetStateAction<CompetitionLog[]>>;profile:Profile}){
 const [date,setDate]=useState(today()),[opponent,setOpponent]=useState(""),[eventType,setEventType]=useState("Game"),[result,setResult]=useState(""),[minutes,setMinutes]=useState(""),[rating,setRating]=useState("7"),[notes,setNotes]=useState("");
 const [location,setLocation]=useState(""),[role,setRole]=useState(profile.position||""),[keyWin,setKeyWin]=useState(""),[improveNext,setImproveNext]=useState(""),[confidence,setConfidence]=useState("7");
 const emptyStats=()=>competitionStats[sport].map(label=>({label,value:""}));
 const [stats,setStats]=useState<StatEntry[]>(emptyStats());
 useEffect(()=>{setStats(emptyStats());setRole(profile.position||"")},[sport,profile.position]);

 const save=()=>{
  if(!opponent.trim()&&!result.trim()&&!notes.trim())return;
  const item:CompetitionLog={
   id:Date.now(),date,opponent:opponent.trim()||"Competition",eventType,result:result.trim(),minutes,
   rating:Number(rating)||0,notes:notes.trim(),sport,stats,location:location.trim(),role:role.trim(),
   keyWin:keyWin.trim(),improveNext:improveNext.trim(),confidence:Number(confidence)||0
  };
  setCompetitions(x=>[item,...x]);
  setOpponent("");setResult("");setMinutes("");setNotes("");setRating("7");setLocation("");setKeyWin("");setImproveNext("");setConfidence("7");setStats(emptyStats());
 };

 const mine=competitions.filter(x=>x.sport===sport).sort((a,b)=>b.date.localeCompare(a.date)||b.id-a.id);
 const games=mine.length;
 const avgRating=games?Math.round(mine.reduce((a,x)=>a+x.rating,0)/games*10)/10:0;
 const avgConfidence=games?Math.round(mine.reduce((a,x)=>a+(x.confidence||0),0)/games*10)/10:0;
 const totalMinutes=mine.reduce((a,x)=>a+(Number(x.minutes)||0),0);
 const wins=mine.filter(x=>/^w/i.test(x.result.trim())).length;
 const winPct=games?Math.round(wins/games*100):0;

 const statTotals=competitionStats[sport].map(label=>{
  const vals=mine.map(g=>Number(g.stats.find(s=>s.label===label)?.value||0)).filter(v=>!Number.isNaN(v));
  return {label,total:Math.round(vals.reduce((a,b)=>a+b,0)*100)/100};
 }).filter(x=>x.total!==0).slice(0,8);

 const recentRatings=mine.slice(0,8).reverse();
 const bestRating=mine.length?Math.max(...mine.map(x=>x.rating)):0;
 const lastThree=mine.slice(0,3);
 const recentAvg=lastThree.length?Math.round(lastThree.reduce((a,x)=>a+x.rating,0)/lastThree.length*10)/10:0;

 return <><div className="hero"><small>PHASE 24 · COMPETITION 2.0</small><h1>Competition</h1><p>{profile.name} · {sport}{profile.position?" · "+profile.position:""} · Track game performance, confidence, and post-event learning.</p></div>

 <div className="grid three">
  <div className="stat"><small>Events Logged</small><b>{games}</b></div>
  <div className="stat"><small>Average Rating</small><b>{avgRating||"—"}</b><span>/10</span></div>
  <div className="stat"><small>Win Rate</small><b>{winPct}%</b></div>
 </div>

 <div className="card"><h2>Log Competition</h2>
  <div className="two">
   <label>Date<input type="date" value={date} onChange={e=>setDate(e.target.value)}/></label>
   <label>Type<select value={eventType} onChange={e=>setEventType(e.target.value)}><option>Game</option><option>Match</option><option>Tournament</option><option>Scrimmage</option><option>Meet</option><option>Showcase</option></select></label>
   <label>Opponent / Event<input value={opponent} onChange={e=>setOpponent(e.target.value)} placeholder="Team or event name"/></label>
   <label>Result<input value={result} onChange={e=>setResult(e.target.value)} placeholder="e.g. W 4-2, 2nd place"/></label>
   <label>Location<input value={location} onChange={e=>setLocation(e.target.value)} placeholder="Home, away, venue"/></label>
   <label>Role / Position<input value={role} onChange={e=>setRole(e.target.value)} placeholder="Position or role"/></label>
   <label>Minutes / Time<input value={minutes} onChange={e=>setMinutes(e.target.value)} inputMode="decimal" placeholder="e.g. 32"/></label>
   <label>Performance Rating<select value={rating} onChange={e=>setRating(e.target.value)}>{Array.from({length:10},(_,i)=>String(i+1)).map(x=><option key={x}>{x}/10</option>)}</select></label>
   <label>Confidence<select value={confidence} onChange={e=>setConfidence(e.target.value)}>{Array.from({length:10},(_,i)=>String(i+1)).map(x=><option key={x}>{x}/10</option>)}</select></label>
  </div>

  <h2>Sport Stats</h2>
  <div className="statInputs">{stats.map((st,i)=><label key={st.label}>{st.label}<input inputMode="decimal" value={st.value} onChange={e=>setStats(x=>x.map((a,j)=>j===i?{...a,value:e.target.value}:a))}/></label>)}</div>

  <div className="two">
   <label>Biggest Win<input value={keyWin} onChange={e=>setKeyWin(e.target.value)} placeholder="What worked best?"/></label>
   <label>Improve Next<input value={improveNext} onChange={e=>setImproveNext(e.target.value)} placeholder="One thing to improve next time"/></label>
  </div>
  <label>Post-Game Notes<input value={notes} onChange={e=>setNotes(e.target.value)} placeholder="What happened and what did you learn?"/></label>
  <button className="primary" onClick={save}>Save Competition</button>
 </div>

 <div className="grid twoCards">
  <div className="card"><h2>Performance Trend</h2>{recentRatings.length<2?<p>Log at least 2 competitions to see a trend.</p>:<div className="competitionTrend">{recentRatings.map(g=><div key={g.id}><i style={{height:`${Math.max(10,g.rating*10)}%`}}/><small>{g.date.slice(5)}</small><b>{g.rating}</b></div>)}</div>}<p>Recent average: <b>{recentAvg||"—"}</b>/10 · Best: <b>{bestRating||"—"}</b>/10</p></div>
  <div className="card"><h2>Confidence</h2><div className="big">{avgConfidence||"—"}<small>/10 avg</small></div><p>Compare confidence with performance rating to spot preparation and mindset patterns.</p></div>
 </div>

 <div className="card"><h2>Season Snapshot</h2>
  <div className="quickStats">
   <span><b>{games}</b><small>Events</small></span>
   <span><b>{wins}</b><small>Wins logged</small></span>
   <span><b>{totalMinutes}</b><small>Total minutes</small></span>
  </div>
  {statTotals.length>0&&<div className="seasonStats">{statTotals.map(x=><div key={x.label}><small>{x.label}</small><b>{x.total}</b></div>)}</div>}
 </div>

 <h2>Competition History</h2>
 {mine.length===0?<div className="card"><p>No competitions logged yet.</p></div>:mine.map(g=><div className="card competitionCard" key={g.id}>
  <div className="row"><div><span className="tag">{g.eventType}</span><h2>{g.opponent}</h2><p>{g.date}{g.result?" · "+g.result:""}{g.location?" · "+g.location:""}{g.minutes?" · "+g.minutes+" min":""}</p></div><div className="ratingBadge">{g.rating}<small>/10</small></div></div>
  <div className="miniStats">{g.stats.filter(x=>x.value!=="").map(x=><span key={x.label}><small>{x.label}</small><b>{x.value}</b></span>)}</div>
  {(g.keyWin||g.improveNext)&&<div className="gameReflection">{g.keyWin&&<p><b>Win:</b> {g.keyWin}</p>}{g.improveNext&&<p><b>Next:</b> {g.improveNext}</p>}</div>}
  {g.notes&&<p><b>Review:</b> {g.notes}</p>}
  <button onClick={()=>setCompetitions(x=>x.filter(c=>c.id!==g.id))}>Delete</button>
 </div>)}
 </>;
}

function Reports({sport,profile,goals,workouts,results,dev,program,readiness,competitions,reportNotes,setReportNotes}:{sport:Sport;profile:Profile;goals:Goal[];workouts:Workout[];results:Result[];dev:DevelopmentItem[];program:TrainingProgram|null;readiness:ReadinessLog[];competitions:CompetitionLog[];reportNotes:ReportNote[];setReportNotes:React.Dispatch<React.SetStateAction<ReportNote[]>>}){
 const [title,setTitle]=useState("Weekly Review"),[body,setBody]=useState("");
 const sportResults=results.filter(r=>r.sport===sport);
 const sportWorkouts=workouts.filter(w=>w.sport===sport);
 const completedWorkouts=sportWorkouts.filter(w=>w.completed).length;
 const trainingConsistency=sportWorkouts.length?Math.round(completedWorkouts/sportWorkouts.length*100):0;
 const goalProgress=goals.length?Math.round(goals.reduce((a,g)=>a+g.progress,0)/goals.length):0;
 const openDev=dev.filter(d=>d.status!=="Complete").length;
 const sportCompetitions=competitions.filter(c=>c.sport===sport);
 const avgRating=sportCompetitions.length?Math.round(sportCompetitions.reduce((a,c)=>a+c.rating,0)/sportCompetitions.length*10)/10:0;
 const recentReadiness=readiness.slice(0,7);
 const avgReadiness=recentReadiness.length?Math.round(recentReadiness.reduce((a,r)=>a+Math.max(0,Math.min(100,Math.round(Math.min(10,r.sleep/8*10)*2.5+(10-Math.min(10,r.soreness))*2.5+Math.min(10,r.energy)*2.5+(10-Math.min(10,r.stress))*2.5))),0)/recentReadiness.length):0;

 const grouped=[...new Map(sportResults.map(r=>[r.testId,r])).values()].map(g=>{
  const rows=sportResults.filter(r=>r.testId===g.testId).sort((a,b)=>a.date.localeCompare(b.date)||a.id-b.id);
  const def=definitions(sport).find(x=>x.id===g.testId)||({lowerBetter:g.unit==="sec"} as TestDef);
  const first=rows[0]?.value??0,last=rows[rows.length-1]?.value??0;
  const imp=rows.length>1?improvement(first,last,def.lowerBetter):0;
  return {name:g.name,unit:g.unit,first,last,imp,count:rows.length};
 }).sort((a,b)=>b.imp-a.imp);

 const overall=Math.round(goalProgress*.25+trainingConsistency*.25+avgReadiness*.2+(avgRating?avgRating*10*.2:0)+(grouped.length?10:0));

 const saveNote=()=>{
  if(!title.trim()&&!body.trim())return;
  setReportNotes(x=>[{id:Date.now(),date:today(),title:title.trim()||"Review",body:body.trim()},...x]);
  setBody("");
 };

 const exportSummary=()=>{
  const rows=[
   ["Athlete",profile.name],
   ["Sport",sport],
   ["Position",profile.position],
   ["Season",profile.season],
   ["Overall Score",String(overall)],
   ["Goal Progress",goalProgress+"%"],
   ["Training Consistency",trainingConsistency+"%"],
   ["7-Day Readiness",avgReadiness+"%"],
   ["Competition Rating",avgRating?String(avgRating):"N/A"],
   ["Open Development Objectives",String(openDev)],
   ["Test Results Logged",String(sportResults.length)],
   ["Competitions Logged",String(sportCompetitions.length)]
  ];
  const csv=rows.map(r=>r.map(v=>`"${String(v).replaceAll('"','""')}"`).join(",")).join("\n");
  const blob=new Blob([csv],{type:"text/csv;charset=utf-8"}),url=URL.createObjectURL(blob),a=document.createElement("a");
  a.href=url;a.download="athlete-performance-summary.csv";a.click();URL.revokeObjectURL(url);
 };

 return <><div className="sectionDivider"><span><i/>Performance Report</span></div><div className="hero"><small>REPORTS & INSIGHTS</small><h1>Performance Report</h1><p>{profile.name} · {sport}{profile.position?" · "+profile.position:""} · {profile.season}</p></div>

 <div className="reportScore"><div><small>OVERALL PERFORMANCE INDEX</small><strong>{overall}</strong><span>/100</span></div><div><b>{overall>=80?"Strong Progress":overall>=60?"Building Momentum":"Needs Attention"}</b><p>Combined from goals, training, readiness, competition, and testing activity.</p></div></div>

 <div className="grid reportGrid">
  <div className="stat"><small>Goal Progress</small><b>{goalProgress}%</b></div>
  <div className="stat"><small>Training Consistency</small><b>{trainingConsistency}%</b></div>
  <div className="stat"><small>7-Day Readiness</small><b>{avgReadiness}%</b></div>
  <div className="stat"><small>Competition Rating</small><b>{avgRating||"—"}</b></div>
  <div className="stat"><small>Open Dev Goals</small><b>{openDev}</b></div>
  <div className="stat"><small>Tests Logged</small><b>{sportResults.length}</b></div>
 </div>

 <div className="card"><div className="sectionHead"><h2>Performance Insights</h2><button onClick={exportSummary}>Export Summary CSV</button></div>
  {grouped.length===0?<p>Log repeated performance tests to generate improvement insights.</p>:grouped.slice(0,6).map(g=><div className="insightRow" key={g.name}><div><b>{g.name}</b><small>{g.count} results · Baseline {g.first} {g.unit} → Current {g.last} {g.unit}</small></div><strong className={g.imp>=0?"good":"bad"}>{g.count>1?(g.imp>=0?"+":"")+g.imp+"%":"New"}</strong></div>)}
 </div>

 <div className="grid twoCards">
  <div className="card"><h2>Development</h2><p>{dev.filter(d=>d.status==="Complete").length} complete · {openDev} open</p>{dev.filter(d=>d.status!=="Complete").slice(0,4).map(d=><div className="line" key={d.id}><b>{d.title}</b><small>{d.category}{d.target?" · "+d.target:""}</small></div>)}</div>
  <div className="card"><h2>Current Program</h2>{program?<><p>{program.focus} · {program.daysPerWeek} days/week</p><p>{program.sessions.filter(s=>s.completed).length}/{program.sessions.length} sessions complete</p></>:<p>No active weekly program.</p>}</div>
 </div>

 <div className="card"><h2>Review Notes</h2><div className="two"><label>Title<input value={title} onChange={e=>setTitle(e.target.value)}/></label><label>Review<input value={body} onChange={e=>setBody(e.target.value)} placeholder="Key wins, concerns, and next priorities"/></label></div><button onClick={saveNote}>Save Review</button></div>
 {reportNotes.slice(0,8).map(n=><div className="card" key={n.id}><div className="row"><b>{n.title}</b><small>{n.date}</small></div><p>{n.body}</p><button onClick={()=>setReportNotes(x=>x.filter(r=>r.id!==n.id))}>Delete</button></div>)}
 </>;
}

function Roster({sport,profile,roster,setRoster,activeAthleteId,switchAthlete}:{sport:Sport;profile:Profile;roster:AthleteRecord[];setRoster:React.Dispatch<React.SetStateAction<AthleteRecord[]>>;activeAthleteId:string;switchAthlete:(a:AthleteRecord)=>void}){
 const [name,setName]=useState(""),[newSport,setNewSport]=useState<Sport>(sport),[position,setPosition]=useState(""),[team,setTeam]=useState(""),[season,setSeason]=useState(profile.season||"2026-27"),[height,setHeight]=useState(""),[weight,setWeight]=useState(""),[handedness,setHandedness]=useState<"Right"|"Left">("Right");
 const currentRecord:AthleteRecord={id:"primary",name:profile.name,sport,position:profile.position,team:profile.team,season:profile.season,height:profile.height,weight:profile.weight,handedness:profile.handedness};

 const add=()=>{
  if(!name.trim())return;
  const item:AthleteRecord={id:"athlete-"+Date.now(),name:name.trim(),sport:newSport,position,team,season,height,weight,handedness};
  setRoster(x=>[...x,item]);
  setName("");setPosition("");setTeam("");setHeight("");setWeight("");
 };

 const activate=(a:AthleteRecord)=>{
  switchAthlete(a);
 };

 const all=[currentRecord,...roster.filter(x=>x.id!=="primary")];
 return <><div className="hero"><small>PHASE 12 · COACH / PARENT</small><h1>Athlete Roster</h1><p>Manage multiple athletes from one mobile-friendly dashboard.</p></div>

 <div className="card"><h2>Add Athlete</h2>
  <div className="two">
   <label>Name<input value={name} onChange={e=>setName(e.target.value)} placeholder="Athlete name"/></label>
   <label>Sport<select value={newSport} onChange={e=>{const v=e.target.value as Sport;setNewSport(v);setPosition("")}}>{["Baseball","Football","Ice Hockey","Basketball","Lacrosse","Wrestling","Soccer"].map(x=><option key={x}>{x}</option>)}</select></label>
   <label>Position<select value={positions[newSport].includes(position)?position:""} onChange={e=>setPosition(e.target.value)}><option value="">Select position</option>{positions[newSport].map(x=><option key={x}>{x}</option>)}</select></label>
   <label>Team<input value={team} onChange={e=>setTeam(e.target.value)} placeholder="Team"/></label>
   <label>Season<input value={season} onChange={e=>setSeason(e.target.value)}/></label>
   <label>Height<input value={height} onChange={e=>setHeight(e.target.value)} placeholder="e.g. 5'10&quot;"/></label>
   <label>Weight<input value={weight} onChange={e=>setWeight(e.target.value)} placeholder="e.g. 165 lb"/></label>
   <label>Handedness<select value={handedness} onChange={e=>setHandedness(e.target.value as "Right"|"Left")}><option>Right</option><option>Left</option></select></label>
  </div>
  <button className="primary" onClick={add}>Add Athlete</button>
 </div>

 <div className="card"><h2>Roster</h2>
  <div className="rosterGrid">{all.map(a=><div className={"rosterCard "+(activeAthleteId===a.id?"activeRoster":"")} key={a.id}>
   <div className="rosterAvatar">{a.name.split(" ").map(x=>x[0]).join("").slice(0,2).toUpperCase()||"A"}</div>
   <div><b>{a.name}</b><small>{a.sport}{a.position?" · "+a.position:""}{a.team?" · "+a.team:""}</small><small>{a.height||"—"} · {a.weight||"—"} · {a.handedness}</small></div>
   <button onClick={()=>activate(a)}>{activeAthleteId===a.id?"Active":"Switch"}</button>
   {a.id!=="primary"&&<button onClick={()=>setRoster(x=>x.filter(r=>r.id!==a.id))}>Remove</button>}
  </div>)}</div>
 </div>

 <div className="card"><h2>Athlete Data Isolation</h2><p>Each roster athlete now has independent local goals, testing history, workouts, readiness logs, competitions, and reports.</p></div><div className="card"><h2>Coach / Parent Workflow</h2>
  <div className="quickStats"><span><b>{all.length}</b><small>Athletes</small></span><span><b>{all.filter(a=>a.sport===sport).length}</b><small>{sport} athletes</small></span><span><b>{all.filter(a=>a.team).length}</b><small>With teams</small></span></div>
  <p>Each athlete now has a separate local data workspace. Switching athletes also switches that athlete’s goals, workouts, tests, development plan, program, readiness, competitions, and reports.</p>
 </div>
 </>;
}

function DataCenter({profile,sport,roster,activeAthleteId,goals,workouts,results,dev,program,readiness,coachNotes,competitions,reportNotes,setProfile,setGoals,setWorkouts,setResults,setDev,setProgram,setReadiness,setCoachNotes,setCompetitions,setReportNotes,setRoster,setActiveAthleteId,setSport}:{profile:Profile;sport:Sport;roster:AthleteRecord[];activeAthleteId:string;goals:Goal[];workouts:Workout[];results:Result[];dev:DevelopmentItem[];program:TrainingProgram|null;readiness:ReadinessLog[];coachNotes:CoachNote[];competitions:CompetitionLog[];reportNotes:ReportNote[];setProfile:React.Dispatch<React.SetStateAction<Profile>>;setGoals:any;setWorkouts:any;setResults:any;setDev:any;setProgram:any;setReadiness:any;setCoachNotes:any;setCompetitions:any;setReportNotes:any;setRoster:any;setActiveAthleteId:any;setSport:any}){
 const [message,setMessage]=useState("");
 const currentSnapshot:AthleteSnapshot={profile:{...profile},goals:[...goals],workouts:[...workouts],results:[...results],development:[...dev],program,readiness:[...readiness],coachNotes:[...coachNotes],competitions:[...competitions],reportNotes:[...reportNotes]};

 const athleteRecords:AthleteRecord[]=[
  {id:"primary",name:profile.name,sport,position:profile.position,team:profile.team,season:profile.season,height:profile.height,weight:profile.weight,handedness:profile.handedness},
  ...roster.filter(r=>r.id!=="primary")
 ];

 const download=(name:string,data:any)=>{
  const blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json;charset=utf-8"});
  const url=URL.createObjectURL(blob),a=document.createElement("a");
  a.href=url;a.download=name;a.click();URL.revokeObjectURL(url);
 };

 const exportCurrent=()=>{
  download(`athlete-${profile.name.replace(/\s+/g,"-").toLowerCase()}-backup.json`,{version:"14.0",created:new Date().toISOString(),athleteId:activeAthleteId,sport,snapshot:currentSnapshot});
  setMessage("Current athlete backup created.");
 };

 const exportAll=()=>{
  const athletes:Record<string,AthleteSnapshot>={};
  athleteRecords.forEach(a=>{
    try{
      const raw=localStorage.getItem(`athleteData:${a.id}`);
      athletes[a.id]=raw?JSON.parse(raw):a.id===activeAthleteId?currentSnapshot:{profile:{name:a.name,position:a.position,team:a.team,season:a.season,height:a.height,weight:a.weight,handedness:a.handedness},goals:[],workouts:[],results:[],development:[],program:null,readiness:[],coachNotes:[],competitions:[],reportNotes:[]};
    }catch{
      athletes[a.id]=currentSnapshot;
    }
  });
  const envelope:BackupEnvelope={version:"14.0",created:new Date().toISOString(),activeAthleteId,roster:athleteRecords,athletes};
  download("athlete-performance-full-backup.json",envelope);
  setMessage("Full roster backup created.");
 };

 const applySnapshot=(snap:AthleteSnapshot)=>{
  const safe=snap||({} as AthleteSnapshot);
  setProfile({name:safe.profile?.name??"Athlete",position:safe.profile?.position??"",team:safe.profile?.team??"",season:safe.profile?.season??"2026-27",height:safe.profile?.height??"",weight:safe.profile?.weight??"",handedness:safe.profile?.handedness==="Left"?"Left":"Right"});
  setGoals(Array.isArray(safe.goals)?safe.goals:[]);
  setWorkouts(Array.isArray(safe.workouts)?safe.workouts:[]);
  setResults(Array.isArray(safe.results)?safe.results:[]);
  setDev(Array.isArray(safe.development)?safe.development:[]);
  setProgram(safe.program??null);
  setReadiness(Array.isArray(safe.readiness)?safe.readiness:[]);
  setCoachNotes(Array.isArray(safe.coachNotes)?safe.coachNotes:[]);
  setCompetitions(Array.isArray(safe.competitions)?safe.competitions:[]);
  setReportNotes(Array.isArray(safe.reportNotes)?safe.reportNotes:[]);
 };

 const importBackup=(file:File)=>{
  const reader=new FileReader();
  reader.onload=()=>{
    try{
      const data=JSON.parse(String(reader.result||"{}"));
      if(data?.athletes&&data?.roster){
        const env=data as BackupEnvelope;
        Object.entries(env.athletes).forEach(([id,snap])=>localStorage.setItem(`athleteData:${id}`,JSON.stringify(snap)));
        const restoredRoster=(env.roster||[]).filter(r=>r.id!=="primary");
        setRoster(restoredRoster);
        const nextId=env.activeAthleteId||"primary";
        setActiveAthleteId(nextId);
        const snap=env.athletes[nextId]||env.athletes["primary"];
        if(snap){applySnapshot(snap);const rec=(env.roster||[]).find(r=>r.id===nextId);if(rec)setSport(rec.sport);}
        setMessage("Full backup restored.");
      }else if(data?.snapshot){
        applySnapshot(data.snapshot);
        localStorage.setItem(`athleteData:${activeAthleteId}`,JSON.stringify(data.snapshot));
        if(data.sport)setSport(data.sport);
        setMessage("Athlete backup restored.");
      }else{
        setMessage("That file is not a valid Athlete Performance backup.");
      }
    }catch{
      setMessage("Could not read the backup file.");
    }
  };
  reader.readAsText(file);
 };

 const clearCurrent=()=>{
  if(!confirm(`Clear all saved performance data for ${profile.name}? This cannot be undone unless you have a backup.`))return;
  const blank:AthleteSnapshot={profile:{...profile},goals:[],workouts:[],results:[],development:[],program:null,readiness:[],coachNotes:[],competitions:[],reportNotes:[]};
  applySnapshot(blank);
  localStorage.setItem(`athleteData:${activeAthleteId}`,JSON.stringify(blank));
  setMessage("Current athlete performance data cleared.");
 };

 const totalItems=goals.length+workouts.length+results.length+dev.length+readiness.length+coachNotes.length+competitions.length+reportNotes.length+(program?.sessions.length||0);

 return <><div className="sectionDivider"><span><i/>Data & Backup</span></div><div className="hero"><small>DATA SAFETY</small><h1>Backup & Restore</h1><p>Protect athlete data before changing devices, browsers, or future app versions.</p></div>

 <div className="grid three">
  <div className="stat"><small>Active Athlete</small><b>{profile.name}</b></div>
  <div className="stat"><small>Saved Data Items</small><b>{totalItems}</b></div>
  <div className="stat"><small>Roster Athletes</small><b>{athleteRecords.length}</b></div>
 </div>

 <div className="card"><h2>Backup</h2><p>Download a portable JSON backup before major upgrades or switching devices.</p><div className="dataActions"><button className="primary" onClick={exportCurrent}>Backup Current Athlete</button><button onClick={exportAll}>Backup Entire Roster</button></div></div>

 <div className="card"><h2>Restore</h2><p>Restore a Phase 14 athlete or full-roster backup. Existing data for restored athletes will be replaced.</p><label className="filePicker">Choose Backup File<input type="file" accept=".json,application/json" onChange={e=>{const f=e.target.files?.[0];if(f)importBackup(f);e.currentTarget.value=""}}/></label></div>

 <div className="card"><h2>Data Health</h2><div className="dataHealth">
  <span><b>{goals.length}</b><small>Goals</small></span>
  <span><b>{workouts.length}</b><small>Workouts</small></span>
  <span><b>{results.length}</b><small>Tests</small></span>
  <span><b>{competitions.length}</b><small>Competitions</small></span>
  <span><b>{readiness.length}</b><small>Readiness Logs</small></span>
  <span><b>{reportNotes.length}</b><small>Report Notes</small></span>
 </div></div>

 <div className="card dangerZone"><h2>Reset Current Athlete Data</h2><p>This keeps the athlete profile but clears performance history for the active athlete only.</p><button onClick={clearCurrent}>Clear Performance Data</button></div>

 {message&&<div className="dataMessage" role="status">{message}</div>}
 </>;
}


function SmartCoach({sport,profile,goals,workouts,results,dev,program,readiness,competitions}:{sport:Sport;profile:Profile;goals:Goal[];workouts:Workout[];results:Result[];dev:DevelopmentItem[];program:TrainingProgram|null;readiness:ReadinessLog[];competitions:CompetitionLog[]}){
 const sr=results.filter(r=>r.sport===sport),sw=workouts.filter(w=>w.sport===sport),sc=competitions.filter(c=>c.sport===sport);
 const done=sw.filter(w=>w.completed).length,consistency=sw.length?Math.round(done/sw.length*100):0;
 const goalProgress=goals.length?Math.round(goals.reduce((a,g)=>a+g.progress,0)/goals.length):0;
 const recent=readiness.slice(0,7),avgReadiness=recent.length?Math.round(recent.reduce((a,r)=>a+Math.max(0,Math.min(100,Math.round(Math.min(10,r.sleep/8*10)*2.5+(10-Math.min(10,r.soreness))*2.5+Math.min(10,r.energy)*2.5+(10-Math.min(10,r.stress))*2.5))),0)/recent.length):0;
 const grouped=[...new Map(sr.map(r=>[r.testId,r])).values()].map(g=>{const rows=sr.filter(r=>r.testId===g.testId).sort((a,b)=>a.date.localeCompare(b.date)||a.id-b.id),def=definitions(sport).find(x=>x.id===g.testId)||({lowerBetter:g.unit==="sec"} as TestDef),first=rows[0]?.value??0,last=rows[rows.length-1]?.value??0;return {name:g.name,imp:rows.length>1?improvement(first,last,def.lowerBetter):0,count:rows.length}});
 const recs:Recommendation[]=[];
 if(avgReadiness>0&&avgReadiness<60)recs.push({id:"recovery",title:"Prioritize Recovery",reason:`7-day readiness is ${avgReadiness}%.`,action:"Reduce volume and emphasize sleep, mobility, and low-intensity technique work.",priority:"High",category:"Recovery"});
 if(consistency<60&&sw.length>=3)recs.push({id:"training",title:"Improve Training Consistency",reason:`You completed ${done} of ${sw.length} planned workouts.`,action:"Simplify the week and prioritize 3 quality sessions.",priority:"High",category:"Training"});
 if(goalProgress<50&&goals.length)recs.push({id:"goals",title:"Refocus Your Goals",reason:`Average goal progress is ${goalProgress}%.`,action:"Pick one short-term goal and connect the next 2–3 workouts to it.",priority:"Medium",category:"Goals"});
 const openDev=dev.filter(d=>d.status!=="Complete");if(openDev.length)recs.push({id:"dev",title:"Target a Development Objective",reason:`${openDev.length} objective${openDev.length===1?"":"s"} remain open.`,action:`Make "${openDev[0].title}" the focus of your next development session.`,priority:"Medium",category:"Development"});
 const declining=grouped.filter(g=>g.count>=2&&g.imp<0).sort((a,b)=>a.imp-b.imp)[0];if(declining)recs.push({id:"decline",title:`Address ${declining.name}`,reason:`This test is ${Math.abs(declining.imp)}% below baseline.`,action:"Review recent training load and add one focused session for this quality.",priority:"High",category:"Testing"});
 const improving=grouped.filter(g=>g.count>=2&&g.imp>0).sort((a,b)=>b.imp-a.imp)[0];if(improving)recs.push({id:"improve",title:`Keep Building ${improving.name}`,reason:`You are ${improving.imp}% better than baseline.`,action:"Keep the methods that are working and retest on the same schedule.",priority:"Low",category:"Testing"});
 if(program&&program.sessions.length&&program.sessions.filter(x=>x.completed).length/program.sessions.length<0.5)recs.push({id:"program",title:"Finish Your Weekly Program",reason:"Less than half of the current program is complete.",action:"Complete the next scheduled session before adding more volume.",priority:"Medium",category:"Program"});
 if(sc.length>=3){const rating=Math.round(sc.reduce((a,c)=>a+c.rating,0)/sc.length*10)/10;if(rating<6.5)recs.push({id:"comp",title:"Review Competition Performance",reason:`Average competition rating is ${rating}/10.`,action:"Review the last 3 competition notes and turn one repeat issue into a development objective.",priority:"Medium",category:"Competition"})}
 if(!recs.length)recs.push({id:"steady",title:"Stay the Course",reason:"No major warning area appears in the current data.",action:"Continue the program, keep logging readiness, and retest key measures regularly.",priority:"Low",category:"Overall"});
 const order={High:0,Medium:1,Low:2};recs.sort((a,b)=>order[a.priority]-order[b.priority]);
 const score=Math.max(0,Math.min(100,Math.round(goalProgress*.25+consistency*.25+(avgReadiness||70)*.25+(grouped.length?25:12))));
 return <><div className="sectionDivider"><span><i/>Coach Recommendations</span></div><div className="hero"><small>SMART COACH</small><h1>Smart Coach</h1><p>{profile.name} · {sport}{profile.position?" · "+profile.position:""} · Data-driven next steps.</p></div><div className="coachHero"><div><small>COACHING SCORE</small><strong>{score}</strong><span>/100</span></div><div><b>{score>=80?"Strong Momentum":score>=60?"Good Base — Keep Building":"Focus Needed"}</b><p>Based on goals, training consistency, readiness, and testing activity.</p></div></div><div className="grid three"><div className="stat"><small>Goal Progress</small><b>{goalProgress}%</b></div><div className="stat"><small>Training Consistency</small><b>{consistency}%</b></div><div className="stat"><small>7-Day Readiness</small><b>{avgReadiness||"—"}</b></div></div><div className="card"><h2>Recommended Next Actions</h2><div className="recommendationList">{recs.map(r=><div className={"recommendation "+r.priority.toLowerCase()} key={r.id}><div className="recPriority">{r.priority}</div><div><span className="tag">{r.category}</span><h2>{r.title}</h2><p><b>Why:</b> {r.reason}</p><p><b>Next step:</b> {r.action}</p></div></div>)}</div></div><div className="grid twoCards"><div className="card"><h2>What Is Improving</h2>{improving?<><b>{improving.name}</b><p>{improving.imp}% improvement from baseline.</p></>:<p>Log repeated tests to identify your strongest trend.</p>}</div><div className="card"><h2>What Needs Attention</h2>{declining?<><b>{declining.name}</b><p>{Math.abs(declining.imp)}% below baseline.</p></>:<p>No declining repeated-test trend detected.</p>}</div></div><div className="card"><h2>Coach Checklist</h2><div className="coachChecklist"><span>✓ Keep tests consistent.</span><span>✓ Use readiness before high-intensity training.</span><span>✓ Link workouts to one development priority.</span><span>✓ Review competition notes before changing the plan.</span></div></div></>;
}

function TrendChart({values,lower}:{values:number[];lower:boolean}){const w=520,h=150,p=24,min=Math.min(...values),max=Math.max(...values),span=max-min||1;const pts=values.map((v,i)=>`${p+i*((w-2*p)/Math.max(1,values.length-1))},${h-p-((v-min)/span)*(h-2*p)}`).join(" ");return <svg className="chart" viewBox={`0 0 ${w} ${h}`} role="img" aria-label="Performance trend"><line x1={p} y1={h-p} x2={w-p} y2={h-p} stroke="currentColor" opacity=".2"/><polyline points={pts} fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"/>{values.map((v,i)=>{const x=p+i*((w-2*p)/Math.max(1,values.length-1)),y=h-p-((v-min)/span)*(h-2*p);return <circle key={i} cx={x} cy={y} r="5" fill="currentColor"/>})}</svg>}
