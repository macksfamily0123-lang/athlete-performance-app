# Phase 72.3.82 RC32 — Professional Athletic System

RC32 is one full combined release built on RC31. It preserves the complete RC31/RC30/RC29 functional baseline and extends the visual system from Home through Goals, Testing, Progress, Development, Competition, Roster, Coach, Parent, Admin, More, forms, tabs, navigation and empty/loading states.

## RC32 highlights

- Player Home Progress destination now has a large, explicit **PROGRESS** heading plus **VIEW PROGRESS** action text.
- Ice Hockey Coach Home now uses a new `1600×900` wide hero asset rather than the old square `640×667` crop.
- Coach hero uses full-bleed cover behavior and role-specific cinematic overlays on desktop and mobile.
- Non-Junior screens use sharper ruled surfaces, flatter cards, restrained graphite/silver/forest-green color, stronger section typography and less rounded UI chrome.
- Tabs use performance-style underline navigation rather than pill controls.
- Forms, tags, roster rows, analytics panels, development panels, testing, competition and support surfaces share the same elite visual language.
- Fixed bottom navigation and setup-modal behavior from RC28/RC27 remain intact.
- RC29 Coach Invite Player / Manage Teams and More → Roster repairs remain included.
- Recovery Tips remain prominent on Player Home.
- Junior mode retains its simpler age-appropriate visual treatment.
- Supabase integration, roles/permissions, Player More, cloud test athletes and migration 009 are preserved.

## Database

No new migration. `009_player_more_cloud_test_athletes.sql` is unchanged.
