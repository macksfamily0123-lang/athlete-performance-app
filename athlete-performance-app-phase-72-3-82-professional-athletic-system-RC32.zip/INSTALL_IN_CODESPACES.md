# Install Phase 72.3.82 RC32 in Codespaces

Upload `athlete-performance-app-phase-72-3-82-professional-athletic-system-RC32.zip` into `/workspaces/athlete-performance-app`, then run each command separately.

```bash
cd /workspaces/athlete-performance-app
```

```bash
unzip -o athlete-performance-app-phase-72-3-82-professional-athletic-system-RC32.zip
```

```bash
rm -rf .next
```

```bash
npm install
```

```bash
npm run test:professional-athletic
```

```bash
npm run test:typecheck
```

```bash
npm run dev -- -H 0.0.0.0 -p 3001
```

No new Supabase migration is required.
