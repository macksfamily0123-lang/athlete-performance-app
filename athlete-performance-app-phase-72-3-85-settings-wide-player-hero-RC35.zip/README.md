
## Phase 72.3.85 RC35 — Settings + Wide Player Game Hero
- Settings now opens from Player, Parent, and Coach views using the document-level viewport portal.
- Ice Hockey Player Home uses a dedicated wide in-game hero with rink, opponents, crowd, and arena context.
- Parent and Coach keep their separate RC34 role-specific hero imagery.
- Migration 009 remains unchanged.
# Athlete Performance App — Phase 72.3.85 RC35

## Role-specific full hero photography
- Ice Hockey Player, Parent, and Coach now use distinct role-specific hero images.
- Player keeps the action-athlete scene.
- Parent uses a supportive parent/athlete scene.
- Coach uses a dedicated coach/team scene.
- Realistic Home heroes now use a two-layer image renderer: a full-bleed darkened backdrop fills the entire hero, while a sharp foreground layer keeps the complete source image visible instead of over-zooming it.
- Junior mode keeps the simpler sport artwork.
- All Phase 72.3.83 RC33 functionality is preserved.
- Migration 009 remains unchanged.

# Athlete Performance App — Phase 72.3.83 RC33

RC33 is the full combined **Sport Photo Framing** release built on RC32.

The primary change is less aggressive realistic hero-photo cropping. Wide sport photography sits farther back with cinematic edge-fill, while Hockey Player and Hockey Coach receive framing tailored to their source image orientation. This keeps the large premium hero treatment while showing more of each original image and reducing the over-zoomed/pixelated appearance.

All RC32 functionality and prior fixes are included. Migration 009 remains the latest required migration.
