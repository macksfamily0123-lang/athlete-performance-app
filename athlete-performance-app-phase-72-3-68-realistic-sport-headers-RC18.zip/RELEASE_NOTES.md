# Phase 72.3.68 RC18 — Realistic Non-Junior Sport Headers

Baseline: Phase 72.3.67 RC17, which itself was built from completed Phase 72.3.64 RC15. No unfinished Phase 72.3.65 code is included.

## Visual update
- Replaces the unclear non-junior Ice Hockey header art with realistic generated commercial-concept imagery.
- Player/Parent/Admin Ice Hockey homes use the action-skater scene.
- Coach Ice Hockey home uses the realistic coach/team scene.
- Junior Player stays on the simpler, friendly sport illustration for now.
- Header is still driven by the active athlete Profile Sport. Non-hockey athletes retain their own sport-specific header instead of ever showing hockey imagery.

## Preserved
- Supabase work and cloud test athletes
- roles and permissions
- Junior mode
- Player More fix
- Parent and Coach flows
- Player photos
- migration 009 unchanged

## Database
No new migration.
