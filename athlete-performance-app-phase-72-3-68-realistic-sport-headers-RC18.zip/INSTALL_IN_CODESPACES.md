# Install Phase 72.3.68 RC18 in GitHub Codespaces

This is a full app ZIP. Upload it to `/workspaces/athlete-performance-app`, unzip over the current app, clear `.next`, install, test, and run.

```bash
cd /workspaces/athlete-performance-app
```

```bash
unzip -o athlete-performance-app-phase-72-3-68-realistic-sport-headers-RC18.zip
```

```bash
rm -rf .next
```

```bash
npm install
```

```bash
npm run test:realistic-hero
```

```bash
npm run dev
```

No new Supabase migration is required. Migration 009 remains the current required migration.
