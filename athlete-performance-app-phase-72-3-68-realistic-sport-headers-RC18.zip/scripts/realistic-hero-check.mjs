import fs from 'node:fs';
import path from 'node:path';

const root=process.cwd();
const app=fs.readFileSync(path.join(root,'components','AthleteApp.tsx'),'utf8');
const css=fs.readFileSync(path.join(root,'app','globals.css'),'utf8');
const player=path.join(root,'public','commercial-scenes','ice-hockey-player.webp');
const coach=path.join(root,'public','commercial-scenes','ice-hockey-coach.webp');
const checks=[
 ['realistic hockey Player image exists',fs.existsSync(player)&&fs.statSync(player).size>10000],
 ['realistic hockey Coach image exists',fs.existsSync(coach)&&fs.statSync(coach).size>10000],
 ['junior mode keeps sport-specific illustrated asset',app.includes('if(juniorMode)return sportHeroAsset(sport)')],
 ['non-junior hockey uses generated commercial Player scene',app.includes('/commercial-scenes/ice-hockey-player.webp')],
 ['Coach uses generated commercial Coach scene',app.includes('/commercial-scenes/ice-hockey-coach.webp')],
 ['other sports remain tied to athlete sport',app.includes('return sportHeroAsset(sport)')],
 ['hero exposes explicit sport marker',app.includes('data-hero-sport={sport}')],
 ['hero exposes realistic versus illustrated marker',app.includes('data-hero-style={realisticHero?"realistic":"illustrated"}')],
 ['realistic hero CSS uses photo treatment',css.includes('.premiumHomeHero.premiumRealisticSportHero')&&css.includes('auto 132%')],
 ['junior-specific treatment remains present',css.includes('.premiumJuniorHome .premiumHomeHero')]
];
let failed=0;
for(const [name,ok] of checks){console.log(`${ok?'PASS':'FAIL'}: ${name}`);if(!ok)failed++;}
if(failed){console.error(`\
${failed} realistic-hero check(s) failed.`);process.exit(1);}
console.log(`\
PASS: ${checks.length}/${checks.length} realistic non-junior hero checks.`);
