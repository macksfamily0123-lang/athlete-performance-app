# Phase 72.3.88 RC38 — Codespaces Installation

Upload the RC38 ZIP into `/workspaces/athlete-performance-app`, then run each command separately.

```bash
cd /workspaces/athlete-performance-app
```

```bash
unzip -o athlete-performance-app-phase-72-3-88-combined-rc36-rc37-rc38.zip
```

```bash
rm -rf .next
```

```bash
npm install
```

```bash
npm run test:performance-intelligence
```

```bash
npm run test:beta-hardening
```

```bash
npm run test:typecheck
```

```bash
npm run dev -- -H 0.0.0.0 -p 3001
```

No new Supabase migration is required. Migration 009 remains the latest required migration.
