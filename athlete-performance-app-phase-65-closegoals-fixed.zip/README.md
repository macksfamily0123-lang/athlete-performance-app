# Athlete Performance App — Combined Phase 61–65

Built from the verified Phase 60 release.

## Phase 61 — Role-Aware Workspace 2.0
- Athlete, Coach, and Parent views now show role-specific next actions
- Existing workspace-role selection preserved

## Phase 62 — Team Dashboard
- Team grouping
- Team filters
- Team average score
- Ready-to-train athlete count
- Team testing and roster summaries

## Phase 63 — Shareable Athlete Snapshot
- Downloadable athlete snapshot JSON
- Existing CSV, copy-summary, and print-report actions preserved

## Phase 64 — Local Data Versioning
- Visible autosave status
- Local schema version label
- Existing data integrity and backup tools preserved

## Phase 65 — Release 65
- Unified team, role, snapshot, and save-status visual design
- Mobile layout refinements
- Same nine-tab navigation

No new top-level tabs were added.
