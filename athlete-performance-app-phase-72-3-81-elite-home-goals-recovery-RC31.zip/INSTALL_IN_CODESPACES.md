# Install Phase 72.3.81 RC31 in Codespaces

RC31 is one full combined download. It already includes the Phase 72.3.79 RC29 More/Roster + Coach action repairs.

From the existing app root:

```bash
cd /workspaces/athlete-performance-app
```

Upload `athlete-performance-app-phase-72-3-80-elite-performance-visual-system-RC31.zip`, then:

```bash
unzip -o athlete-performance-app-phase-72-3-80-elite-performance-visual-system-RC31.zip
```

```bash
rm -rf .next
```

```bash
npm install
```

```bash
npm run test:elite-visual
```

```bash
npm run test:coach-roster-more
```

```bash
npm run test:typecheck
```

```bash
npm run dev -- -H 0.0.0.0 -p 3001
```

No new Supabase migration is required. Migration 009 remains unchanged.
