# Phase 72.3.81 RC31 — Elite Home, Goals & Recovery Refinement

- Removes the inherited circular artifact from the Player hero overlay.
- Makes the Home Progress destination explicitly labeled and clickable.
- Adds prominent Recovery Tips directly to Player Home with readiness-aware guidance.
- Rebuilds non-Junior My Goals into a sharp editorial goal board with no rounded dashboard cards.
- Adds an always-visible goal performance signal rail for active goals, momentum, near-finish goals, and completions.
- Preserves RC30/RC29 functional fixes, always-active navigation, setup modal behavior, roles/permissions, cloud athletes, Junior mode, realistic all-sport imagery, and migration 009.
- No new Supabase migration is required; migration 009 remains latest.

# RC31 Release Notes

## Phase 72.3.81 — Elite Performance Visual System

### Visual system upgrade
- RC29 functional fixes are fully included in this one combined release.
- New continuous live-performance signal rail for readiness, goals, testing, and training.
- New embedded performance sparkline using repeated-test or readiness history.
- Photography-first hero gains restrained telemetry details and sport-specific visual geometry.
- Home screens use stronger editorial hierarchy, graphite/silver surfaces, disciplined accent colors, and fewer generic dashboard cards.
- Analytics, roster, navigation sheets, setup dialog, and forms receive a sharper premium-performance treatment.
- Mobile layout is tuned for 360–430 px screens with full-width visuals and stable tap targets.

### Preserved
- RC29 More/Roster overlap repair, working Coach Invite Player / Manage Teams actions, and duplicate Add Player cleanup.
- RC28 always-active bottom navigation and Train layout repair.
- RC27 viewport shell and centered setup modal.
- Supabase integration, role permissions, Junior mode, Player More, cloud test athletes, player photos, realistic all-sport imagery, Parent/Coach workflows, and migration 009.

# RC29 Release Notes

## Phase 72.3.79 — More/Roster + Coach Action Repair

### Fixed
- Roster label/icon overlap inside the More navigation sheet.
- Coach **Invite Player** and **Manage Teams** actions now use explicit working launchers.
- Admin Coach Preview no longer presents silent no-op team actions; it displays a read-only explanation.
- Duplicate Invite/Add Player controls removed from the Coach Roster page.
- More-sheet content now wraps safely on narrow mobile screens.

### Preserved
- RC28 always-active bottom navigation and Train layout repair.
- RC27 viewport shell and centered setup modal.
- RC26 Performance OS visual system.
- Supabase, roles/permissions, Junior mode, Player More, cloud test athletes, player photos, realistic all-sport imagery, Parent/Coach workflows, and migration 009.
