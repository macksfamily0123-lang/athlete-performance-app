# Phase 72.3.91 RC41 — Codespaces Install

1. Upload the RC41 ZIP into `/workspaces/athlete-performance-app`.

```bash
cd /workspaces/athlete-performance-app
```

```bash
unzip -o athlete-performance-app-phase-72-3-91-tracker-discovery-recovery-RC41.zip
```

```bash
rm -rf .next
```

```bash
npm install
```

2. Run the RC41 discovery regression:

```bash
npm run test:tracker-discovery
```

Expected: `PASS: 14/14 RC41 Tracker Discovery checks.`

3. Re-run Google Health and tracker foundation checks:

```bash
npm run test:google-health
```

```bash
npm run test:connected-trackers
```

4. Typecheck and build:

```bash
npm run test:typecheck
```

```bash
npm run build
```

5. Start locally:

```bash
npm run dev -- -H 0.0.0.0 -p 3001
```

RC41 requires no new Supabase migration. Keep migrations 010 and 011 already installed.
